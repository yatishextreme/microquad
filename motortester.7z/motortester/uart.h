#include <msp430f2619.h>

void UART_init(void);
unsigned char UART_putchar(unsigned char c);
