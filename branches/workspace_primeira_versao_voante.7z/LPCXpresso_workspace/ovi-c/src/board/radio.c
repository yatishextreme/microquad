#include "lpc_types.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_gpio.h"

#include "delay.h"
#include "radio.h"

int32_t RadioMinVal	= RADIO_MIN_CH_VALUE;
int32_t RadioMaxVal	= RADIO_MAX_CH_VALUE;

int32_t RadioValues[RADIO_NUM_CH] 	= {0,0,0,0,0,0,0,0};
int32_t RadioOffsets[RADIO_NUM_CH] 	= {0,0,0,0,0,0,0,0};

static uint32_t RadioRiseTime[RADIO_NUM_CH] = {0,0,0,0, 0,0,0,0};
static uint32_t FailledReadings = 0;
static uint32_t TotalReadings = 0;

int32_t radio_offset_channel(RADIO_CH_t ChannelNum, uint16_t NumSamples){
	uint32_t Mean = 0;
	uint16_t Div = NumSamples;

	while(NumSamples--){
		delay_ms(20);
		Mean += RadioValues[ChannelNum];
	}

	return (Mean/Div);
}

inline void ppm_input_process(void){
	int32_t now = get_time_ticks();

	if(GPIO_GetIntStatus(RADIO_CH1_PORT, RADIO_CH1_PIN, RISING_EDGE)){
		radio_channel(RADIO_CH1, 0, now);
		GPIO_ClearInt(RADIO_CH1_PORT, _BIT(RADIO_CH1_PIN));
	}
	else{
		if(GPIO_GetIntStatus(RADIO_CH1_PORT, RADIO_CH1_PIN, FALLING_EDGE)){
			radio_channel(RADIO_CH1, 1, now);
			GPIO_ClearInt(RADIO_CH1_PORT, _BIT(RADIO_CH1_PIN));
		}
	}

	if(GPIO_GetIntStatus(RADIO_CH2_PORT, RADIO_CH2_PIN, RISING_EDGE)){
		radio_channel(RADIO_CH2, 0, now);
		GPIO_ClearInt(RADIO_CH2_PORT, _BIT(RADIO_CH2_PIN));
	}
	else{
		if(GPIO_GetIntStatus(RADIO_CH2_PORT, RADIO_CH2_PIN, FALLING_EDGE)){
			radio_channel(RADIO_CH2, 1, now);
			GPIO_ClearInt(RADIO_CH2_PORT, _BIT(RADIO_CH2_PIN));
		}
	}

	if(GPIO_GetIntStatus(RADIO_CH3_PORT, RADIO_CH3_PIN, RISING_EDGE)){
		radio_channel(RADIO_CH3, 0, now);
		GPIO_ClearInt(RADIO_CH3_PORT, _BIT(RADIO_CH3_PIN));
	}
	else{
		if(GPIO_GetIntStatus(RADIO_CH3_PORT, RADIO_CH3_PIN, FALLING_EDGE)){
			radio_channel(RADIO_CH3, 1, now);
			GPIO_ClearInt(RADIO_CH3_PORT, _BIT(RADIO_CH3_PIN));
		}
	}

	if(GPIO_GetIntStatus(RADIO_CH4_PORT, RADIO_CH4_PIN, RISING_EDGE)){
		radio_channel(RADIO_CH4, 0, now);
		GPIO_ClearInt(RADIO_CH4_PORT, _BIT(RADIO_CH4_PIN));
	}
	else{
		if(GPIO_GetIntStatus(RADIO_CH4_PORT, RADIO_CH4_PIN, FALLING_EDGE)){
			radio_channel(RADIO_CH4, 1, now);
			GPIO_ClearInt(RADIO_CH4_PORT, _BIT(RADIO_CH4_PIN));
		}
	}

	if(GPIO_GetIntStatus(RADIO_CH5_PORT, RADIO_CH5_PIN, RISING_EDGE)){
		radio_channel(RADIO_CH5, 0, now);
		GPIO_ClearInt(RADIO_CH5_PORT, _BIT(RADIO_CH5_PIN));
	}
	else{
		if(GPIO_GetIntStatus(RADIO_CH5_PORT, RADIO_CH5_PIN, FALLING_EDGE)){
			radio_channel(RADIO_CH5, 1, now);
			GPIO_ClearInt(RADIO_CH5_PORT, _BIT(RADIO_CH5_PIN));
		}
	}

	if(GPIO_GetIntStatus(RADIO_CH6_PORT, RADIO_CH6_PIN, RISING_EDGE)){
		radio_channel(RADIO_CH6, 0, now);
		GPIO_ClearInt(RADIO_CH6_PORT, _BIT(RADIO_CH6_PIN));
	}
	else{
		if(GPIO_GetIntStatus(RADIO_CH6_PORT, RADIO_CH6_PIN, FALLING_EDGE)){
			radio_channel(RADIO_CH6, 1, now);
			GPIO_ClearInt(RADIO_CH6_PORT, _BIT(RADIO_CH6_PIN));
		}
	}

	if(GPIO_GetIntStatus(RADIO_CH7_PORT, RADIO_CH7_PIN, RISING_EDGE)){
		radio_channel(RADIO_CH7, 0, now);
		GPIO_ClearInt(RADIO_CH7_PORT, _BIT(RADIO_CH7_PIN));
	}
	else{
		if(GPIO_GetIntStatus(RADIO_CH7_PORT, RADIO_CH7_PIN, FALLING_EDGE)){
			radio_channel(RADIO_CH7, 1, now);
			GPIO_ClearInt(RADIO_CH7_PORT, _BIT(RADIO_CH7_PIN));
		}
	}

	if(GPIO_GetIntStatus(RADIO_CH8_PORT, RADIO_CH8_PIN, RISING_EDGE)){
		radio_channel(RADIO_CH8, 0, now);
		GPIO_ClearInt(RADIO_CH8_PORT, _BIT(RADIO_CH8_PIN));
	}
	else{
		if(GPIO_GetIntStatus(RADIO_CH8_PORT, RADIO_CH8_PIN, FALLING_EDGE)){
			radio_channel(RADIO_CH8, 1, now);
			GPIO_ClearInt(RADIO_CH8_PORT, _BIT(RADIO_CH8_PIN));
		}
	}
}

void radio_init(void){
	PINSEL_CFG_Type pin;

	/** Radio **************************/
	pin.Funcnum = PINSEL_FUNC_0;
	pin.Pinmode = PINSEL_PINMODE_TRISTATE;
	pin.OpenDrain = PINSEL_PINMODE_REPEATER;

	pin.Portnum = PINSEL_PORT_0;
	pin.Pinnum  = RADIO_CH2_PIN;
	PINSEL_ConfigPin(&pin);
	pin.Pinnum  = RADIO_CH6_PIN;
	PINSEL_ConfigPin(&pin);
	pin.Pinnum  = RADIO_CH7_PIN;
	PINSEL_ConfigPin(&pin);
	pin.Pinnum  = RADIO_CH8_PIN;
	PINSEL_ConfigPin(&pin);

	GPIO_SetDir(0, _BIT(RADIO_CH2_PIN) | _BIT(RADIO_CH6_PIN) |
			_BIT(RADIO_CH7_PIN) | _BIT(RADIO_CH8_PIN), 0);

	pin.Portnum = PINSEL_PORT_2;
	pin.Pinnum  = RADIO_CH1_PIN;
	PINSEL_ConfigPin(&pin);
	pin.Pinnum  = RADIO_CH3_PIN;
	PINSEL_ConfigPin(&pin);
	pin.Pinnum  = RADIO_CH4_PIN;
	PINSEL_ConfigPin(&pin);
	pin.Pinnum  = RADIO_CH5_PIN;
	PINSEL_ConfigPin(&pin);

	GPIO_SetDir(2, _BIT(RADIO_CH1_PIN) | _BIT(RADIO_CH3_PIN) |
			_BIT(RADIO_CH4_PIN) | _BIT(RADIO_CH5_PIN), 0);

}

inline uint32_t radio_channel(RADIO_CH_t Channel, uint32_t Edge, uint32_t Time){
	if((Channel > RADIO_NUM_CH) || (Edge > 1)){
		return 0;
	}
	// 0 = rising
	if(Edge == 0){
		// set PPMRiseTime
		RadioRiseTime[Channel] = Time;
	}
	else{
		// falling
		RadioValues[Channel] = (Time - RadioRiseTime[Channel]) >> 8;

		TotalReadings++;
		if((RadioValues[Channel] < (RADIO_MIN_CH_VALUE - 200)) || (RadioValues[Channel] > (RADIO_MAX_CH_VALUE + 200))){
			FailledReadings++;
		}
	}
	return 1;
}


inline int16_t radio_get_channel(RADIO_CH_t ChannelNum){
	// se o stick ta maior q o deadzone
	if(RadioValues[ChannelNum] - RadioOffsets[ChannelNum] > RADIO_STICK_DEADZONE){
		return (RadioValues[ChannelNum] - RadioOffsets[ChannelNum]);
	}
	else{
		// se o stick ta menor q o -deadzone
		if(RadioValues[ChannelNum] - RadioOffsets[ChannelNum] < -RADIO_STICK_DEADZONE){
			return (RadioValues[ChannelNum] - RadioOffsets[ChannelNum]);
		}
	}
	// se o cara nao ta mexendo no stick
	return 0;
}

inline int16_t radio_get_raw(RADIO_CH_t ChannelNum){
	return (RadioValues[ChannelNum]);
}
