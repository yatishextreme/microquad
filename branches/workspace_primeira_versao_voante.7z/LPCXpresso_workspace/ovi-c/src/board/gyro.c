/*
 * gyro.c
 *
 *  Created on: Apr 24, 2012
 *      Author: fanl
 */
#include "l3g4200d_driver.h"
#include "lpc17xx_clkpwr.h"
#include "lpc17xx_pinsel.h"
#include "ssp.h"

void gyro_Init(void){

	PINSEL_CFG_Type pin;

	/** L3G4200D Pins *************************/
	/* SSP0 */
	pin.Funcnum = PINSEL_FUNC_3;
	pin.Pinmode = PINSEL_PINMODE_PULLUP;
	pin.OpenDrain = PINSEL_PINMODE_NORMAL;
	pin.Portnum = PINSEL_PORT_1;
	pin.Pinnum  = PINSEL_PIN_23;
	PINSEL_ConfigPin(&pin);

	pin.Pinnum  = PINSEL_PIN_24;
	PINSEL_ConfigPin(&pin);

	pin.Funcnum = PINSEL_FUNC_2;
	pin.Portnum = PINSEL_PORT_0;
	pin.Pinnum  = PINSEL_PIN_15;
	PINSEL_ConfigPin(&pin);

	pin.Funcnum = PINSEL_FUNC_2;
	pin.Pinnum  = PINSEL_PIN_16;
	PINSEL_ConfigPin(&pin);


	SSP0Init();

	SetODR_G(ODR_400Hz_BW_20);
	SetFullScale_G(FULLSCALE_500);
	SetMode_G(NORMAL);
	SetBDU_G(ENABLE);
	SetHPFMode_G(HPM_AUTORESET_INT);
	SetHPFCutOFF_G(HPFCF_9);
	HPFEnable_G(MEMS_ENABLE);
	SetOutputDataAndFifoFilters_G(HPF);
	SetIntPinMode_G(PUSH_PULL);
	SetAxis_G(X_ENABLE | Y_ENABLE | Z_ENABLE);

}

void gyro_ReadAxes(int32_t GyroValues[3]) {
	GetAngRateRaw_G(GyroValues);
}
