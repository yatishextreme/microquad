
#include "lpc_types.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_pwm.h"

#include "motor.h"

const int MOTOR_MIN	=	13300;
const int MOTOR_MAX	=	24100;

void motor_init(){
	int8_t temp;
	PWM_TIMERCFG_Type PWMCfgDat;
	PWM_MATCHCFG_Type PWMMatchCfgDat;
	PINSEL_CFG_Type PinCfg;

	PWMCfgDat.PrescaleOption = PWM_TIMER_PRESCALE_TICKVAL;
	PWMCfgDat.PrescaleValue = 4;

	PWM_Init(LPC_PWM1, PWM_MODE_TIMER, (void *) &PWMCfgDat);

	PinCfg.Funcnum = 1;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 2;

	for (temp = 0; temp < 6; temp++){
		PinCfg.Pinnum = temp;
		PINSEL_ConfigPin(&PinCfg);
	}

	PWM_MatchUpdate(LPC_PWM1, 0, 31250, PWM_MATCH_UPDATE_NOW);

	PWMMatchCfgDat.IntOnMatch = DISABLE;
	PWMMatchCfgDat.MatchChannel = 0;
	PWMMatchCfgDat.ResetOnMatch = ENABLE;
	PWMMatchCfgDat.StopOnMatch = DISABLE;
	PWM_ConfigMatch(LPC_PWM1, &PWMMatchCfgDat);

	/* Edge setting ------------------------------------ */
	PWM_ChannelConfig(LPC_PWM1, 1, PWM_CHANNEL_SINGLE_EDGE);
	PWM_ChannelConfig(LPC_PWM1, 2, PWM_CHANNEL_SINGLE_EDGE);
	PWM_ChannelConfig(LPC_PWM1, 3, PWM_CHANNEL_SINGLE_EDGE);
	PWM_ChannelConfig(LPC_PWM1, 4, PWM_CHANNEL_SINGLE_EDGE);
	PWM_ChannelConfig(LPC_PWM1, 5, PWM_CHANNEL_SINGLE_EDGE);
	PWM_ChannelConfig(LPC_PWM1, 6, PWM_CHANNEL_SINGLE_EDGE);

	/* Match value setting ------------------------------------ */
	PWM_MatchUpdate(LPC_PWM1, 1, MOTOR_MIN, PWM_MATCH_UPDATE_NOW);
	PWM_MatchUpdate(LPC_PWM1, 2, MOTOR_MIN, PWM_MATCH_UPDATE_NOW);
	PWM_MatchUpdate(LPC_PWM1, 3, MOTOR_MIN, PWM_MATCH_UPDATE_NOW);
	PWM_MatchUpdate(LPC_PWM1, 4, MOTOR_MIN, PWM_MATCH_UPDATE_NOW);
	PWM_MatchUpdate(LPC_PWM1, 5, MOTOR_MIN, PWM_MATCH_UPDATE_NOW);
	PWM_MatchUpdate(LPC_PWM1, 6, MOTOR_MIN, PWM_MATCH_UPDATE_NOW);

	/* Match option setting ------------------------------------ */
	PWMMatchCfgDat.IntOnMatch = DISABLE;
	PWMMatchCfgDat.MatchChannel = temp;
	PWMMatchCfgDat.ResetOnMatch = DISABLE;
	PWMMatchCfgDat.StopOnMatch = DISABLE;
	for(temp = 1; temp < 6; temp++)
	{
		PWM_ConfigMatch(LPC_PWM1, &PWMMatchCfgDat);
	}
	/* Enable PWM Channel Output ------------------------------------ */
	/* Channel 1 */
	PWM_ChannelCmd(LPC_PWM1, 1, ENABLE);
	/* Channel 2 */
	PWM_ChannelCmd(LPC_PWM1, 2, ENABLE);
	/* Channel 3 */
	PWM_ChannelCmd(LPC_PWM1, 3, ENABLE);
	/* Channel 4 */
	PWM_ChannelCmd(LPC_PWM1, 4, ENABLE);
	/* Channel 5 */
	PWM_ChannelCmd(LPC_PWM1, 5, ENABLE);
	/* Channel 6 */
	PWM_ChannelCmd(LPC_PWM1, 6, ENABLE);

	/* Reset and Start counter */
	PWM_ResetCounter(LPC_PWM1);
	PWM_CounterCmd(LPC_PWM1, ENABLE);

	/* Start PWM now */
	PWM_Cmd(LPC_PWM1, ENABLE);
}

void set_motor_output(int32_t Values[6]){
	PWM_MatchUpdate(LPC_PWM1, 1, constrain(Values[0], MOTOR_MIN, MOTOR_MAX), PWM_MATCH_UPDATE_NEXT_RST);
	PWM_MatchUpdate(LPC_PWM1, 2, constrain(Values[1], MOTOR_MIN, MOTOR_MAX), PWM_MATCH_UPDATE_NEXT_RST);
	PWM_MatchUpdate(LPC_PWM1, 3, constrain(Values[2], MOTOR_MIN, MOTOR_MAX), PWM_MATCH_UPDATE_NEXT_RST);
	PWM_MatchUpdate(LPC_PWM1, 4, constrain(Values[3], MOTOR_MIN, MOTOR_MAX), PWM_MATCH_UPDATE_NEXT_RST);
	PWM_MatchUpdate(LPC_PWM1, 5, constrain(Values[4], MOTOR_MIN, MOTOR_MAX), PWM_MATCH_UPDATE_NEXT_RST);
	PWM_MatchUpdate(LPC_PWM1, 6, constrain(Values[5], MOTOR_MIN, MOTOR_MAX), PWM_MATCH_UPDATE_NEXT_RST);
}


