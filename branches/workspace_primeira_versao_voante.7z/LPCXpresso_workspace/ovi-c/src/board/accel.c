/*
 * rdwr.c
 *
 *  Created on: Apr 23, 2012
 *      Author: fanl
 */
#include "accel.h"

#include "lpc17xx_pinsel.h"
#include "i2c.h"
#include "lsm303dlhc_driver.h"

/* I2C inputs and configs */
#define LSM_I2C		1
#define M_RDWR_BIT			0x80

extern volatile uint8_t I2CMasterBuffer[I2C_PORT_NUM][BUFSIZE];
extern volatile uint8_t I2CSlaveBuffer[I2C_PORT_NUM][BUFSIZE];
extern volatile uint32_t I2CReadLength[I2C_PORT_NUM];
extern volatile uint32_t I2CWriteLength[I2C_PORT_NUM];

int32_t i2c_lsmRead(uint8_t sensor, uint8_t reg, uint8_t *p8, int32_t nBytes)
{
	if(nBytes<0 || nBytes>BUFSIZE) return ERROR;

	int32_t i;
	for(i=0; i<BUFSIZE || i<nBytes; i++){
		I2CSlaveBuffer[LSM_I2C][i]=0;
	}

	I2CWriteLength[LSM_I2C] = 2;
	I2CReadLength[LSM_I2C] = nBytes;
	I2CMasterBuffer[LSM_I2C][0] = sensor;
	I2CMasterBuffer[LSM_I2C][1] = reg | (nBytes==1?0:M_RDWR_BIT);		/* address */
	I2CMasterBuffer[LSM_I2C][2] = sensor | RD_BIT;

	int32_t result;
	result = I2CEngine(LSM_I2C);
	if(result != I2C_OK) return ERROR;

	i=0;
	while(nBytes--){
	 *p8++ = I2CSlaveBuffer[LSM_I2C][i++];
	}

	return SUCCESS;
}

int32_t i2c_lsmWrite(uint8_t sensor, uint8_t reg, uint8_t data)
{
	I2CSlaveBuffer[LSM_I2C][0]=0;

	I2CWriteLength[LSM_I2C] = 3;
	I2CReadLength[LSM_I2C] = 0;
	I2CMasterBuffer[LSM_I2C][0] = sensor;
	I2CMasterBuffer[LSM_I2C][1] = reg;		/* address */
	I2CMasterBuffer[LSM_I2C][2] = data;

	int32_t result;
	result = I2CEngine(LSM_I2C);
	if(result != I2C_OK) return ERROR;

	return SUCCESS;
}

#define LSM303_ID	0x00333448

void magacc_Init() {
	int32_t v;
	int32_t i32;
	uint8_t *p8;

	PINSEL_CFG_Type pin;

	/** LSM303 Pins *************************/
	/* I2C1 */
	pin.Funcnum = PINSEL_FUNC_3;
	pin.Pinmode = PINSEL_PINMODE_TRISTATE;
	pin.OpenDrain = PINSEL_PINMODE_NORMAL;
	pin.Portnum = PINSEL_PORT_0;
	pin.Pinnum  = PINSEL_PIN_0;
	PINSEL_ConfigPin(&pin);

	pin.Pinnum  = PINSEL_PIN_1;
	PINSEL_ConfigPin(&pin);

	I2C1Init();

	i32 = 0;
	p8 = (uint8_t*)&i32;
	v = i2c_lsmRead(MAG_I2C_ADDRESS, IRA_REG_M, p8, 3);

	v=0;
	v += SetODR(ODR_100Hz);
	v += SetODR_M(ODR_30Hz_M);
	v += SetMode(NORMAL);
	v += SetModeMag(CONTINUOUS_MODE);
	v += SetFullScale(FULLSCALE_4);
	v += SetGainMag(GAIN_400_M);
	v += SetAxis(X_ENABLE | Y_ENABLE | Z_ENABLE);
}

void acc_ReadAxes(volatile int AccValues[3]) {
	GetAccAxesRaw(AccValues);
}
