/*
 * board.c
 *
 *  Created on: May 11, 2012
 *      Author: fanl
 */

#include "board.h"
#include "gyro.h"
#include "accel.h"
#include "interruptions.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_clkpwr.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_timer.h"
#include "lpc17xx_i2c.h"

void board_init(void){

	gyro_Init();
	magacc_Init();
	interruptions_Setup(); //Enable interruptions

	// leds
	LPC_GPIO1->FIODIR |= (LED1 | LED2 | LED3);

}

void process_leds(void){
	static char leds_step = 0;
	static int32_t led_delay = 0;

	led_delay--;

	switch(leds_step){
		case 0:
			// apaga todos os leds
			LPC_GPIO1->FIOPIN |= (LED1 | LED2 | LED3);
			leds_step++;
			break;

		case 1:
			if(led_delay < 0){
				// acende o primeiro e delay 1 parte
				LPC_GPIO1->FIOPIN &= ~LED1;
				led_delay = LED_BLINK_TIME_UNIT;
				leds_step++;
			}
			break;

		case 2:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN &= ~LED2;
				led_delay = LED_BLINK_TIME_UNIT;
				leds_step++;
			}
			break;

		case 3:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN &= ~LED3;
				led_delay = LED_BLINK_TIME_UNIT;
				leds_step++;
			}
			break;

		case 4:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN |= LED3;
				led_delay = LED_BLINK_TIME_UNIT;
				leds_step++;
			}
			break;

		case 5:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN |= LED2;
				led_delay = LED_BLINK_TIME_UNIT;
				leds_step++;
			}
			break;

		case 6:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN |= LED1;
				led_delay = LED_BLINK_TIME_UNIT;
				leds_step++;
			}
			break;

		case 7:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN &= ~LED1;
				led_delay = LED_BLINK_TIME_UNIT;
				leds_step++;
			}
			break;

		case 8:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN &= ~LED2;
				led_delay = LED_BLINK_TIME_UNIT;
				leds_step++;
			}
			break;

		case 9:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN |= LED2;
				leds_step++;
				led_delay = LED_BLINK_TIME_UNIT;
			}
			break;

		case 10:
			if(led_delay < 0){
				LPC_GPIO1->FIOPIN |= LED1;
				led_delay = LED_BLINK_TIME_UNIT * 10;
				leds_step = 1;
			}

			break;

	}
}


