#ifndef RADIO_H_
#define RADIO_H_

#define RADIO_CH2_PIN			(22)		//P0.22
#define RADIO_CH6_PIN			(3)			//P0.3
#define RADIO_CH7_PIN			(2)			//P0.2
#define RADIO_CH8_PIN			(17)		//P0.17

#define RADIO_CH1_PIN			(10)		//P2.10
#define RADIO_CH3_PIN			(8)			//P2.8
#define RADIO_CH4_PIN			(7)			//P2.7
#define RADIO_CH5_PIN			(6)			//P2.6

#define RADIO_CH2_PORT			0			//P0.22
#define RADIO_CH6_PORT			0			//P0.3
#define RADIO_CH7_PORT			0			//P0.2
#define RADIO_CH8_PORT			0			//P0.17

#define RADIO_CH1_PORT			2			//P2.10
#define RADIO_CH3_PORT			2			//P2.8
#define RADIO_CH4_PORT			2			//P2.7
#define RADIO_CH5_PORT			2			//P2.6

/******************** PERSONAL DEFINES - radio turnigy 9X *******************************/
#define __1khz_tone_period		12500 // 1ms

#define RADIO_MIN_CH_VALUE		(207)
#define RADIO_MAX_CH_VALUE		(376)

#define RADIO_MIN_CH_THRESHOLD	(RADIO_MIN_CH_VALUE + 7)
#define RADIO_MAX_CH_THRESHOLD	(RADIO_MAX_CH_VALUE - 7)

#define RADIO_STICK_DEADZONE	3

/*****************************************************************************************/

enum{
	ROLL_RC_CH			= 1,// RadioValue[1]
	YAW_RC_CH			,	// RadioValue[2]
	THROTTLE_RC_CH		,	// RadioValue[3]
	PITCH_RC_CH			,	// RadioValue[4]
};

typedef enum {
	RADIO_CH1 = 0,
	RADIO_CH2,
	RADIO_CH3,
	RADIO_CH4,
	RADIO_CH5,
	RADIO_CH6,
	RADIO_CH7,
	RADIO_CH8,
	RADIO_NUM_CH,
}RADIO_CH_t;

// var
extern int32_t RadioValues[RADIO_NUM_CH];
extern int32_t RadioOffsets[RADIO_NUM_CH];

extern int32_t RadioMinVal;
extern int32_t RadioMaxVal;

// function
void ppm_input_process(void);
void radio_init(void);
int32_t radio_offset_channel(RADIO_CH_t ChannelNum, uint16_t NumSamples);
uint32_t radio_channel(RADIO_CH_t Channel, uint32_t Edge, uint32_t Time);

int16_t radio_get_channel(RADIO_CH_t ChannelNum);
int16_t radio_get_raw(RADIO_CH_t ChannelNum);

#endif /* RADIO_H_ */
