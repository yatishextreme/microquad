/*
 * board.h
 *
 *  Created on: May 14, 2012
 *      Author: fanl
 */

#ifndef BOARD_H_
#define BOARD_H_

#include "target.h"

#define LED1	(1<<10)
#define LED2	(1<<14)
#define LED3	(1<<15)

#define LED_BLINK_TIME_UNIT 25

void board_init(void);
void process_leds(void);

#endif /* BOARD_H_ */
