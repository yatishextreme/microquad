/*
 * mag.h
 *
 *  Created on: Apr 23, 2012
 *      Author: fanl
 */

#ifndef ACCEL_H_
#define ACCEL_H_

void magacc_Init();
void acc_ReadAxis(volatile int AccValues[3]);

#endif /* ACCEL_H_ */
