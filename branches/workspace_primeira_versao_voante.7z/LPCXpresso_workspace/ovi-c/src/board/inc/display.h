#ifndef NOKIA6100_H_
#define NOKIA6100_H_

//
// ** LCD6100.h ***************************************************
// **                                                            **
// **       Biblioteca do display  gráfico colorido Nokia 6100.  **
// **    Esta biblioteca foi  configurada como 8bits/pixel para  **
// **    operações alfanuméricas (display "texto") e pode colar  **
// **    imagens em 12bits/pixel ou 8bits/pixel.                 **
// **                                                            **
// ****************************************(C) by JCLima, 2010/2 **
//
//                       +----+
//      0                |    | 131   <--- CONECTOR VERDE S1D15G00
//     +-----------------+    +----+       CONECTOR AMARELO PCF8833
//    0|  ---X--->                 |                     Nokia 6100
//     | |                         |                     Nokia 7250
//     | |    Color: BBGGGRRR      |                     Nokia 2600
//     | Y                         |
//     | |       >-->-->-->-->    |       INICIALIZAÇÃO
//     | |                 /       |
//     | V               /         | Memory Data Access Control
//     |               /           |            0x08
//     |             /             |             |
//     |           /               |             |
//     |         /-->-->-->-->     |<------------+
//  131|                           |
//     +---------------------------+
//
//
//
//
//    avacalhado por flavio em 20/11/2010
//    - lcd_drawcircle(...);
//    - lcd_drawline(...);
//    - otimizacao do codigo:
//        - funcao n6100_sendcommand e n6100_senddata viraram uma so: n6100_send(char,char)
//        - o codigo foi reduzido em aproximadamente 20% de tamanho
//        - fonts.h foi movido para lcd6100.h
//        - prototipos foram movidos para lcd6100.h
//        - cor ORANGE e LIME foram adicionadas
//
//    continuacao flavio 24/7/2011
//        void lcd_drawpoint(unsigned char x, unsigned char y, int color)
//
//    continuacao flavio 23/10/2011
//        adicionado typedef COLOR
//        cor ORANGE foi removida
//
//	  continuacao flavio 06/05/2012
//		  typedef color foi removido pq nao servia pra nada
//		  toda lib adaptada para LPC17xx utilizando LPCXpresso
//
// TODO:
//    se quiser economizar memoria, transformar o display em preto e branco
//	  e trabalhar soh com 0xFF e 0x00 para as cores, isso vai economizar bastante
//    nas imagens.
//

// Display Gráfico Color
//
#define    BLACK           0x00
#define    GRAY            0x49
#define    MARROON         0x40
#define    OLIVE           0x6c
#define    GREEN           0x08
#define    TEAL            0x09
#define    NAVY            0x01
#define    PURPLE          0x41
#define    MAGENTA         0xe3
#define    BLUE            0x03
#define    AQUA            0x1f
#define    LIME            0x1c
#define    YELLOW          0xfc
#define    RED             0xe0
#define    SILVER          0xb6
#define    WHITE           0xff
#define    CYAN            0x1F

#define LCD_DEFAULT_BACKCOLOR 	WHITE
#define LCD_DEFAULT_FORECOLOR 	BLACK

#define LCD_PORT_NUM		1

#define LCD_RESX            4 // P1.4
#define LCD_SDA             1 // p1.1
#define LCD_SCLK            0 // P1.0
#define LCD_CSX             8 // P1.8

#define LCD_BKLIGHT			22 // P1.22

#define LCD_NCHAR       21
#define LCD_NLINE       16

#define LCD_DIREITO     0x48
#define LCD_INVERTIDO   0x00

// ****************************************************************
// ** V A R I Á V E I S  D O  D I S P L A Y                      **
// ****************************************************************
//
typedef struct{
	unsigned char LineCount;
	unsigned char CharCount;
	unsigned char BackColor;
	unsigned char ForeColor;
}NokiaDisplay_t;

extern NokiaDisplay_t NokiaDisplay;

//
// ****************************************************************
// ** P R O T Ó T I P O S                                        **
// ****************************************************************
//

/* system tick ja devera estar rodando quando esta funcao for chamada */
char lcd_init(unsigned char color);

void lcd_setcolor(unsigned char foreground_color, unsigned char background_color);
void n6100_send(unsigned char data, unsigned char cmd);
void lcd_clear(unsigned char color);
void n6100_sendcom1(unsigned char comm, unsigned char dat);
void n6100_sendcom2(unsigned char comm, unsigned char dat1, unsigned char dat2);
void lcd_drawpoint(unsigned char x, unsigned char y, unsigned char color);
void lcd_fillrect(unsigned char x, unsigned char y, unsigned char lx, unsigned char ly, unsigned char color);
void lcd_putlogo(unsigned char x, unsigned char y, unsigned char lx, unsigned char ly, unsigned char p[]);
void lcd_newline(void);
void lcd_goto(unsigned char x, unsigned char y);
void lcd_wrchar(unsigned char c);
void lcd_putchar(unsigned char c);
void lcd_puts(char *s);
void lcd_drawcircle(unsigned int x, unsigned int y, unsigned int radius, unsigned char color, int width);
void lcd_drawline(int x0, int y0, int x1, int y1, unsigned char color);
void lcd_drawprogressbar(int x0, int y0, int x1, int y1, unsigned char color, unsigned char colorprogress, int percent);
void lcd_putdot(int from, int to);

void lcd_backlight_on(void);
void lcd_backlight_off(void);

#endif // NOKIA6100_H_
