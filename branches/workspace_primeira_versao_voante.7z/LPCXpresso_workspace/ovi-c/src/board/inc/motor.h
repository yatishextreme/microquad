#ifndef MOTOR_H
#define MOTOR_H

// radio values << 6
extern const int MOTOR_MIN;
extern const int MOTOR_MAX;

void motor_init(void);
void set_motor_output(int32_t Values[6]);

#endif// MOTOR_H
