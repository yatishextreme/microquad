/*
 * gyro.h
 *
 *  Created on: Apr 24, 2012
 *      Author: fanl
 */

#ifndef GYRO_H_
#define GYRO_H_

void gyro_Init();
void gyro_ReadAxes();

#endif /* GYRO_H_ */
