/*
 * interruptions.c
 *
 *  Created on: May 16, 2012
 *      Author: fanl
 */

#include "lpc17xx_gpio.h"
#include "lpc17xx_timer.h"
#include "lpc17xx_clkpwr.h"

#include "board.h"
#include "radio.h"
#include "motor.h"
#include "control.h"
#include "quadcopter.h"

void interruptions_Setup(void){

	NVIC_SetPriority(TIMER2_IRQn, 1); // 400hz interruption
	NVIC_SetPriority(EINT3_IRQn, 0); //GPIO

	// Timer structures /
	TIM_TIMERCFG_Type timer;
	TIM_MATCHCFG_Type match;/*
*/
	/**** TIMER2 Interruptions Configurations *******************************/
	CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_TIMER2, CLKPWR_PCLKSEL_CCLK_DIV_4); //timer2 clk = 25MHz
	timer.PrescaleOption = TIM_PRESCALE_TICKVAL;
	timer.PrescaleValue = 500; //Timer counter freq = 50kHz
	TIM_Init(LPC_TIM2, TIM_TIMER_MODE, &timer);
	match.IntOnMatch = ENABLE;
	match.ExtMatchOutputType = TIM_EXTMATCH_NOTHING;
	match.MatchChannel = 0;
	match.MatchValue = 124; //400Hz
	match.ResetOnMatch = ENABLE;
	TIM_ConfigMatch(LPC_TIM2, &match);

	TIM_Cmd(LPC_TIM2, ENABLE);
	NVIC_EnableIRQ(TIMER2_IRQn);

	/**** GPIO Interruptions Configurations *******************************/

	/* PCLK_GPIOINT = 100MHz */
	CLKPWR_SetPCLKDiv(CLKPWR_PCLKSEL_GPIOINT, CLKPWR_PCLKSEL_CCLK_DIV_1);

	/* Enable Radio IO Interruptions */
	GPIO_IntCmd(2, _BIT(RADIO_CH1_PIN) | _BIT(RADIO_CH3_PIN) |
			_BIT(RADIO_CH4_PIN) | _BIT(RADIO_CH5_PIN), RISING_EDGE);

	GPIO_IntCmd(0, _BIT(RADIO_CH2_PIN) | _BIT(RADIO_CH6_PIN) |
			_BIT(RADIO_CH7_PIN) | _BIT(RADIO_CH8_PIN), RISING_EDGE);

	GPIO_IntCmd(2, _BIT(RADIO_CH1_PIN) | _BIT(RADIO_CH3_PIN) |
			_BIT(RADIO_CH4_PIN) | _BIT(RADIO_CH5_PIN), FALLING_EDGE);

	GPIO_IntCmd(0, _BIT(RADIO_CH2_PIN) | _BIT(RADIO_CH6_PIN) |
			_BIT(RADIO_CH7_PIN) | _BIT(RADIO_CH8_PIN), FALLING_EDGE);


	NVIC_EnableIRQ(EINT3_IRQn);
}

void TIMER2_IRQHandler(void)
{
	// para testar a freq no oscilos
	//LPC_GPIO1->FIOPIN ^= ((1<<10) | (1<<14) | (1<<15));

	refresh_IMU();

	process_leds();

	LPC_TIM2->IR |= TIM_IR_CLR(TIM_MR0_INT);
	LPC_TIM2->TCR  = 1;
}

// RADIO INTERRUPTION
void EINT3_IRQHandler(void)
{
	ppm_input_process();
}
