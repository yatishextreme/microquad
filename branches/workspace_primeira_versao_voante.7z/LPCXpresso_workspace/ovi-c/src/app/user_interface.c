#include "lpc_types.h"

#include "delay.h"
#include "display.h"
#include "resources.h"
#include "gyro.h"
#include "accel.h"
#include "usefullibs.h"
#include "menu.h"
#include "radio.h"
#include "quadcopter.h"
#include "motor.h"
#include "user_interface.h"

MENU_MANAGER *MenuMgr;

void user_interface_init(void){
	lcd_init(LCD_DEFAULT_BACKCOLOR);
	lcd_backlight_on();

	lcd_puts(FIRM_VERSION);
	delay_ms(3000);

	// inicializa menus
	MenuMgr = generate_menus();
	MenuMgr->CurrentMenu = INDEX_MAIN_MENU;

	//MenuMgr->CurrentMenu = INDEX_RADIO_MENU;
	menu_draw((MENU*)list_get_data(MenuMgr->Menus, MenuMgr->CurrentMenu), 1);
}

void process_user_entry(MENU_MANAGER* oMenuMgr){
	// tem q fazer isso pra facilitar a vida do sugeito
	// ainda bem q essas listas sao bem pequenas, media de 8 itens por lista
	// o problema eh q as listas tao inplementadas pra varrer iniciando sempre do node first, isso eh ruim
	// pq se o node eh o ultimo ele vai varrer toda a lista. Se ela iniciasse do fim ela pegaria de primeira
	MENU* SelectedMenu;
	Item* SelectedItem;

	switch(oMenuMgr->CurrentMenu){
		case INDEX_MOTOR_MENU:
			set_motor_output(Quadcopter.MotorOutput);
			break;

		case INDEX_CONTROL_MENU:
			break;

		case INDEX_SENSOR_MENU:
			refresh_IMU();
			break;

		case INDEX_FILTER_MENU:
			break;

		case INDEX_DOWN_CFG_MENU:
			break;

		case INDEX_MAIN_MENU:
			SelectedMenu = (MENU*)list_get_data(oMenuMgr->Menus, oMenuMgr->CurrentMenu);
			SelectedItem = list_get_data(SelectedMenu->Items, SelectedMenu->SelectedItem);

			if(SelectedItem->Name == _str_FLY){
				// muda Quad.Step para fly
				Quadcopter.CurrentStep = QUAD_STEP_PRE_FLIGHT;
			}
			else{
				if(SelectedItem->Name == _str_BAT_TEST){
					// entra na telinha de bat test
					// talvez colocar um menu especial pra esse
				}
			}
			break;

		case INDEX_SAVE_LOG_MENU:
			break;

		case INDEX_STATUS_MENU:
			break;

		case INDEX_RADIO_MENU:
			break;
	}
}

MENU_MANAGER* generate_menus(void){

	List* MenuList = list_create((void*)(menu_create("Main Menu",
									create_item(_str_FLY, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_MAIN_MENU),
									&menu_janela_size_large, 0, 0, &menu_arrow_left, 0)),
								"MenuList");

	// exemplo add item no primeiro menu da lista de menus
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_MOTORS, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_MOTOR_MENU));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_RADIO, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_RADIO_MENU));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_SENSORS, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_SENSOR_MENU));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_CONTROL, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_CONTROL_MENU));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_FILTERS, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_FILTER_MENU));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_STATUS, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_STATUS_MENU));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_BAT_TEST, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_MAIN_MENU));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_SAVE_LOG, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_SAVE_LOG_MENU));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MAIN_MENU), create_item(_str_DOWN_CFG, ITEMTYPE_SUBMENU, 0,0,0,0,INDEX_DOWN_CFG_MENU));

	// exemplo de add novo menu
	// menu motores
	list_insert(MenuList, (void*)(menu_create(_str_Motors, create_item("M1", ITEMTYPE_VALUE_BAR_RW, (int*)&MOTOR_MIN,(int*)&MOTOR_MAX,(int32_t*)&_250,(int32_t*)&(Quadcopter.MotorOutput[0]),-1),
			&menu_janela_size_large, &menu_bar_position_center, &menu_value_position_right, &menu_arrow_left, &menu_bar_lenght_medium)), MenuList->Lenght);
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MOTOR_MENU), create_item("M2", ITEMTYPE_VALUE_BAR_RW, (int*)&MOTOR_MIN,(int*)&MOTOR_MAX,(int32_t*)&_250,(int32_t*)&(Quadcopter.MotorOutput[1]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MOTOR_MENU), create_item("M3", ITEMTYPE_VALUE_BAR_RW, (int*)&MOTOR_MIN,(int*)&MOTOR_MAX,(int32_t*)&_250,(int32_t*)&(Quadcopter.MotorOutput[2]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MOTOR_MENU), create_item("M4", ITEMTYPE_VALUE_BAR_RW, (int*)&MOTOR_MIN,(int*)&MOTOR_MAX,(int32_t*)&_250,(int32_t*)&(Quadcopter.MotorOutput[3]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MOTOR_MENU), create_item("M5", ITEMTYPE_VALUE_BAR_RW, (int*)&MOTOR_MIN,(int*)&MOTOR_MAX,(int32_t*)&_250,(int32_t*)&(Quadcopter.MotorOutput[4]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_MOTOR_MENU), create_item("M6", ITEMTYPE_VALUE_BAR_RW, (int*)&MOTOR_MIN,(int*)&MOTOR_MAX,(int32_t*)&_250,(int32_t*)&(Quadcopter.MotorOutput[5]),-1));

	// menu radio
	list_insert(MenuList, (void*)(menu_create(_str_Radio, create_item("CH1", ITEMTYPE_VALUE_BAR_R, (int*)&RadioMinVal,(int*)&RadioMaxVal,(int*)&_One,(int32_t*)&RadioValues[0],-1),
			&menu_janela_size_large, &menu_bar_position_center, &menu_value_position_right, &menu_arrow_left, &menu_bar_lenght_medium)), MenuList->Lenght);
	menu_add_item((MENU*) list_get_data(MenuList, INDEX_RADIO_MENU),create_item("CH2", ITEMTYPE_VALUE_BAR_R, (int*)&RadioMinVal,(int*)&RadioMaxVal,(int*)&_One,(int32_t*)&RadioValues[1],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("CH3", ITEMTYPE_VALUE_BAR_R, (int*)&RadioMinVal,(int*)&RadioMaxVal,(int*)&_One,(int32_t*)&RadioValues[2],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("CH4", ITEMTYPE_VALUE_BAR_R, (int*)&RadioMinVal,(int*)&RadioMaxVal,(int*)&_One,(int32_t*)&RadioValues[3],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("CH5", ITEMTYPE_VALUE_BAR_R, (int*)&RadioMinVal,(int*)&RadioMaxVal,(int*)&_One,(int32_t*)&RadioValues[4],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("CH6", ITEMTYPE_VALUE_BAR_R, (int*)&RadioMinVal,(int*)&RadioMaxVal,(int*)&_One,(int32_t*)&RadioValues[5],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("CH7", ITEMTYPE_VALUE_BAR_R, (int*)&RadioMinVal,(int*)&RadioMaxVal,(int*)&_One,(int32_t*)&RadioValues[6],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("CH8", ITEMTYPE_VALUE_BAR_R, (int*)&RadioMinVal,(int*)&RadioMaxVal,(int*)&_One,(int32_t*)&RadioValues[7],-1));
	// offsets
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("OFF1", ITEMTYPE_VALUE_R, &RadioMinVal,&RadioMaxVal,(int*)&_One,(int32_t*)&RadioOffsets[0],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("OFF2", ITEMTYPE_VALUE_R, &RadioMinVal,&RadioMaxVal,(int*)&_One,(int32_t*)&RadioOffsets[1],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("OFF3", ITEMTYPE_VALUE_R, &RadioMinVal,&RadioMaxVal,(int*)&_One,(int32_t*)&RadioOffsets[2],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("OFF4", ITEMTYPE_VALUE_R, &RadioMinVal,&RadioMaxVal,(int*)&_One,(int32_t*)&RadioOffsets[3],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("OFF5", ITEMTYPE_VALUE_R, &RadioMinVal,&RadioMaxVal,(int*)&_One,(int32_t*)&RadioOffsets[4],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("OFF6", ITEMTYPE_VALUE_R, &RadioMinVal,&RadioMaxVal,(int*)&_One,(int32_t*)&RadioOffsets[5],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("OFF7", ITEMTYPE_VALUE_R, &RadioMinVal,&RadioMaxVal,(int*)&_One,(int32_t*)&RadioOffsets[6],-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_RADIO_MENU), create_item("OFF8", ITEMTYPE_VALUE_R, &RadioMinVal,&RadioMaxVal,(int*)&_One,(int32_t*)&RadioOffsets[7],-1));

	// menu sensores
	list_insert(MenuList, (void*)(menu_create(_str_Sensors, create_item("GyrR", ITEMTYPE_VALUE_R, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadIMU.GyroValues[INDEX_IMU_ROLL]),-1),
			&menu_janela_size_large, &menu_bar_position_center, &menu_value_position_right, &menu_arrow_left, &menu_bar_lenght_medium)), MenuList->Lenght);
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_SENSOR_MENU), create_item("GyrP", ITEMTYPE_VALUE_R, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadIMU.GyroValues[INDEX_IMU_PITCH]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_SENSOR_MENU), create_item("GyrY", ITEMTYPE_VALUE_R, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadIMU.GyroValues[INDEX_IMU_YAW]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_SENSOR_MENU), create_item("AccR", ITEMTYPE_VALUE_R, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadIMU.AccelValues[INDEX_IMU_ROLL]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_SENSOR_MENU), create_item("AccP", ITEMTYPE_VALUE_R, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadIMU.AccelValues[INDEX_IMU_PITCH]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_SENSOR_MENU), create_item("AccY", ITEMTYPE_VALUE_R, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadIMU.AccelValues[INDEX_IMU_YAW]),-1));

	// menu control
	list_insert(MenuList, (void*)(menu_create(_str_Control, create_item("RPMU", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.RollPID.GainMul[INDEX_PROPORTIONAL]),-1),
			&menu_janela_size_large, &menu_bar_position_center, &menu_value_position_right, &menu_arrow_left, &menu_bar_lenght_medium)), MenuList->Lenght);
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_CONTROL_MENU), create_item("RPDI", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.RollPID.GainDiv[INDEX_PROPORTIONAL]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_CONTROL_MENU), create_item("RIDI", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.RollPID.GainDiv[INDEX_INTEGRAL]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_CONTROL_MENU), create_item("PPMU", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.PitchPID.GainMul[INDEX_PROPORTIONAL]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_CONTROL_MENU), create_item("PPDI", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.PitchPID.GainDiv[INDEX_PROPORTIONAL]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_CONTROL_MENU), create_item("PIDI", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.PitchPID.GainDiv[INDEX_INTEGRAL]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_CONTROL_MENU), create_item("YPMU", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.YawPID.GainMul[INDEX_PROPORTIONAL]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_CONTROL_MENU), create_item("YPDI", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.YawPID.GainDiv[INDEX_PROPORTIONAL]),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_CONTROL_MENU), create_item("YIDI", ITEMTYPE_VALUE_RW, &MinInt,&MaxInt,(int*)&_One,(int32_t*)&(Quadcopter.QuadControl.YawPID.GainDiv[INDEX_INTEGRAL]),-1));

	// menu filters
	// gyro
	list_insert(MenuList, (void*)(menu_create(_str_Filters, create_item("GRMU", ITEMTYPE_VALUE_RW, (int*)&MinUInt,&MaxInt,(int*)&_One,(int*)&(Quadcopter.GyroFilter[INDEX_IMU_ROLL].Multiplier),-1),
			&menu_janela_size_large, &menu_bar_position_center, &menu_value_position_right, &menu_arrow_left, &menu_bar_lenght_medium)), MenuList->Lenght);
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("GRDI", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.GyroFilter[INDEX_IMU_ROLL].Divisor),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("GPMU", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.GyroFilter[INDEX_IMU_PITCH].Multiplier),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("GPDI", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.GyroFilter[INDEX_IMU_PITCH].Divisor),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("GPMU", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.GyroFilter[INDEX_IMU_YAW].Multiplier),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("GPDI", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.GyroFilter[INDEX_IMU_YAW].Divisor),-1));
	// motor
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("MFMU", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.MotorOutputFilter[MOTOR_FRONT].Multiplier),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("MFDI", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.MotorOutputFilter[MOTOR_FRONT].Divisor),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("MBMU", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.MotorOutputFilter[MOTOR_BACK].Multiplier),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("MBDI", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.MotorOutputFilter[MOTOR_BACK].Divisor),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("MRMU", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.MotorOutputFilter[MOTOR_RIGHT].Multiplier),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("MRDI", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.MotorOutputFilter[MOTOR_RIGHT].Divisor),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("MLMU", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.MotorOutputFilter[MOTOR_LEFT].Multiplier),-1));
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_FILTER_MENU), create_item("MLDI", ITEMTYPE_VALUE_RW, (int*)&MinUInt,(int*)&MaxInt,(int*)&_One,(int*)&(Quadcopter.MotorOutputFilter[MOTOR_LEFT].Divisor),-1));

	// menu status
	list_insert(MenuList, (void*)(menu_create(_str_Status, create_item("??", ITEMTYPE_SUBMENU, 0,0,0,0,-1),
			&menu_janela_size_large, 0, 0, &menu_arrow_left, 0)), MenuList->Lenght);

	// menu save log
	list_insert(MenuList, (void*)(menu_create(_str_Save_log, create_item("YES", ITEMTYPE_SUBMENU, 0,0,0,0,-1),
			&menu_janela_size_large, 0, 0, &menu_arrow_left, 0)), MenuList->Lenght);
	 menu_add_item((MENU*)list_get_data(MenuList, INDEX_SAVE_LOG_MENU), create_item("NO ", ITEMTYPE_SUBMENU, 0,0,0,0,-1));

	// menu download cfg
	list_insert(MenuList, (void*)(menu_create(_str_Down_config, create_item("USB ", ITEMTYPE_SUBMENU, 0,0,0,0,-1),
			&menu_janela_size_large, 0, 0, &menu_arrow_left, 0)), MenuList->Lenght);
	menu_add_item((MENU*)list_get_data(MenuList, INDEX_DOWN_CFG_MENU), create_item("SD CARD", ITEMTYPE_SUBMENU, 0,0,0,0,-1));

	// adiciona a lista de menus no menu manager
	return menu_mgr_create("MenuManager", MenuList);

}
