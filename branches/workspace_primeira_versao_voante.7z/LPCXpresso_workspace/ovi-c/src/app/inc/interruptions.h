/*
 * interruptions.h
 *
 *  Created on: May 21, 2012
 *      Author: fanl
 */

#ifndef INTERRUPTIONS_H_
#define INTERRUPTIONS_H_

void interruptions_Setup(void);

#endif /* INTERRUPTIONS_H_ */
