#ifndef _USER_INTERFACE_H
#define _USER_INTERFACE_H

#include "usefullibs.h"
#include "menu.h"

// defines, enum
#define FIRM_VERSION "OVI-C v1.1"

// ordem dos menus na list de menus
enum{
	INDEX_MAIN_MENU		= 0,	// MenuMgr->Menus[0]
	INDEX_MOTOR_MENU	,		// MenuMgr->Menus[1]
	INDEX_RADIO_MENU	,		// MenuMgr->Menus[2]
	INDEX_SENSOR_MENU	,		// MenuMgr->Menus[3]
	INDEX_CONTROL_MENU	,		// MenuMgr->Menus[4]
	INDEX_FILTER_MENU	,		// MenuMgr->Menus[5]
	INDEX_STATUS_MENU	,		// MenuMgr->Menus[6]
	INDEX_SAVE_LOG_MENU	,		// MenuMgr->Menus[7]
	INDEX_DOWN_CFG_MENU	,		// MenuMgr->Menus[8]
};

extern MENU_MANAGER *MenuMgr;

MENU_MANAGER* generate_menus();	// cria a lista de menus e itens dentro dos menus
void user_interface_init(void);
void process_user_entry(MENU_MANAGER* oMenuMgr);

#endif //_USER_INTERFACE_H
