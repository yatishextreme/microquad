#ifndef _NAVI_H
#define _NAVI_H

enum{
	INDEX_IMU_ROLL		,
	INDEX_IMU_PITCH		,
	INDEX_IMU_YAW		,
};

typedef struct{
	int32_t GyroValues[3];
	int32_t AccelValues[3];

	int32_t TempValues;
}IMU;

void IMU_init(IMU *oIMU);

#endif // _NAVI_H
