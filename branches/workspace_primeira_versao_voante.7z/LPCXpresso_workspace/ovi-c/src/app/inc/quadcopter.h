#ifndef _QUADCOPTER_H
#define _QUADCOPTER_H

#include "navigation.h"
#include "control.h"
#include "filter.h"

#define DEFAULT_GAIN_MUL_P_ROLL    13
#define DEFAULT_GAIN_MUL_D_ROLL    0
#define DEFAULT_GAIN_MUL_P_PITCH   13
#define DEFAULT_GAIN_MUL_D_PITCH   0
#define DEFAULT_GAIN_MUL_P_YAW     19
#define DEFAULT_GAIN_MUL_D_YAW     0
#define DEFAULT_GAIN_DIV_P_ROLL    0
#define DEFAULT_GAIN_DIV_I_ROLL    6
#define DEFAULT_GAIN_DIV_D_ROLL    0
#define DEFAULT_GAIN_DIV_P_PITCH   0
#define DEFAULT_GAIN_DIV_I_PITCH   6
#define DEFAULT_GAIN_DIV_D_PITCH   0
#define DEFAULT_GAIN_DIV_P_YAW     0
#define DEFAULT_GAIN_DIV_I_YAW     6
#define DEFAULT_GAIN_DIV_D_YAW     0

#define DEFAULT_SAT_P_ROLL         0xFFFF
#define DEFAULT_SAT_I_ROLL         0xFFFF
#define DEFAULT_SAT_D_ROLL         0xFFFF
#define DEFAULT_SAT_P_PITCH        0xFFFF
#define DEFAULT_SAT_I_PITCH        0xFFFF
#define DEFAULT_SAT_D_PITCH        0xFFFF
#define DEFAULT_SAT_P_YAW          0xFFFF
#define DEFAULT_SAT_I_YAW          0xFFFF
#define DEFAULT_SAT_D_YAW          0xFFFF

#define DEFAULT_LP_MUL_GYRO_ROLL   1
#define DEFAULT_LP_MUL_GYRO_PITCH  1
#define DEFAULT_LP_MUL_GYRO_YAW    1
#define DEFAULT_LP_DIV_GYRO_ROLL   1
#define DEFAULT_LP_DIV_GYRO_PITCH  1
#define DEFAULT_LP_DIV_GYRO_YAW    1

#define DEFAULT_LP_MUL_ACCEL_ROLL  1
#define DEFAULT_LP_MUL_ACCEL_PITCH 1
#define DEFAULT_LP_MUL_ACCEL_YAW   1
#define DEFAULT_LP_DIV_ACCEL_ROLL  1
#define DEFAULT_LP_DIV_ACCEL_PITCH 1
#define DEFAULT_LP_DIV_ACCEL_YAW   1

#define DEFAULT_LP_MUL_MAG_ROLL  1
#define DEFAULT_LP_MUL_MAG_PITCH 1
#define DEFAULT_LP_MUL_MAG_YAW   1
#define DEFAULT_LP_DIV_MAG_ROLL  1
#define DEFAULT_LP_DIV_MAG_PITCH 1
#define DEFAULT_LP_DIV_MAG_YAW   1

#define DEFAULT_LP_MUL_MOTOR_FRONT 1
#define DEFAULT_LP_MUL_MOTOR_BACK  1
#define DEFAULT_LP_MUL_MOTOR_RIGHT 1
#define DEFAULT_LP_MUL_MOTOR_LEFT  1
#define DEFAULT_LP_DIV_MOTOR_FRONT 1
#define DEFAULT_LP_DIV_MOTOR_BACK  1
#define DEFAULT_LP_DIV_MOTOR_RIGHT 1
#define DEFAULT_LP_DIV_MOTOR_LEFT  1

enum{
	MOTOR_LEFT	       = 	0,
	MOTOR_BACK	       =	1,
	MOTOR_FRONT	       =	2,
	MOTOR_RIGHT	       =	3,
};

typedef enum{
	 QUAD_STEP_PRE_FLIGHT	,
	 QUAD_STEP_FLYING		,
	 QUAD_STEP_LANDED		,
	 QUAD_STEP_LANDING		,
	 QUAD_STEP_TAKING_OFF	,
}QUAD_STEP;

typedef struct{
	QUAD_STEP CurrentStep;

	IMU QuadIMU;
	CONTROLLER QuadControl;

	FILTER_PARAMS GyroFilter[3];
	FILTER_PARAMS AccelFilter[3];
	FILTER_PARAMS MagFilter[3];
	FILTER_PARAMS MotorOutputFilter[4];

	int32_t MotorOutput[6];
}QUADCOPTER;

extern QUADCOPTER Quadcopter;

void quad_init(void);
void quad_run_control(void);
void set_PID_outputs(void);
void set_PID_inputs(void);
void turn_off_motors(void);
void refresh_IMU(void);
void motor_control_mix(void);

#endif // _QUADCOPTER_H
