#ifndef _FILTER_H
#define _FILTER_H

typedef struct{
	int32_t Multiplier;
	int32_t Divisor;
}FILTER_PARAMS;

// sei la como faz esse filtro sem float
//int32_t low_pass_1(int32_t Value, int32 OldValue, float Coef);

// usar esse provisorio
#define low_pass(Val,OldVal,Mul,Div) (((Val*Mul)+OldVal)>>Div)

#endif // _FILTER_H
