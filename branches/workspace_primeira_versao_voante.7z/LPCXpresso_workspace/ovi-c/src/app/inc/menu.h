#ifndef MENU_H_
#define MENU_H_

// esses defines devem coincidir com a tabela de characteres do display LCD
#define SETABAIXO  				25
#define SETACIMA    			24
#define SETALEFT    			27
#define SETARIGHT   			26
#define CHECKED                 23
#define UNCHECKED               22

// intervalo entre incrementos se der hold
#define STICK_DELAY             25

enum{
	MASK_SUBMENU   =         0x01,
	MASK_WRITE     =         0x02,
	MASK_READ      =         0x04,
	MASK_BOOL      =         0x08,
	MASK_VALUE     =         0x10,
	MASK_BAR       =         0x20,
};

typedef enum{
    ITEMTYPE_SUBMENU        =   MASK_SUBMENU | MASK_READ | MASK_WRITE,
    ITEMTYPE_VALUE_RW       =   MASK_READ | MASK_WRITE | MASK_VALUE,
    ITEMTYPE_VALUE_R        =   MASK_READ | MASK_VALUE,
    ITEMTYPE_BAR_R          =   MASK_READ | MASK_BAR,
    ITEMTYPE_BAR_RW         =   MASK_READ | MASK_WRITE | MASK_BAR,
    ITEMTYPE_VALUE_BAR_RW   =   MASK_READ | MASK_WRITE | MASK_VALUE | MASK_BAR,
    ITEMTYPE_VALUE_BAR_R    =   MASK_READ | MASK_VALUE | MASK_BAR,
    ITEMTYPE_BOOLEAN_RW     =   MASK_READ | MASK_WRITE | MASK_BOOL,
    ITEMTYPE_BOOLEAN_R      =   MASK_READ | MASK_BOOL,
}ITEMTYPE;

// acoes que o usuario pode fazer atraves do radio/teclado
typedef enum{
    ACTION_NONE 			 = 0,
    // extra channel switch
    ACTION_EMERGENCY		   	,
    // pitch stick
    ACTION_UP					,
    ACTION_DOWN					,
    // roll stick
    ACTION_LEFT					,
    ACTION_RIGHT				,
    // yaw stick
    ACTION_TURN_CW				,
    ACTION_TURN_CCW				,
}ACTION;

typedef enum{
    MENU_STEP_IDLE			 = 0,
    MENU_STEP_WAIT_BACK			,
    MENU_STEP_WAIT_SUBMENU_IN	,
    MENU_STEP_WAIT_SUBMENU_OUT	,
    MENU_STEP_WAIT_UPDOWN_BACK	,
}MENU_STEP;

typedef enum{
    ITEM_RESP_NONE			,
    ITEM_RESP_SETA_CHANGE	,
    ITEM_RESP_SEL_MIN_LIMIT	,
    ITEM_RESP_SEL_MAX_LIMIT	,
    ITEM_RESP_MAX_VALUE		,
    ITEM_RESP_MIN_VALUE		,
    ITEM_RESP_CHECKED		,
    ITEM_RESP_UNCHECKED		,
    ITEM_RESP_SUBMENU_IN	,
    ITEM_RESP_SUBMENU_OUT	,
}ITEM_RESPONSE;

typedef struct{
	// attributes
    const char *Name; 	// nome do item mostrado no menu
    int *Value; 		// o valor eh uma referencia de algum lugar da memoria
    const int *MaxVal;
    const int *MinVal;
    const int *Interval;
    ITEMTYPE ItemType;	// read, write, bar, bool, value
    // managing
    int16_t LinkedMenuIndex;	// usado no caso de submenus
}Item;

// estrutura de um menu
typedef struct{
    // container
    List *Items;
    // attributes
    const int* JanelaSize;
    const int* BarsPositionH;
    const int* ValuePositionH;
    const int* ArrowPositionH;
    const int* BarsLenght;
    // managing
    uint8_t SelectedItem;
    uint8_t FirstShowed;
    uint8_t LinkedPrevMenu;

    MENU_STEP CurrentStep;
}MENU;

// estrutura do gerenciador de menus
typedef struct{
	// container
	List* Menus; // lista de menus que o menu manager comanda
	// attributes
	const char* Name;
	// managing
	int8_t CurrentMenu;
}MENU_MANAGER;

/****************************************************************************************/
/****************************** FUNCOES *************************************************/
/****************************************************************************************/

void menu_draw(MENU* oMenu, char Clear); // redesenha todo o menu
void menu_refresh(MENU* oMenu);			// so atualiza os valores

Item* create_item(const char *Name, ITEMTYPE type, const int *minval, const int *maxval, const int *interval, int *val, int16_t LinkedMenuIndex);// tittle eh o nome da list que contem os items
MENU* menu_create(const char *Name, Item *FirstItem, const int *JanelaSize, const int *barsposh, const int *valueposh,  const int *arrowposh,  const int *barslen);// tittle eh o nome da list que contem os menus
MENU_MANAGER* menu_mgr_create(const char *Name, List* Menus);

char menu_add_item(MENU* oMenu, Item *oItem);
char menu_mgr_add_menu(MENU_MANAGER* oMenuMgr, MENU* oMenu);// cria um item no menu manager

ITEM_RESPONSE menu_process(MENU* oMenu, ACTION oAction); // processa um unico menu
char menu_mgr_process(MENU_MANAGER* oMenuMgr, ACTION oAction);// processa e atualiza o menu atual, avanca, volta e navega nos menus

extern const int menu_janela_size_small      ;
extern const int menu_janela_size_medium     ;
extern const int menu_janela_size_large      ;
extern const int menu_bar_lenght_small       ;
extern const int menu_bar_lenght_medium      ;
extern const int menu_bar_lenght_large       ;
extern const int menu_arrow_left             ;
extern const int menu_arrow_center           ;
extern const int menu_arrow_right            ;
extern const int menu_bar_position_left      ;
extern const int menu_bar_position_center    ;
extern const int menu_bar_position_right     ;
extern const int menu_value_position_right   ;
extern const int menu_value_position_center  ;

#endif //MENU_H_

