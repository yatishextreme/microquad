#ifndef RESOURCES_H
#define RESOURCES_H

extern const unsigned int MinUInt	    ;	// usado na barrinha/valor do menu
extern const unsigned int MaxUInt	    ;	// usado na barrinha/valor do menu
                                        ;
extern const int _One				    ;	// usado na barrinha/valor do menu
extern const int _10				    ;
extern const int _100				    ;
extern const int _250				    ;
                                        ;
extern const int MinInt				    ;	// usado na barrinha/valor do menu
extern const int MaxInt				    ;	// usado na barrinha/valor do menu


extern const char* _str_Motors 			;
extern const char* _str_Radio 			;
extern const char* _str_Sensors 		;
extern const char* _str_Control 		;
extern const char* _str_Filters 		;
extern const char* _str_Status		 	;
extern const char* _str_Save_log		;
extern const char* _str_Down_config	 	;

extern const char* _str_FLY				;
extern const char* _str_MOTORS			;
extern const char* _str_RADIO			;
extern const char* _str_SENSORS			;
extern const char* _str_CONTROL			;
extern const char* _str_FILTERS			;
extern const char* _str_STATUS			;
extern const char* _str_BAT_TEST		;
extern const char* _str_SAVE_LOG		;
extern const char* _str_DOWN_CFG		;


#endif//RESOURCES_H
