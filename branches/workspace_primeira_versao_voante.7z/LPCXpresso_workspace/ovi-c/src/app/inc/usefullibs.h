#ifndef __USEFULLIBS_H
#define __USEFULLIBS_H

/*********************************************************************
 * LISTA GENERICA
 *
 *
 *
 *
 */

/****************************************************************************/
/***************************** LISTA GENERICA *******************************/
/********************************* especial! ********************************/

// node
struct _ListNode{
    void* Data;
    struct _ListNode* Next;
};
typedef struct _ListNode ListNode;

// list
typedef struct{
	ListNode* First;
    const char *Name;
    int8_t Lenght;
    int8_t DataSize;
}List;

/***************************** FUNCOES ***************************/

// dispose list
void list_dispose(List* ListHandler);

// insert new item to the list
char list_insert(List* ListHandler, void* Data, int8_t Index);

// remove at index
char list_remove(List* ListHandler, int8_t Index);

// First = first node, DataSize = data size in bytes
List* list_create(void* First, const char* Name);

// get node at index
ListNode* list_get_node(List* ListHandler, int8_t Index);

// get data pointer at index
void* list_get_data(List* ListHandler, int8_t Index);

/******************************* FIM LISTA GENERICA ********************************/
/***********************************************************************************/

#endif // __USEFULLIBS_H
