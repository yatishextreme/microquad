#ifndef _CONTROL_H
#define _CONTROL_H

// enum , struct

typedef enum{
	CONTROL_TYPE_PID,
}CONTROL_TYPE;

enum{
	INDEX_PROPORTIONAL,
	INDEX_INTEGRAL,
	INDEX_DERIVATIVE,
};

typedef struct{
	int32_t GainMul[2];
	int32_t GainDiv[3];
	int32_t Saturation[3];

	int32_t Input;
	int32_t Error;
	int32_t Output;
	int32_t Integrator;

	int32_t ControlValue[3];
}PID;

typedef struct{
	char RunControl;
	CONTROL_TYPE ControlType;

	PID RollPID;
	PID YawPID;
	PID PitchPID;

}CONTROLLER;


// prototypes

void controller_init(CONTROLLER* oController, CONTROL_TYPE oType, PID RollPID, PID PitchPID, PID YawPID);

void PID_init_values(PID* oPID, int32_t Gain[3], int32_t Saturation[3]);
void PID_process(PID* oPID);

#endif // _CONTROL_H
