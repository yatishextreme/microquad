#include "resources.h"

/*********************** GLOBALS **************************************************/

const unsigned int MinUInt	= 0;			// usado na barrinha/valor do menu
const unsigned int MaxUInt	= 65535;		// usado na barrinha/valor do menu

const int _One				= 1;			// usado na barrinha/valor do menu
const int _10				= 10;
const int _100				= 100;
const int _250				= 250;

const int MinInt			= -32766;		// usado na barrinha/valor do menu
const int MaxInt			= 32767;		// usado na barrinha/valor do menu

/************************************************************************************/

const char* _str_Motors 			= "Motors"				;
const char* _str_Radio 				= "Radio"				;
const char* _str_Sensors 			= "Sensors"             ;
const char* _str_Control 			= "Control"             ;
const char* _str_Filters 			= "Filters"             ;
const char* _str_Status		 		= "Status"              ;
const char* _str_Save_log		 	= "Save log"            ;
const char* _str_Down_config	 	        = "Down. config."       ;

const char* _str_FLY				= "FLY"					;
const char* _str_MOTORS				= "MOTORS"				;
const char* _str_RADIO				= "RADIO"         		;
const char* _str_SENSORS			= "SENSORS"      		;
const char* _str_CONTROL			= "CONTROL"      		;
const char* _str_FILTERS			= "FILTERS"      		;
const char* _str_STATUS				= "STATUS"       		;
const char* _str_BAT_TEST			= "BAT. TEST"    		;
const char* _str_SAVE_LOG			= "SAVE. LOG"      		;
const char* _str_DOWN_CFG			= "DOWN CFG."    		;

