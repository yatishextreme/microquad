#include "lpc_types.h"
#include "delay.h"
#include "filter.h"
#include "gyro.h"
#include "accel.h"
#include "radio.h"
#include "motor.h"
#include "quadcopter.h"

QUADCOPTER Quadcopter;

void quad_init(void){

	PID RollPID = {{DEFAULT_GAIN_MUL_P_ROLL, DEFAULT_GAIN_MUL_D_ROLL},		// Gain
					{DEFAULT_GAIN_DIV_P_ROLL, DEFAULT_GAIN_DIV_I_ROLL, DEFAULT_GAIN_DIV_D_ROLL},
					{DEFAULT_SAT_P_ROLL,DEFAULT_SAT_I_ROLL,DEFAULT_SAT_D_ROLL},	// Saturation
					0,0,0,0,		// input, error, output, integrator
					{0,0,0}};	// Control Value

	PID PitchPID = {{DEFAULT_GAIN_MUL_P_PITCH, DEFAULT_GAIN_MUL_D_PITCH},		// Gain
					{DEFAULT_GAIN_DIV_P_PITCH, DEFAULT_GAIN_DIV_I_PITCH, DEFAULT_GAIN_DIV_D_PITCH},
					{DEFAULT_SAT_P_PITCH,DEFAULT_SAT_I_PITCH,DEFAULT_SAT_D_PITCH},	// Saturation
					0,0,0,0,		// input, error, output, integrator
					{0,0,0}};	// Control Value

	PID YawPID  = {{DEFAULT_GAIN_MUL_P_YAW, DEFAULT_GAIN_MUL_D_YAW},		// Gain
					{DEFAULT_GAIN_DIV_P_YAW, DEFAULT_GAIN_DIV_I_YAW, DEFAULT_GAIN_DIV_D_YAW},
					{DEFAULT_SAT_P_YAW,DEFAULT_SAT_I_YAW,DEFAULT_SAT_D_YAW},	// Saturation
					0,0,0,0,		// input, error, output,  integrator
					{0,0,0}};	// Control Value

	Quadcopter.GyroFilter[INDEX_IMU_ROLL].Multiplier = 		DEFAULT_LP_MUL_GYRO_ROLL;
	Quadcopter.GyroFilter[INDEX_IMU_PITCH].Multiplier = 	DEFAULT_LP_MUL_GYRO_PITCH;
	Quadcopter.GyroFilter[INDEX_IMU_YAW].Multiplier = 		DEFAULT_LP_MUL_GYRO_YAW;

	Quadcopter.GyroFilter[INDEX_IMU_ROLL].Divisor = 		DEFAULT_LP_DIV_GYRO_ROLL;
	Quadcopter.GyroFilter[INDEX_IMU_PITCH].Divisor = 		DEFAULT_LP_DIV_GYRO_PITCH;
	Quadcopter.GyroFilter[INDEX_IMU_YAW].Divisor = 			DEFAULT_LP_DIV_GYRO_YAW;

	Quadcopter.AccelFilter[INDEX_IMU_ROLL].Multiplier = 	DEFAULT_LP_MUL_ACCEL_ROLL;
	Quadcopter.AccelFilter[INDEX_IMU_PITCH].Multiplier = 	DEFAULT_LP_MUL_ACCEL_PITCH;
	Quadcopter.AccelFilter[INDEX_IMU_YAW].Multiplier = 		DEFAULT_LP_MUL_ACCEL_YAW;

	Quadcopter.AccelFilter[INDEX_IMU_ROLL].Divisor = 		DEFAULT_LP_DIV_ACCEL_ROLL;
	Quadcopter.AccelFilter[INDEX_IMU_PITCH].Divisor = 		DEFAULT_LP_DIV_ACCEL_PITCH;
	Quadcopter.AccelFilter[INDEX_IMU_YAW].Divisor = 		DEFAULT_LP_DIV_ACCEL_YAW;

	Quadcopter.MagFilter[INDEX_IMU_ROLL].Multiplier = 		DEFAULT_LP_MUL_MAG_ROLL;
	Quadcopter.MagFilter[INDEX_IMU_PITCH].Multiplier = 		DEFAULT_LP_MUL_MAG_PITCH;
	Quadcopter.MagFilter[INDEX_IMU_YAW].Multiplier = 		DEFAULT_LP_MUL_MAG_YAW;

	Quadcopter.MagFilter[INDEX_IMU_ROLL].Divisor = 			DEFAULT_LP_DIV_MAG_ROLL;
	Quadcopter.MagFilter[INDEX_IMU_PITCH].Divisor = 		DEFAULT_LP_DIV_MAG_PITCH;
	Quadcopter.MagFilter[INDEX_IMU_YAW].Divisor = 			DEFAULT_LP_DIV_MAG_YAW;

	Quadcopter.MotorOutputFilter[MOTOR_BACK].Multiplier = 	DEFAULT_LP_MUL_MOTOR_BACK;
	Quadcopter.MotorOutputFilter[MOTOR_FRONT].Multiplier = 	DEFAULT_LP_MUL_MOTOR_FRONT;
	Quadcopter.MotorOutputFilter[MOTOR_RIGHT].Multiplier = 	DEFAULT_LP_MUL_MOTOR_RIGHT;
	Quadcopter.MotorOutputFilter[MOTOR_LEFT].Multiplier = 	DEFAULT_LP_MUL_MOTOR_LEFT;

	Quadcopter.MotorOutputFilter[MOTOR_BACK].Divisor = 		DEFAULT_LP_DIV_MOTOR_BACK;
	Quadcopter.MotorOutputFilter[MOTOR_FRONT].Divisor = 	DEFAULT_LP_DIV_MOTOR_FRONT;
	Quadcopter.MotorOutputFilter[MOTOR_RIGHT].Divisor = 	DEFAULT_LP_DIV_MOTOR_RIGHT;
	Quadcopter.MotorOutputFilter[MOTOR_LEFT].Divisor = 		DEFAULT_LP_DIV_MOTOR_LEFT;


	controller_init(&(Quadcopter.QuadControl), CONTROL_TYPE_PID, RollPID, PitchPID, YawPID);

	Quadcopter.CurrentStep = QUAD_STEP_LANDED;

    Quadcopter.MotorOutput[0] = MOTOR_MIN;
	Quadcopter.MotorOutput[1] = MOTOR_MIN;
	Quadcopter.MotorOutput[2] = MOTOR_MIN;
	Quadcopter.MotorOutput[3] = MOTOR_MIN;
	Quadcopter.MotorOutput[4] = MOTOR_MIN;
	Quadcopter.MotorOutput[5] = MOTOR_MIN;

	delay_ms(1000);

	RadioOffsets[RADIO_CH1] = radio_offset_channel(RADIO_CH1, 15);
	RadioOffsets[RADIO_CH2] = radio_offset_channel(RADIO_CH2, 15);
	RadioOffsets[RADIO_CH3] = radio_offset_channel(RADIO_CH3, 15);
	RadioOffsets[RADIO_CH4] = radio_offset_channel(RADIO_CH4, 15);
	RadioOffsets[RADIO_CH5] = radio_offset_channel(RADIO_CH5, 15);
	RadioOffsets[RADIO_CH6] = radio_offset_channel(RADIO_CH6, 15);
	RadioOffsets[RADIO_CH7] = radio_offset_channel(RADIO_CH7, 15);
	RadioOffsets[RADIO_CH8] = radio_offset_channel(RADIO_CH8, 15);

}

void turn_off_motors(void){
	Quadcopter.MotorOutput[0] = MOTOR_MIN;
	Quadcopter.MotorOutput[1] = MOTOR_MIN;
	Quadcopter.MotorOutput[2] = MOTOR_MIN;
	Quadcopter.MotorOutput[3] = MOTOR_MIN;
	Quadcopter.MotorOutput[4] = MOTOR_MIN;
	Quadcopter.MotorOutput[5] = MOTOR_MIN;

	set_motor_output(Quadcopter.MotorOutput);
}

void refresh_IMU(void){
	// vai trabalhar de -445 a +445

	static int32_t LastValues[3];
	static int32_t Values[3];

	// refresh leitura
	gyro_ReadAxes(Values);

	// ajusta direcao
	Values[INDEX_IMU_ROLL] = -(Values[INDEX_IMU_ROLL] >> 6);
	Values[INDEX_IMU_PITCH] = -(Values[INDEX_IMU_PITCH] >> 6);
	Values[INDEX_IMU_YAW] = -(Values[INDEX_IMU_YAW] >> 6);

	// filtro bundao
	LastValues[INDEX_IMU_ROLL] = ( LastValues[INDEX_IMU_ROLL] * 7 + Values[INDEX_IMU_ROLL] ) >> 3;
	LastValues[INDEX_IMU_PITCH] = ( LastValues[INDEX_IMU_PITCH] * 7 + Values[INDEX_IMU_PITCH] ) >> 3;
	LastValues[INDEX_IMU_YAW] = (LastValues[INDEX_IMU_YAW] * 7 + Values[INDEX_IMU_YAW] ) >> 3;

	if(Quadcopter.QuadControl.RunControl == 0){
		Quadcopter.QuadIMU.GyroValues[INDEX_IMU_ROLL] = LastValues[INDEX_IMU_ROLL];
		Quadcopter.QuadIMU.GyroValues[INDEX_IMU_PITCH] = LastValues[INDEX_IMU_PITCH];
		Quadcopter.QuadIMU.GyroValues[INDEX_IMU_YAW] = LastValues[INDEX_IMU_YAW];

		Quadcopter.QuadControl.RunControl = 1;
	}
}

void quad_run_control(void){

	// seta os outputs do PID
	set_PID_outputs();

	// seta os inputs do PID
	set_PID_inputs();

	// process PID loop
	PID_process(&(Quadcopter.QuadControl.RollPID));
	PID_process(&(Quadcopter.QuadControl.PitchPID));
	PID_process(&(Quadcopter.QuadControl.YawPID));

	Quadcopter.QuadControl.RunControl = 0;

	// mix motor outputs
	motor_control_mix();

	// send motor values to ESC
	set_motor_output(Quadcopter.MotorOutput);
}

void set_PID_inputs(void){
	Quadcopter.QuadControl.RollPID.Input 	= radio_get_channel(ROLL_RC_CH);
	Quadcopter.QuadControl.PitchPID.Input 	= radio_get_channel(PITCH_RC_CH);
	Quadcopter.QuadControl.YawPID.Input 	= radio_get_channel(YAW_RC_CH);

}

void set_PID_outputs(void){

	Quadcopter.QuadControl.RollPID.Output 	= Quadcopter.QuadIMU.GyroValues[INDEX_IMU_ROLL];
	Quadcopter.QuadControl.PitchPID.Output 	= Quadcopter.QuadIMU.GyroValues[INDEX_IMU_PITCH];
	Quadcopter.QuadControl.YawPID.Output 	= Quadcopter.QuadIMU.GyroValues[INDEX_IMU_YAW];

}

void motor_control_mix(void){
    // output mixing
    Quadcopter.MotorOutput[MOTOR_RIGHT] = (radio_get_raw(THROTTLE_RC_CH) << 6) -
    		Quadcopter.QuadControl.RollPID.ControlValue[INDEX_PROPORTIONAL] -
    		Quadcopter.QuadControl.RollPID.ControlValue[INDEX_INTEGRAL] -
    		Quadcopter.QuadControl.YawPID.ControlValue[INDEX_PROPORTIONAL] -
    		Quadcopter.QuadControl.YawPID.ControlValue[INDEX_INTEGRAL];

    Quadcopter.MotorOutput[MOTOR_LEFT] = (radio_get_raw(THROTTLE_RC_CH) << 6) +
    		Quadcopter.QuadControl.RollPID.ControlValue[INDEX_PROPORTIONAL] +
    		Quadcopter.QuadControl.RollPID.ControlValue[INDEX_INTEGRAL] -
    		Quadcopter.QuadControl.YawPID.ControlValue[INDEX_PROPORTIONAL] -
    		Quadcopter.QuadControl.YawPID.ControlValue[INDEX_INTEGRAL];

    Quadcopter.MotorOutput[MOTOR_BACK] = (radio_get_raw(THROTTLE_RC_CH) << 6) +
    		Quadcopter.QuadControl.PitchPID.ControlValue[INDEX_PROPORTIONAL] +
    		Quadcopter.QuadControl.PitchPID.ControlValue[INDEX_INTEGRAL] +
    		Quadcopter.QuadControl.YawPID.ControlValue[INDEX_PROPORTIONAL] +
    		Quadcopter.QuadControl.YawPID.ControlValue[INDEX_INTEGRAL];

    Quadcopter.MotorOutput[MOTOR_FRONT] = (radio_get_raw(THROTTLE_RC_CH) << 6) -
    		Quadcopter.QuadControl.PitchPID.ControlValue[INDEX_PROPORTIONAL] -
    		Quadcopter.QuadControl.PitchPID.ControlValue[INDEX_INTEGRAL] +
    		Quadcopter.QuadControl.YawPID.ControlValue[INDEX_PROPORTIONAL] +
    		Quadcopter.QuadControl.YawPID.ControlValue[INDEX_INTEGRAL];

}
