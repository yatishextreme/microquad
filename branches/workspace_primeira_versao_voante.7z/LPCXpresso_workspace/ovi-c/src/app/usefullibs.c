#include "lpc_types.h"
#include "target.h"

#include <stdlib.h>
#include "usefullibs.h"

/*********************************************************************************/
/***************************************** LIST **********************************/
/*********************************************************************************/

List* list_create(void* First, const char* Name){
    List* oList = (List*)malloc(sizeof(List));
    if(oList != NULL){
        oList->Name = Name;
        ListNode* oNode = (ListNode*)malloc(sizeof(ListNode));
        if(oNode != NULL){
            oNode->Next = NULL;
            oNode->Data = First;
            oList->First = oNode;
            oList->Lenght = 1;
        }
    }

    return oList;
}

// se o infeliz pediu index maior do q o tamanho da lista
// retorna NULL
// senao retorna um ponteiro pra lista
ListNode* list_get_node(List* ListHandler, int8_t Index){
    ListNode* Iterator = ListHandler->First;
    int16_t i = 0;
    if(Index < ListHandler->Lenght){
        while(i++ < Index){
            Iterator = Iterator->Next;
        }
        return Iterator;
    }
    else{
        return NULL;
    }
}

char list_insert(List* ListHandler, void* Data, int8_t Index){
    char result = 0;
    // cria um novo node
    ListNode* oNode = (ListNode*)malloc(sizeof(ListNode));
    if(oNode != NULL){
    	// se conseguiu alocar
    	// joga o dado
        oNode->Data = Data;
        // se for o primeiro item da lista
        if(Index == 0){
        	// se for pra inserir na posicao 0
            oNode->Next = ListHandler->First;
            ListHandler->First=oNode;
        }
        else{
        	// se for em outra posicao
            ListNode* Iterator = list_get_node(ListHandler, Index - 1);
            oNode->Next = Iterator->Next;
            Iterator->Next = oNode;
        }
        result = 1;
        (ListHandler->Lenght)++;
    }

    return result;
}

char list_remove(List* ListHandler, int8_t Index){
    char result = 0;
    if(ListHandler->Lenght > 0){
        ListNode* NodeRM = list_get_node(ListHandler, Index);
        if(ListHandler->Lenght == 1){
            ListHandler->First = NULL;
        }
        else{
            ListNode* Iterator = list_get_node(ListHandler, Index - 1);
            Iterator->Next = NodeRM->Next;
        }
        (ListHandler->Lenght)--;
        free(NodeRM);
        result = 1;
    }
    return result;
}

void* list_get_data(List* ListHandler, int8_t Index){
	if(Index < ListHandler->Lenght){
		return list_get_node(ListHandler, Index)->Data;
	}
	return 0;
}

void list_dispose(List* ListHandler){
    while(list_remove(ListHandler, ListHandler->Lenght - 1));
    free(ListHandler);
}
