#include "lpc_types.h"
#include "navigation.h"

void IMU_init(IMU *oIMU){
	oIMU->AccelValues[INDEX_IMU_ROLL] = 0;
	oIMU->AccelValues[INDEX_IMU_PITCH] = 0;
	oIMU->AccelValues[INDEX_IMU_YAW] = 0;

	oIMU->GyroValues[INDEX_IMU_ROLL] = 0;
	oIMU->GyroValues[INDEX_IMU_PITCH] = 0;
	oIMU->GyroValues[INDEX_IMU_YAW] = 0;
}

