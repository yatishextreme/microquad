#include "lpc17xx_gpio.h"
#include "interruptions.h"

#include "delay.h"
#include "board.h"
#include "radio.h"
#include "motor.h"
#include "display.h"
#include "resources.h"
#include "quadcopter.h"
#include "user_interface.h"

/*********************** PROTOTYPES ************************************************/

void get_user_action(ACTION* RadioAction);

/***********************************************************************************/
/*    ☺☻       ☺☻     ☺☻     ☺☺☺☻  ☺☻      ☺☻
 *    ☺☺☻     ☺☺☻    ☺☺☺☻     ☺☻   ☺☺☻     ☺☻
 *    ☺☺☺☻   ☺☺☺☻   ☺☻  ☺☻    ☺☻   ☺☺☺☻    ☺☻
 *    ☺☻☺☺☻ ☺☺☻☺☻  ☺☻    ☺☻   ☺☻   ☺☻☺☺☻   ☺☻
 *    ☺☻ ☺☺☺☺☻ ☺☻  ☺☺☺☺☺☺☺☻   ☺☻   ☺☻ ☺☺☻  ☺☻
 *    ☺☻  ☺☺☻  ☺☻  ☺☺☺☺☺☺☺☻   ☺☻   ☺☻  ☺☺☻ ☺☻
 *    ☺☻       ☺☻  ☺☻    ☺☻   ☺☻   ☺☻   ☺☺☺☺☻
 *    ☺☻       ☺☻  ☺☻    ☺☻  ☺☺☺☻  ☺☻    ☺☺☺☻
 ***********************************************************************************/

int main (void){

	ACTION RadioAction = ACTION_NONE;

	char StringAux[20];

	delay_Init();

	/* Application Initialization */
	board_init();

	quad_init();
	motor_init();

	//printf("%s @ %d MHz\n", FIRM_VERSION, SystemCoreClock/1000000);
	user_interface_init();

	while(1){
		switch(Quadcopter.CurrentStep){
			case QUAD_STEP_PRE_FLIGHT:
				// re-check for security
				if(RadioValues[THROTTLE_RC_CH] < RADIO_MIN_CH_THRESHOLD){
					// apaga LCD backlight
					lcd_backlight_off();
					// lcd_clear(NokiaDisplay.BackColor);
					// vai pro step de voo
					Quadcopter.CurrentStep = QUAD_STEP_TAKING_OFF;
				}
			break;

			case QUAD_STEP_FLYING:
				if(RadioAction == ACTION_EMERGENCY){

					// limpa todos os integradores
					Quadcopter.QuadControl.PitchPID.Integrator = 0;
					Quadcopter.QuadControl.RollPID.Integrator = 0;
					Quadcopter.QuadControl.YawPID.Integrator = 0;

					Quadcopter.CurrentStep = QUAD_STEP_LANDING;
				}
				else{
					// tambem zera os integradores qd o throttle tiver baixo
					if(radio_get_raw(THROTTLE_RC_CH) < RADIO_MIN_CH_THRESHOLD){
						Quadcopter.QuadControl.PitchPID.Integrator = 0;
						Quadcopter.QuadControl.RollPID.Integrator = 0;
						Quadcopter.QuadControl.YawPID.Integrator = 0;
					}
					else{
						quad_run_control();
/*
						lcd_goto(0,0);
						sprintf(StringAux, "%d %d %d      ",Quadcopter.QuadControl.PitchPID.ControlValue[INDEX_PROPORTIONAL], Quadcopter.QuadControl.RollPID.ControlValue[INDEX_PROPORTIONAL], Quadcopter.QuadControl.YawPID.ControlValue[INDEX_PROPORTIONAL]);
						lcd_puts(StringAux);

						//lcd_goto(0,0);
						//sprintf(StringAux, "%d %d",Quadcopter.MotorOutput[MOTOR_FRONT], Quadcopter.MotorOutput[MOTOR_BACK]);
						//lcd_puts(StringAux);
*/
					}
				}
			break;

			case QUAD_STEP_LANDED:
				// roda um loop do menu
				if(menu_mgr_process(MenuMgr, RadioAction)){
					process_user_entry(MenuMgr);
				}
			break;

			case QUAD_STEP_LANDING:
				// liga backlight do display
				lcd_backlight_on();

				Quadcopter.CurrentStep = QUAD_STEP_LANDED;
			break;

			case QUAD_STEP_TAKING_OFF:
				// vai pro step de voo
				Quadcopter.CurrentStep = QUAD_STEP_FLYING;
			break;

			default:
			break;
		}

		// busca o USER ACTION
		get_user_action(&RadioAction);

		if(RadioAction == ACTION_EMERGENCY){
			turn_off_motors();
		}
	}

	return 0;
}

void get_user_action(ACTION* RadioAction){
	// yaw stick
	if(radio_get_raw(YAW_RC_CH) < RADIO_MIN_CH_THRESHOLD){
		if(radio_get_raw(THROTTLE_RC_CH) < RADIO_MIN_CH_THRESHOLD){
			*RadioAction = ACTION_EMERGENCY;
		}
		else{
			*RadioAction = ACTION_TURN_CW;
		}
		return;
	}

	if(radio_get_raw(YAW_RC_CH) > RADIO_MAX_CH_THRESHOLD){
		*RadioAction = ACTION_TURN_CCW;
		return;
	}
	// roll stick
	if(radio_get_raw(ROLL_RC_CH) < RADIO_MIN_CH_THRESHOLD){
		*RadioAction = ACTION_LEFT;
		return;
	}

	if(radio_get_raw(ROLL_RC_CH) > RADIO_MAX_CH_THRESHOLD){
		*RadioAction = ACTION_RIGHT;
		return;
	}

	// pitch stick
	if(radio_get_raw(PITCH_RC_CH) < RADIO_MIN_CH_THRESHOLD){
		*RadioAction = ACTION_DOWN;
		return;
	}

	if(radio_get_raw(PITCH_RC_CH) > RADIO_MAX_CH_THRESHOLD){
		*RadioAction = ACTION_UP;
		return;
	}

	*RadioAction = ACTION_NONE;

}

