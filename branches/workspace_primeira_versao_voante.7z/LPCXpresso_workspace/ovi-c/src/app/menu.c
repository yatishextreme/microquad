/*
 * main.c
 *
 *  Created on: Sep, 2011
 *      Author: flaviohpo
 *
 *  Modified on May, 2012 by flaviohpo
 *  	* new submenu structure
 *  	* menu manager included
 *  		* menu list added
 *  	* ported to lpcxpresso
 */

#include "stdio.h"
#include "stdlib.h"
#include "lpc_types.h"
#include "target.h"

#include "usefullibs.h"
#include "delay.h"
#include "display.h"
#include "menu.h"

TOUT_t DelayStick;

static char StringAux[16];

const int menu_janela_size_small      = 4;
const int menu_janela_size_medium     = 8;
const int menu_janela_size_large      = 12;
const int menu_bar_lenght_small       = 15;
const int menu_bar_lenght_medium      = 30;
const int menu_bar_lenght_large       = 45;
const int menu_arrow_left             = 6;
const int menu_arrow_center           = 9;
const int menu_arrow_right            = 13;
const int menu_bar_position_left      = 30;
const int menu_bar_position_center    = 50;
const int menu_bar_position_right     = 70;
const int menu_value_position_right   = 15;
const int menu_value_position_center  = 7;

MENU_MANAGER* menu_mgr_create(const char *Name, List* Menus){
	MENU_MANAGER* oMenuMgr = (MENU_MANAGER*)malloc(sizeof(MENU_MANAGER));
	if(oMenuMgr != NULL){
		oMenuMgr->Name        	= Name;
		oMenuMgr->Menus			= Menus;
		oMenuMgr->CurrentMenu	= 0;
	}
	return oMenuMgr;
}

char menu_mgr_add_menu(MENU_MANAGER* oMenuMgr, MENU* oMenu){
	if(oMenuMgr != NULL){
		return list_insert(oMenuMgr->Menus, (void*)oMenu, oMenuMgr->Menus->Lenght);
	}
	return 0;
}

// responde 1 qd o usuario da ACTION_RIGHT em menu com LinkedMenu = -1 do tipo SUBMENU,
// 0 se ele soh ta navegando ou mudando valor das variaveis
char menu_mgr_process(MENU_MANAGER* oMenuMgr, ACTION oAction){
	MENU* SelectedMenu = (MENU*)list_get_data(oMenuMgr->Menus, oMenuMgr->CurrentMenu);
	MENU* NextMenu;
	Item* SelectedItem;

	// refresh todos os items do selected menu que sao readeable
	menu_refresh(SelectedMenu);

	switch(menu_process(SelectedMenu, oAction)){
		case ITEM_RESP_CHECKED:
				// nada
			break;

		case ITEM_RESP_MAX_VALUE:
				// nada
			break;

		case ITEM_RESP_MIN_VALUE:
				// nada
			break;

		case ITEM_RESP_NONE:
				// nada
			break;

		case ITEM_RESP_SEL_MAX_LIMIT:
				// nada
			break;

		case ITEM_RESP_SEL_MIN_LIMIT:
				// nada
			break;

		case ITEM_RESP_SETA_CHANGE:
				// redesenha soh a parte das setas, valores e items
				menu_draw(SelectedMenu, 0);
			break;

		case ITEM_RESP_SUBMENU_IN:
				// verifica se o submenu for diferente de -1
				// muda para o menu apontado
				SelectedItem = list_get_data(SelectedMenu->Items, SelectedMenu->SelectedItem);
				if(SelectedItem->ItemType == ITEMTYPE_SUBMENU){
					if(SelectedItem->LinkedMenuIndex != -1){
						if(list_get_data(oMenuMgr->Menus, SelectedItem->LinkedMenuIndex) != 0){	// se o menu apontado existir
							// o menu apontado deve apontar para o menu atual
							NextMenu = list_get_data((void*)oMenuMgr->Menus, (int16_t)SelectedItem->LinkedMenuIndex);
							NextMenu->LinkedPrevMenu = oMenuMgr->CurrentMenu;
							oMenuMgr->CurrentMenu = SelectedItem->LinkedMenuIndex;

							SelectedMenu = NextMenu;

							// redesenha todo o menu
							menu_draw(SelectedMenu, 1);
						}
					}
				}
				return 1;
			break;

		case ITEM_RESP_SUBMENU_OUT:
				// verifica se o submenu for diferente de -1
				// muda para o menu apontado
				if(SelectedMenu->LinkedPrevMenu != -1){
					oMenuMgr->CurrentMenu = SelectedMenu->LinkedPrevMenu;
					SelectedMenu = (MENU*)list_get_data(oMenuMgr->Menus, oMenuMgr->CurrentMenu);

					// redesenha todo o menu
					menu_draw(SelectedMenu, 1);
				}
				return 1;
			break;

		case ITEM_RESP_UNCHECKED:
				// nada
			break;

		default:
				// nada
			break;
	}

	return 0;
}

Item* create_item(const char *Name, ITEMTYPE type, const int *minval, const int *maxval, const int *interval, int *val, int16_t LinkedMenuIndex){
    Item* oItem = (Item*)malloc(sizeof(Item));
    if(oItem != NULL){
        oItem->Name        =   Name;
        oItem->ItemType     =   type;
        oItem->MaxVal       =   maxval;
        oItem->MinVal       =   minval;
        oItem->Interval     =   interval;
        oItem->Value        =   val;
        oItem->LinkedMenuIndex = LinkedMenuIndex;
    }
    return oItem;
}

// remark: arrowpositionH must never be ZERO.
// se o menu contem items diferentes de SUBMENUS, nenhum parametro deve ser NULL.
MENU* menu_create(const char *Name, Item *FirstItem,  const int *JanelaSize,  const int *barsposh,  const int *valueposh,  const int *arrowposh,  const int *barslen){
    MENU* oMenu = (MENU*)malloc(sizeof(MENU));
    if(oMenu != NULL){
        oMenu->Items = list_create(FirstItem, Name);
        oMenu->JanelaSize = JanelaSize;
        oMenu->BarsPositionH = barsposh;
        oMenu->ValuePositionH = valueposh;
        oMenu->ArrowPositionH = arrowposh;
        oMenu->BarsLenght = barslen;
        oMenu->SelectedItem = 0;
        oMenu->FirstShowed = 0;
        oMenu->LinkedPrevMenu = -1;
        oMenu->CurrentStep = MENU_STEP_IDLE;
    }
    return oMenu;
}

char menu_add_item(MENU* oMenu, Item *oItem){
    unsigned char result = list_insert(oMenu->Items, oItem, oMenu->Items->Lenght);
    return result;
}

// remark: menus que contem somente SUBMENUS nao dever rodar esta rotina
void menu_refresh(MENU* oMenu){

	int32_t valor;
	int32_t min, max;
    int8_t i = oMenu->FirstShowed;
    int8_t d, p;

    Item* oItem;

    // varre todos os items visiveis
    while((i < (oMenu->FirstShowed + *(oMenu->JanelaSize))) && (i < oMenu->Items->Lenght)){

        oItem = list_get_data(oMenu->Items,i);
        // se possuir barra
        if((oItem->ItemType & MASK_READ) && (oItem->ItemType & MASK_BAR)){
            min = *(oItem->MinVal);
            max = *(oItem->MaxVal);
            d = (max-min) / 100;
            p = ((*(oItem->Value)) - (*(oItem->MinVal))) / d;
            if(p > 100){
                p = 100;
            }
            lcd_drawprogressbar(*(oMenu->BarsPositionH), 20+(8*(i-oMenu->FirstShowed)), *(oMenu->BarsLenght), 4, RED, BLACK, p);
        }
        else{ // se nao apaga o lugar da barra
            lcd_fillrect(*(oMenu->BarsPositionH),20+(8*(i-oMenu->FirstShowed)), *(oMenu->BarsLenght), 4, NokiaDisplay.BackColor);
        }

        lcd_goto(*(oMenu->ValuePositionH), 2+i-oMenu->FirstShowed); // move para posicao di valor
        if(((oItem->ItemType) & MASK_READ) != 0){ // if is value or bool readable
        //if(1){
            if(((oItem->ItemType) & MASK_VALUE) != 0){ // se for um valor
            //if(1){
                // valor
            	sprintf(StringAux, "%d",*(oItem->Value));
            	lcd_puts(StringAux);

                valor = *(oItem->Value);

                sprintf(StringAux, "   ");
                lcd_puts(StringAux);
            }
            else{   // se nao for valor
                if((oItem->ItemType & MASK_BOOL) == MASK_BOOL){ // se for um boolean
                	sprintf(StringAux, "%c    ",*(oItem->Value));
                	lcd_puts(StringAux);
                }
                else{ // se for submenu so apaga
                    //sprintf(StringAux, "     ");
                    //lcd_puts(StringAux);
                }
            }
        }
        i++;
    }
}

void menu_draw(MENU* oMenu, char Clear){
    uint16_t i = 0;

    char SetaCima = 1;
    char SetaBaixo = 1;

    if(Clear){
        lcd_clear(NokiaDisplay.BackColor);
        lcd_goto(0,0);
        sprintf(StringAux, oMenu->Items->Name);
        lcd_puts(StringAux);
    }

    // coloca desde o inicio ate o tamanho de 2*Janela+1
    if(oMenu->SelectedItem < oMenu->FirstShowed && oMenu->FirstShowed > 0){
        oMenu->FirstShowed = oMenu->SelectedItem;
    }
    // verifica se o selected item ta fora da janela
    if(oMenu->SelectedItem >= (oMenu->FirstShowed + *(oMenu->JanelaSize)) && oMenu->SelectedItem < oMenu->Items->Lenght){
        oMenu->FirstShowed = oMenu->SelectedItem - *(oMenu->JanelaSize) + 1;
    }
    // config seta cima
    if(oMenu->FirstShowed == 0){
        SetaCima = 0;
    }
    // config seta baixo
    if((*(oMenu->JanelaSize) + oMenu->FirstShowed) >= oMenu->Items->Lenght){
        SetaBaixo = 0;
    }

    // anda do i = primeiro mostrado (0) ate o ultimo da janela
    for(i = oMenu->FirstShowed; i < oMenu->FirstShowed + *(oMenu->JanelaSize); i++){
        if(i < oMenu->Items->Lenght){
            lcd_goto(0, 2 + i - oMenu->FirstShowed);
            if(i == oMenu->SelectedItem){
                sprintf(StringAux, "%c ",SETARIGHT);
                lcd_puts(StringAux);
            }
            else{
                sprintf(StringAux, "  ");
                lcd_puts(StringAux);
            }
            // mostra o Name do item
            sprintf(StringAux, ((Item*)list_get_node(oMenu->Items, i)->Data)->Name);
            lcd_puts(StringAux);
            NokiaDisplay.LineCount++;
        }
    }

    lcd_goto(0,LCD_NLINE - 1);
    sprintf(StringAux, "%d/%d  ",oMenu->SelectedItem + 1, oMenu->Items->Lenght);
    lcd_puts(StringAux);

    lcd_goto(*(oMenu->ArrowPositionH), 1);
    if(SetaCima){
        sprintf(StringAux, "%c",SETACIMA);
        lcd_puts(StringAux);
    }
    else{
        sprintf(StringAux, " ");
        lcd_puts(StringAux);
    }

    // BUG: desenhou uma seta ao lado direito do MenuTittle quand era pra ta la em baixo
    // desenha NADA na mesma posicao quando nao deve desenhar seta
    // ha! ja sei, eh porque a continha da maior do q era pra dar //////// ps. bug corrigido
    lcd_goto(*(oMenu->ArrowPositionH), LCD_NLINE - 1);
    if(SetaBaixo){
        sprintf(StringAux, "%c",SETABAIXO);
        lcd_puts(StringAux);
    }
    else{
        sprintf(StringAux, " ");
        lcd_puts(StringAux);
    }

    lcd_goto(LCD_NCHAR - 1, LCD_NLINE - 1);
    sprintf(StringAux, "%d",(int)oMenu->CurrentStep);
    lcd_puts(StringAux);

}

/*
 *
 *
 *
 *
 *
 *
 * */
ITEM_RESPONSE menu_process(MENU* oMenu, ACTION oAction){
    Item* oItem = list_get_data(oMenu->Items, oMenu->SelectedItem);
    ITEM_RESPONSE result = ITEM_RESP_NONE;
    switch(oMenu->CurrentStep){
        case MENU_STEP_IDLE:	// se o menu esta em idle state
            switch(oAction){
                case ACTION_NONE:
                	// se o usuario nao deu nenhum comando, nao faz nada
                break;

                case ACTION_UP:	// se o usuario mandou setinha para cima
                	timeout_ms_start(&DelayStick, STICK_DELAY);	// start delay q conta o tempo do botao pressionado
                	// seta o step de esperar o botao voltar
                    oMenu->CurrentStep = MENU_STEP_WAIT_UPDOWN_BACK;
                    if(oMenu->SelectedItem > 0){	// se estiver em um item diferente do primeiro
                        (oMenu->SelectedItem)--;	// move a setinha um item acima
                        result = ITEM_RESP_NONE;	// nao responde nada para o MenuMgr
                    }
                    else{
                        result = ITEM_RESP_SEL_MIN_LIMIT;	// se esta no limite, entao responde que chegou no final
                    }
                break;

                case ACTION_DOWN: // mesma logica do action up
                    timeout_ms_start(&DelayStick, STICK_DELAY);

                    oMenu->CurrentStep = MENU_STEP_WAIT_UPDOWN_BACK;
                    if(oMenu->SelectedItem < oMenu->Items->Lenght - 1){
                        (oMenu->SelectedItem)++;
                        result = ITEM_RESP_NONE;
                    }
                    else{
                        result = ITEM_RESP_SEL_MAX_LIMIT;
                    }
                break;

                case ACTION_TURN_CCW:
                	timeout_ms_start(&DelayStick, STICK_DELAY);
					oMenu->CurrentStep = MENU_STEP_WAIT_BACK;
					if((oItem->ItemType == ITEMTYPE_VALUE_RW) || (oItem->ItemType == ITEMTYPE_BAR_RW) || (oItem->ItemType == ITEMTYPE_VALUE_BAR_RW)){
						if(*(oItem->Value) + *(oItem->Interval) <= *(oItem->MaxVal)){
							*(oItem->Value) = *(oItem->Value) + *(oItem->Interval);
							result = ITEM_RESP_NONE;
						}
						else{
							result = ITEM_RESP_MAX_VALUE;
						}
					}
					else{
						if(oItem->ItemType == ITEMTYPE_BOOLEAN_RW){
							*(oItem->Value) = CHECKED;
							result = ITEM_RESP_NONE;
						}
					}
                	break;

                case ACTION_TURN_CW:
                	timeout_ms_start(&DelayStick, STICK_DELAY);	// seta o timeout de tecla pressionada
					oMenu->CurrentStep = MENU_STEP_WAIT_BACK;	// seta o step de espera de tecla

					if((oItem->ItemType == ITEMTYPE_VALUE_RW) || (oItem->ItemType == ITEMTYPE_BAR_RW) || (oItem->ItemType == ITEMTYPE_VALUE_BAR_RW)){
						// se for readwrite
						if(*(oItem->Value) - *(oItem->Interval) >= *(oItem->MinVal)){	// verifica se o valor vai ficar dentro do permitido
							*(oItem->Value) = *(oItem->Value) - *(oItem->Interval);		// se vai ficar faz a subtracao
							result = ITEM_RESP_NONE;
						}
						else{
							*(oItem->Value) = *(oItem->MinVal);		// se nao ficar dentro do permitido, seta o minimo
							result = ITEM_RESP_MIN_VALUE;			// e avisa pro menu manager que o usuario chegou no limite minimo
						}
					}
					else{
						if(oItem->ItemType == ITEMTYPE_BOOLEAN_RW){	// se for um booleano inverte a selecao
							*(oItem->Value) = UNCHECKED;
							result = ITEM_RESP_NONE;
						}
					}
                	break;

                case ACTION_LEFT:	// se o usuario apertou para esquerda
                	oMenu->CurrentStep = MENU_STEP_WAIT_SUBMENU_OUT;
                    result = ITEM_RESP_NONE;
                break;

                case ACTION_RIGHT:
					oMenu->CurrentStep = MENU_STEP_WAIT_SUBMENU_IN;
					result = ITEM_RESP_NONE;
                break;

				default:
				// outros nao faz nada
				break;

            }
        break;

        case MENU_STEP_WAIT_BACK:
            if(timeout_ms_check(&DelayStick)){
                oMenu->CurrentStep = MENU_STEP_IDLE;
                result = ITEM_RESP_NONE;
            }
            else{
                result = ITEM_RESP_NONE;
            }
        break;

        case MENU_STEP_WAIT_SUBMENU_IN:
            if(oAction == ACTION_NONE){
                oMenu->CurrentStep = MENU_STEP_IDLE;
                result = ITEM_RESP_SUBMENU_IN;
            }
            else{
                result = ITEM_RESP_NONE;
            }
        break;

        case MENU_STEP_WAIT_SUBMENU_OUT:
            if(oAction == ACTION_NONE){
                oMenu->CurrentStep = MENU_STEP_IDLE;
                result = ITEM_RESP_SUBMENU_OUT;
            }
            else{
                result = ITEM_RESP_NONE;
            }
        break;

        case MENU_STEP_WAIT_UPDOWN_BACK:
        	if(timeout_ms_check(&DelayStick)){
				oMenu->CurrentStep = MENU_STEP_IDLE;
				result = ITEM_RESP_SETA_CHANGE;
			}
			else{
				result = ITEM_RESP_NONE;
			}
        break;
    }
    return result;
}
