#include "lpc_types.h"
#include "control.h"


void controller_init(CONTROLLER* oController, CONTROL_TYPE oType, PID RollPID, PID PitchPID, PID YawPID){
	oController->ControlType = oType;

	oController->RollPID = RollPID;
	oController->PitchPID = PitchPID;
	oController->YawPID = YawPID;

	oController->RunControl = 0;
}


void PID_init_values(PID* oPID, int32_t Gain[3], int32_t Saturation[3]){
	oPID->ControlValue[INDEX_PROPORTIONAL] = Gain[INDEX_PROPORTIONAL];
	oPID->ControlValue[INDEX_INTEGRAL] = Gain[INDEX_INTEGRAL];
	oPID->ControlValue[INDEX_DERIVATIVE] = Gain[INDEX_DERIVATIVE];

	oPID->Saturation[INDEX_PROPORTIONAL] = Saturation[INDEX_PROPORTIONAL];
	oPID->Saturation[INDEX_INTEGRAL] = Saturation[INDEX_INTEGRAL];
	oPID->Saturation[INDEX_DERIVATIVE] = Saturation[INDEX_DERIVATIVE];

	oPID->Error = 0;
	oPID->Input = 0;
	oPID->Output = 0;
}

inline void PID_process(PID* oPID){
	// usada no derivativo
	int32_t ErrorOld = oPID->Error;

	oPID->Error = oPID->Input - oPID->Output;

	// proportinal gain
	oPID->ControlValue[INDEX_PROPORTIONAL] = (oPID->Error * oPID->GainMul[INDEX_PROPORTIONAL]) >> oPID->GainDiv[INDEX_PROPORTIONAL];

	// integrate error
	//oPID->Integrator += oPID->Error;
	//oPID->Integrator = constrain(oPID->Integrator, -oPID->Saturation[INDEX_INTEGRAL], oPID->Saturation[INDEX_INTEGRAL]);
	//oPID->ControlValue[INDEX_INTEGRAL] = oPID->Integrator >> oPID->GainDiv[INDEX_INTEGRAL];

	// derivative
	// todo
	//oPID->ControlValue[INDEX_DERIVATIVE] = 0;

}

