#include "sensor.h"

void SENSOR_init(){
#ifdef PRESS_ENABLE
	PRESS_init();
#endif /* PRESS_ENABLE */
	ACCEL_init();
	GYRO_init();
}

/* Magnetometer HMC5843 */
#ifdef MAG_ENABLE

float HEADING;
float HEADING_X;
float HEADING_Y;

float MAG_X;
float MAG_Y;
float MAG_Z;

void MAG_init(){

}

void MAG_read(){
	
}

void MAG_process(float EULER_roll, float EULER_pitch){
	float Head_X;
	float Head_Y;
	float cos_roll;
	float sin_roll;
	float cos_pitch;
	float sin_pitch;
  
	cos_roll = cos(EULER_roll);  // Optimizacion, se puede sacar esto de la matriz DCM?
	sin_roll = sin(EULER_roll);
	cos_pitch = cos(EULER_pitch);
	sin_pitch = sin(EULER_pitch);
	// Tilt compensated Magnetic field X component:
	Head_X = MAG_X * cos_pitch + MAG_Y * sin_roll * sin_pitch + MAG_Z * cos_roll * sin_pitch;
	// Tilt compensated Magnetic field Y component:
	Head_Y = MAG_Y * cos_roll - MAG_Z * sin_roll;
	// Magnetic Heading
	HEADING = atan2( -Head_Y, Head_X);
	// Optimization for external DCM use. Calculate normalized components
	HEADING_X = cos(HEADING);
	HEADING_Y = sin(HEADING);
}

#endif /* MAG_ENABLE */

/* Pressure BMP085 */
void PRESS_init(){

}

/* Accelerometer MMA7455 */
float ACCEL_values[3] = {0, 0, 0};

void ACCEL_init(){
	char addr_data[2];
	// considerar que I2C ja esta incializado
	// precisa fazer a calibracao por que ele tenha algum offset
	// se nao quiser fazer a calibracao, utiliza offset experimental
	I2C_set_slave_add(ACCEL_I2C_ADDR);
	// o proprio acelerometro tem um registrador pra armazenar a calibracao 0x10
	// ver Freescale Application Note AN3745
	// registrador 0x16 configura o modo de operacao:
	addr_data[0] = 0x16; // addr
	addr_data[1] = 0x05; // 0000 0101 = measurement mode, 2g scale 
	if(I2C_write_byte(addr_data, 2)){
		LED1_ON;
	}
}

char ACCEL_read_register(char register_addr){
	
	return 0;
}

void ACCEL_read_8(){
	
}

void ACCEL_read_10(){
	
}

/* GYROSCOPE LPR LPY510AL */

float GYRO_values[3] = {0, 0, 0};

#ifndef GYRO_PR_REF_ON 
int GYRO_pitch_offset = 0;
int GYRO_roll_offset = 0;
#endif /* GYRO_PR_REF_ON */

#ifndef GYRO_Y_REF_ON
int GYRO_yaw_offset = 0;
#endif /* GYRO_Y_REF_ON */

void GYRO_init(){
#ifndef GYRO_PR_REF_ON
	unsigned int i = 0;
	float last_read = 0;
	float current_read = 0;
	float sum = 0;
	
	/* faz uma media de 50 leituras com passa baixa por eixo */
	last_read = ADC12_read_channel(GYRO_PITCH_INPUT);
	for(i = 0; i < 50; i++){
		current_read = ADC12_read_channel(GYRO_PITCH_INPUT);
		sum += last_read * 0.6 + current_read * 0.4;
		last_read = current_read;
	}
	GYRO_pitch_offset = (sum / 50);
	
	sum = 0;
	last_read = ADC12_read_channel(GYRO_ROLL_INPUT);
	for(i = 0; i < 50; i++){
		current_read = ADC12_read_channel(GYRO_ROLL_INPUT);
		sum += last_read * 0.6 + current_read * 0.4;
		last_read = current_read;
	}
	GYRO_roll_offset = (sum / 50);
	
	sum = 0;
	last_read = ADC12_read_channel(GYRO_YAW_INPUT);
	for(i = 0; i < 50; i++){
		current_read = ADC12_read_channel(GYRO_YAW_INPUT);
		sum += last_read * 0.6 + current_read * 0.4;
		last_read = current_read;
	}
	GYRO_yaw_offset = (sum / 50);
#endif	
}

/* ADC  : -1241.2121....................1241.2121 ( x 0.3222 graus / s )
 * REAL : -400...............................+400 ( x 1 graus / s )
 * */
void GYRO_read(){
	// le pitch e roll
#ifdef GYRO_PR_REF_ON
	GYRO_values[1] = ADC12_read_channel(GYRO_PITCH_INPUT) - ADC12_read_channel(GYRO_PR_VREF_INPUT);
	GYRO_values[0] = ADC12_read_channel(GYRO_ROLL_INPUT) - ADC12_read_channel(GYRO_PR_VREF_INPUT);
#else /* GYRO_PR_REF_ON */
	// usa os valores do setup
	GYRO_values[1] = ADC12_read_channel(GYRO_PITCH_INPUT) - GYRO_pitch_offset;
	GYRO_values[0] = ADC12_read_channel(GYRO_ROLL_INPUT) - GYRO_roll_offset;
#endif
	// le yaw
#ifdef GYRO_Y_REF_ON
	GYRO_values[2] = ADC12_read_channel(GYRO_YAW_INPUT) - ADC12_read_channel(GYRO_Y_VREF_INPUT);
#else
	GYRO_values[2] = ADC12_read_channel(GYRO_YAW_INPUT) - GYRO_yaw_offset;
#endif /* GYRO_Y_REF_ON */
	GYRO_values[0] = GYRO_GAIN * (float)GYRO_values[0];
	GYRO_values[1] = GYRO_GAIN * (float)GYRO_values[1];
	GYRO_values[2] = GYRO_GAIN * (float)GYRO_values[2];	
}

/* Mag HMC5843 */

/* Pressure BMP085 */


