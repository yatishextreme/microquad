#include "DCM.h"

float Vector_Dot_Product(float vector1[3],float vector2[3]);
void Vector_Cross_Product(float vectorOut[3], float v1[3],float v2[3]);
void Vector_Scale(float vectorOut[3],float vectorIn[3], float scale2);
void Vector_Add(float vectorOut[3],float vectorIn1[3], float vectorIn2[3]);
void Matrix_Multiply(float a[3][3], float b[3][3], float mat[3][3]);

float DCM_Matrix[3][3]= {
  { 1,0,0 },
  { 0,1,0 },
  { 0,0,1 }}; 
float Update_Matrix[3][3]={
  { 0,0,0 },
  { 0,0,0 },
  { 0,0,0 }};
float Temporary_Matrix[3][3]={
  { 0,0,0 },
  { 0,0,0 },
  { 0,0,0 }};

// se nao couber tudo em uma section, dividir em 2 funcoes
void DCM_process(void){
    float Temporary[3][3];
    float error = 0;
    float renorm = 0;
    int x, y;
    
    // update matrix
    Update_Matrix[0][0] = 0;
    Update_Matrix[0][1] = (-G_Dt * GyroValues[2]); // -z
    Update_Matrix[0][2] = (G_Dt * GyroValues[1]); // y
    Update_Matrix[1][0] = (G_Dt * GyroValues[2]); // z
    Update_Matrix[1][1] = 0;
    Update_Matrix[1][2] = (-G_Dt * GyroValues[0]); // -x
    Update_Matrix[2][0] = (-G_Dt * GyroValues[1]); // -y
    Update_Matrix[2][1] = (G_Dt * GyroValues[0]); // x
    Update_Matrix[2][2] = 0;
#ifdef PRINT_MATRIX    
    PrintMatrix(Matrix_Update);
#endif /* PRINTMATRIX */
    Matrix_Multiply(DCM_Matrix, Update_Matrix, Temporary_Matrix); // a * b = c
#ifdef PRINT_MATRIX    
    PrintMatrix(Temporary_Matrix);
#endif /* PRINTMATRIX */
    for(x = 0; x < 3; x++){
        for(y = 0; y < 3; y++){
            DCM_Matrix[x][y] += Temporary_Matrix[x][y];
        } 
    }
#ifdef PRINT_MATRIX    
    PrintMatrix(DCM_Matrix);
#endif /* PRINTMATRIX */
    /* renormalization
    error= -Vector_Dot_Product(&DCM_Matrix[0][0], &DCM_Matrix[1][0]) * 0.5; //eq.19
    
    Vector_Scale(&Temporary[0][0], &DCM_Matrix[1][0], error); //eq.19
    Vector_Scale(&Temporary[1][0], &DCM_Matrix[0][0], error); //eq.19
    
    Vector_Add(&Temporary[0][0], &Temporary[0][0], &DCM_Matrix[0][0]);//eq.19
    Vector_Add(&Temporary[1][0], &Temporary[1][0], &DCM_Matrix[1][0]);//eq.19
    
    Vector_Cross_Product(&Temporary[2][0], &Temporary[0][0], &Temporary[1][0]); // c = a x b //eq.20
    
    renorm = 0.5 *(3 - Vector_Dot_Product(&Temporary[0][0], &Temporary[0][0])); //eq.21
    Vector_Scale(&DCM_Matrix[0][0], &Temporary[0][0], renorm);
    
    renorm = 0.5 *(3 - Vector_Dot_Product(&Temporary[1][0], &Temporary[1][0])); //eq.21
    Vector_Scale(&DCM_Matrix[1][0], &Temporary[1][0], renorm);
    
    renorm = 0.5 *(3 - Vector_Dot_Product(&Temporary[2][0], &Temporary[2][0])); //eq.21
    Vector_Scale(&DCM_Matrix[2][0], &Temporary[2][0], renorm);*/
#ifdef PRINT_MATRIX    
    PrintMatrix(DCM_Matrix);
#endif /* PRINTMATRIX */    
    // drift correction
    
    // euler angles
    pitch = asin(-DCM_Matrix[2][0]);
    roll = atan2(DCM_Matrix[2][1], DCM_Matrix[2][2]);
    yaw = atan2(DCM_Matrix[1][0], DCM_Matrix[0][0]);
}

// VECTOR FUNCTIONS
//Computes the dot product of two vectors
float Vector_Dot_Product(float vector1[3],float vector2[3])
{
    float op = 0;
    int i = 0;
    
    for(i = 0; i < 3; i++){
        op += vector1[i] * vector2[i];
    }
    
    return op; 
}

//Computes the cross product of two vectors
void Vector_Cross_Product(float vectorOut[3], float v1[3],float v2[3])
{
    vectorOut[0] = (v1[1] * v2[2]) - (v1[2] * v2[1]);
    vectorOut[1] = (v1[2] * v2[0]) - (v1[0] * v2[2]);
    vectorOut[2] = (v1[0] * v2[1]) - (v1[1] * v2[0]);
}

//Multiply the vector by a scalar. 
void Vector_Scale(float vectorOut[3],float vectorIn[3], float scale2)
{
    int i = 0;
    for(i = 0; i < 3; i++){
        vectorOut[i] = vectorIn[i] * scale2; 
    }
}

void Vector_Add(float vectorOut[3],float vectorIn1[3], float vectorIn2[3])
{
    int i = 0;
    for(i = 0; i < 3; i++){
        vectorOut[i] = vectorIn1[i] + vectorIn2[i];
    }
}

void Matrix_Multiply(float a[3][3], float b[3][3], float mat[3][3])
{
    float op[3];
    int x, y, w; 
    for(x = 0; x < 3; x++){
        for(y = 0; y < 3; y++){
            for(w = 0; w < 3; w++){
                op[w] = a[x][w] * b[w][y];
            } 
            mat[x][y] = op[0] + op[1] + op[2];
        }
    }
}

void print_matrix(float Matrix[3][3]){
    printf("\n\n\r%d | %d | %d\n\r-----------------------\n\r%d | %d | %d\n\r-----------------------\n\r%d | %d | %d\n\r", (int)Matrix[0][0], (int)Matrix[0][1], (int)Matrix[0][2], (int)Matrix[1][0], (int)Matrix[1][1], (int)Matrix[1][2], (int)Matrix[2][0], (int)Matrix[2][1], (int)Matrix[2][2]);    
}

