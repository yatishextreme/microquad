#ifndef MATH_MATRIX_H_
#define MATH_MATRIX_H_

void MATRIX_mul(float Output[3][3], float Input1[3][3], float Input2[3][3]);

#endif /*MATH_MATRIX_H_*/
