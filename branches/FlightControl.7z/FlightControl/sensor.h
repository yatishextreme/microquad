#ifndef SENSOR_H_
#define SENSOR_H_

#include "mcufunctions.h"
#include "math.h"

/* ON/OFF macros for P5 outputs */
#define LED1_ON (P5OUT&=~0x20)
#define LED1_OFF (P5OUT|=0x20)
#define LED2_ON (P5OUT&=~0x40)
#define LED2_OFF (P5OUT|=0x40)
#define BUZZER_ON (P5OUT|=0x80)
#define BUZZER_OFF (P5OUT&=~0x80)

void SENSOR_init();

/* MAGNETOMETER HMC5843 esquece o magnetometro por enquanto */
//#define MAG_ENABLE
#ifdef MAG_ENABLE
extern float MAG_X;
extern float MAG_Y;
extern float MAG_Z;

void MAG_init();
void MAG_read();
void MAG_process(float EULER_roll, float EULER_pitch);

#endif /* MAG_ENABLE */

/* PRESSURE BMP085 */
#define PRESS_ENABLE
#ifdef PRESS_ENABLE
void PRESS_init();
#endif /* PRESS_ENABLE */

/* ACCELEROMETER MMA7455 */
#define ACCEL_I2C_ADDR 0x1C

/* {X, Y, Z} */
extern float ACCEL_values[3];

void ACCEL_init();
void ACCEL_read_8();
void ACCEL_read_10();

/* GYROSCOPES LPR510AL LPY510AL */
#define GYRO_PR_REF_ON // indica se o jumper de Vref do LPR esta fechado no A5
#define GYRO_Y_REF_ON // indica se o jumper de Vref do LPY esta fechado no A4

#ifdef GYRO_PR_REF_ON // canal analogico da referencia do gyro pitch e roll
#define GYRO_PR_VREF_INPUT 5
#endif /* GYRO_PR_REF_ON */

#ifdef GYRO_Y_REF_ON // canal analogico da referencia do gyro yaw
#define GYRO_Y_VREF_INPUT 4
#endif /* GYRO_Y_REF_ON */

#define GYRO_YAW_INPUT 0 // entrada analogica correspondente
#define GYRO_PITCH_INPUT 1
#define GYRO_ROLL_INPUT 2

#define GYRO_GAIN 0.3222

/* {roll, pitch, yaw} */
extern float GYRO_values[3];

void GYRO_init();
void GYRO_read();

#endif /*SENSOR_H_*/
