#include "math_vector.h"

void vector_scale(int vector_out[], int vector_in[], int scale ,  unsigned int size){
	do{
		vector_out[size] = vector_in[size] * scale;
		size--;
	}while(size > 0);
}

void vector_scale_float(float vector_out[], float vector_in[], float scale,  unsigned int size){
	do{
		vector_out[size] = vector_in[size] * scale;
		size--;
	}while(size > 0);
}

void vector_cross(float output[3], float input1[3], float input2[3]){
	output[0]= (input1[1] * input2[2]) - (input1[2] * input2[1]);
	output[1]= (input1[2] * input2[0]) - (input1[0] * input2[2]);
	output[2]= (input1[0] * input2[1]) - (input1[1] * input2[0]);
}

float vector_dot(float input1[3], float input2[3]){
	float op=0;
	int c;
  
	for(c = 0; c < 3; c++){
		op += input1[c] * input2[c];
	}
  	return op; 
}

void vector_add(int vector_out[], int vector_in1[], int vector_in2[], unsigned int size){
	while(size > 0){
		size--;
		vector_out[size] = vector_in1[size] + vector_in2[size];
	}
}

void vector_add_float(float vector_out[], float vector_in1[], float vector_in2[], unsigned int size){
	while(size > 0){
		size--;
		vector_out[size] = vector_in1[size] + vector_in2[size];
	}
}	

