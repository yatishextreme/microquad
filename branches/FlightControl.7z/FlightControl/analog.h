#ifndef __ANALOG
#define __ANALOG

#include "flightcontrol.h"

#define ANALOG_ENABLE 0xFF

#define BATTERY_CH 3 
#define GYROY_CH 2
#define GYROX_CH 1
#define GYROZ_CH 0
#define ACCELX_CH 6
#define ACCELY_CH 7
#define GYROPRREF_CH 5
#define GYROPYREF_CH 4

extern int AnalogOffset[8];
extern int AnalogValue[8];

void analog_init(void);
void analog_calibrate_channel(int channel);
void analog_refresh_all(void);
void analog_refresh_channel(int channel);
     
#endif /* __ANALOG */
