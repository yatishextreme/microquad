#include "mma7455.h"

unsigned char MMA7455Found = 0;
char MMA7455Offset[3] = {0, 0, 0};
