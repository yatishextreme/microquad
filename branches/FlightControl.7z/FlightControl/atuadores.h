#ifndef ATUADORES_H_
#define ATUADORES_H_

#include "mcufunctions.h"

#define ATUADORES_QTD 4
#define MAX_THROTTLE 4020
#define MIN_THROTTLE 2020

extern int ATUADORES_relacao;

/*
 * n = channel (1..6)
 * duty = duty cycle (0..100)
 */
void ATUADORES_set_duty(char n, int duty);

/*
 * seta o duty cycle de todos os atuadores de uma vez so
 * a posicao 0 do vetor de duty eh o timerB1 e a posicao 5 eh o timerB6
 * */
void ATUADORES_set_duties(int duties[ATUADORES_QTD]);

#endif /*ATUADORES_H_*/
