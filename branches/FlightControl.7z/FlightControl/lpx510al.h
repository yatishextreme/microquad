#ifndef __LPX510AL
#define __LPX510AL

#define GYRO_GAIN 0.324;        // 2.5 mV/�/s










#endif //LPX510AL
