#include "math_matrix.h"

void MATRIX_mul(float Output[3][3], float Input1[3][3], float Input2[3][3]){
	float op[3]; 
	int x, y, w;
	for(x = 0; x < 3; x++){
		for(y = 0; y < 3; y++){
			for(w = 0; w < 3; w++){
				op[w] = Input1[x][w] * Input2[w][y];
			} 
			Output[x][y] = 0;
			Output[x][y] = op[0] + op[1] + op[2];  
		}
	}
}

