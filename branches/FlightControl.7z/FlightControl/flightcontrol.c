#include "flightcontrol.h"

ERROR CurrentError = _NO_ERROR;
BEEPSTYLE CurrentBeep = _NO_BEEP;

char MotorArmed = 0;

const unsigned int TriggerOneFast[7] = { 0, 1, 5, 5, 5, 5, 5 };
const unsigned int TriggerOneSlow[7] = { 0, 5, 40, 40, 40, 40, 40};
const unsigned int TriggerTwoFast[7] = { 0, 1, 5, 6, 15, 15, 15};
const unsigned int TriggerTwoSlow[7] = { 0, 5, 10, 15, 40, 40, 40};
const unsigned int TriggerThreeFast[7] = { 0, 1, 2, 3, 4, 5, 10};
const unsigned int TriggerThreeSlow[7] = { 0, 5, 10, 15, 20, 25, 50};

unsigned int BeepCounter = 0;
unsigned int BeepStep = 0;
unsigned int BeepTrigger[7] = {0, 0, 0, 0, 0, 0, 0};

float PPMSlope[6] = {1, 1, 1, 1, 1, 1};
float PPMOffset[6] = {0, 0, 0, 0, 0, 0};

float ChannelInput[6] = {0, 0, 0, 0, 0, 0};

int ThrottleRef = MIN_THROTTLE;
int Throttle[4] = {MIN_THROTTLE, MIN_THROTTLE, MIN_THROTTLE, MIN_THROTTLE};
int ThrottleOffset[4] = {100, 100, 100, 100};

// Pitch Control
float PitchGainP = 1.6;
float PitchGainI = 0.016;
float PitchGainD = 0.7;

// Roll Control
float RollGainP = 1.6;
float RollGainI = 0.016;
float RollGainD = 0.7;
float RollGainCascateP = 0.5; // not in use

// yaw control
float YawGainP = 1;
float YawGainI = 0.005;
float YawGainD = 0.5;

float G_Dt = 0;
float GyroValues[3] = {0,0,0};
float GyroValuesOld[3] = {0, 0, 0};
float AccelValues[3] = {0,0,0};

float PitchRef = 0;
float RollRef = 0;
float YawRef = 0;

float PitchErro = 0;
float RollErro = 0;
float YawErro = 0;

float RollErroCascate = 0;

float PitchErroOld = 0;
float RollErroOld = 0;
float YawErroOld = 0;

float PitchControl = 0;
float RollControl = 0;
float YawControl = 0;

float PitchProportional = 0;
float PitchIntegrator = 0;
float PitchDerivative = 0;

float RollProportional = 0;
float RollIntegrator = 0;
float RollDerivative = 0;

float YawProportional = 0;
float YawIntegrator = 0;
float YawDerivative = 0;

float PitchGyro = 0;
float RollGyro = 0;
float YawGyro = 0;

float Pitch = 0;
float Roll = 0;
float Yaw = 0;

void uvetcpy(unsigned int v1[], const unsigned int v2[], int size);

void setup(void){
    long i = 0;
    char c = 0;
    
    // led & buzzer
    P5SEL = 0;
    P5DIR |= BIT5 + BIT6 + BIT7;
    LEDGREEN_ON;
    
    BUZZER_ON;
    for(i = 0; i < 15000; i++);
    BUZZER_OFF;
    LEDRED_OFF;
    
    DCOCTL = 0x77;      
    BCSCTL1 = 0xcf;     
    BCSCTL2 = 0xc8;   
    BCSCTL3 = 0xa0; 
    
    UART_init();
    printf("\n\n\r----------------------------\n\rComunicacao OK...");
    
    printf("\n\rTimerA...");
    TMRA_init();
    printf(" OK...");

#ifdef TEST_ESC_PERIOD 
    printf("\n\rTEST ESC PERIOD ENABLED...");
    TMRB_test_esc();
#else // TEST_ESC_PERIOD    
    printf("\n\rTimerB...");
    TMRB_init(10001);
#endif     // TEST_ESC_PERIOD    
    printf(" OK...");
         
    printf("\n\rPPM...");
    ppm_init();
    printf(" OK...");
    
#ifdef CALIBRATE_ESC
    printf("\n\rPressione S para calibrar os ESCs...\n\rAny other key skips this step...\n\rRETIRE AS HELICES!\n\r*** THROTTLE WILL BE FULL! *** \n");
    while(!(UC1IFG & UCA1RXIFG));
    c = UCA1RXBUF;
    if(c == 'S'){
        printf("\n\rPressione qualquer tecla novamente apos o BEEP.\n");
        TBCCR1 = 4000;
        TBCCR2 = 4000;
        TBCCR3 = 4000;
        TBCCR4 = 4000;
        TBCCR5 = 4000;
        TBCCR6 = 4000;
    }
    while(!(UC1IFG & UCA1RXIFG));
    c = UCA1RXBUF;
#endif // CALIBRATE_ESC    
    
    TBCCR1 = 2000;
    TBCCR2 = 2000;
    TBCCR3 = 2000;
    TBCCR4 = 2000;
    TBCCR5 = 2000;
    TBCCR6 = 2000;

    printf("\n\rAnalog Init...");    
    analog_init();
    printf("\n\rAnalog OK...");

    printf("\n\rI2C init...");
    
    printf("\n\rEEPROM init...");
    
    i2c_config(EEPROM_I2C_ADDR);
    EEPROMFound = !(i2c_find_device());
    
    load_PID_values();
    
    if(EEPROMFound){
        printf("\n\rEEPROM encontrada.\n\rCarregando parametros...");
    }
    else{
        printf("\n\rEEPROM nao encontrada... Loading factory settings...");
    }
    load_transmitter_values();
#ifndef __MMA7260 // se nao ta definido acelerometro analogico, procupra pelo MMA7455   

    init_MMA7455();
    
#endif //__MMA7260
    calibrate_gyro();
    printf("\n\rCalibracao OK..."); 
        
    analog_refresh_channel(BATTERY_CH);   
    printf("\n\rBateria: %d", AnalogValue[BATTERY_CH]);
    
    LEDGREEN_ON;
    LEDRED_OFF;    

    printf("\n\rAll PPM duty set to 1ms.");
    set_min_throttle();
    printf("\n\rAll motor disarmed.");
    MotorArmed = 0;
    
    printf("\n\rLOOP...\n\r");
}

void calibrate_accel(void){
    
    float Media = 0;
    char CharAux = 0;
    int k = 0;    
#ifdef __MMA7260 
    printf("\n\rAnalog accelerometer connected X to A6 and Y to A7.")
    printf("\n\rCalibrando Analog 6...");
    analog_calibrate_channel(6);
    printf("\n\rOffset Ch[6] = %d", AnalogOffset[6]);
    LEDGREEN_TOGGLE;
    LEDRED_TOGGLE;        
    printf("\n\rCalibrando Analog 7...");
    analog_calibrate_channel(7);
    printf("\n\rOffset Ch[7] = %d", AnalogOffset[7]);
    LEDGREEN_TOGGLE;
    LEDRED_TOGGLE;        

    // grava na eeprom os offsets float
    // fazer.....................
         
#else // se estiver com MMA7455
    if(MMA7455Found){ // isso so vai acontecer se o __MMA7260 nao estiver definido
        // amostra o acelerometro digital
        // da pra gravar nele um offset ai nao precisa subtrair o offset no software
        i2c_change_address(MMA7455_I2C_ADDR);
                
        printf("\n\rCalibrando MMA7455 X...");
        Media = 0;
        for(k = 0; k < MEAN_SIZE; k++){   
            i2c_read_byte(ACC_XOUT8, &CharAux); // le byte 
            Media += CharAux;
            delayms(4);    // espera o tempo aproximado da amostragem real do processo, 200hz
        }
        Media = (Media / MEAN_SIZE);
        // imprime os valores da media
        printf("Offset X: %d", (int)Media);
        
        MMA7455Offset[0] = (char)Media;
        //i2c_write_byte(ACC_XOFFL, (char)(Media));
        //i2c_write_byte(ACC_XOFFL, 0);
        //delayms(4);
        //i2c_write_byte(ACC_XOFFH, 0);
        
        // calibrando Y
        printf("\n\rCalibrando MMA7455 Y...");
        Media = 0;
        for(k = 0; k < MEAN_SIZE; k++){   
            i2c_read_byte(ACC_YOUT8, &CharAux); // le byte 
            Media += CharAux;
            delayms(4);    // espera o tempo aproximado da amostragem real do processo, 200hz
        }
        Media = (Media / MEAN_SIZE);
        // imprime os valores da media
        printf("Offset Y: %d", (int)Media);
        MMA7455Offset[1] = (char)Media;
        //i2c_write_byte(ACC_YOFFL, (char)(Media));
        //i2c_write_byte(ACC_YOFFL, 0);
        //delayms(4);
        //i2c_write_byte(ACC_YOFFH, 0);
        
        
        /*teste
        printf("\n\rDebug\n");
        while(1){
            i2c_read_byte(ACC_XOUTL, &CharAux); // le byte  low
            valor = CharAux2;
            valor = (valor << 8) | CharAux;
            AccelX = AccelX * 0.7 + (float)(valor) * 0.3;
            //AccelX = CharAux;
            printf("\rX:%3d   H:%d     L:%d", (int)(AccelX), (int)CharAux2, (int)CharAux);
            delayms(5);
        }*/
        
        //grava na eeprom os offsets 8 bits
        if(EEPROMFound){
            printf("\n\rGravando na EEPROM...");
            i2c_change_address(EEPROM_I2C_ADDR);
            i2c_write16_multiples(_MMA7455_OFFSET, MMA7455Offset, 3);           
            printf("OK...");
        }
        else{
            printf("\n\rEEPROM nao foi incializada. Nada foi gravado.");
        }
    }
#endif //__MMA7260
}

void calibrate_gyro(void){
    
    printf("\n\rCalibrando sensores.");
    
    LEDGREEN_ON;
    LEDRED_OFF;
    LEDGREEN_TOGGLE;
    LEDRED_TOGGLE;
    printf("\n\rCalibrando Analog 0...");
    analog_calibrate_channel(0);
    printf("\n\rOffset Ch[0] = %d", AnalogOffset[0]);
    LEDGREEN_TOGGLE;    
    LEDRED_TOGGLE;    
    printf("\n\rCalibrando Analog 1...");
    analog_calibrate_channel(1);
    printf("\n\rOffset Ch[1] = %d", AnalogOffset[1]);
    LEDGREEN_TOGGLE;
    LEDRED_TOGGLE;        
    printf("\n\rCalibrando Analog 2...");
    analog_calibrate_channel(2);
    printf("\n\rOffset Ch[2] = %d", AnalogOffset[2]);
    LEDGREEN_TOGGLE;
    LEDRED_TOGGLE;       
}

void error_process(void){
    int i = 0;
    
    if(CurrentError != _NO_ERROR){
        beep_process();
    }
    
    switch(CurrentError){
        case _NO_ERROR:
#ifdef BATTERY_ALARM_ENABLE
            if(AnalogValue[BATTERY_CH] < MIN_BATTERY){
                printf("\n\n\rERROR: LOW BATTERY!\n");
                CurrentError = _LOW_BAT;
                set_beep(_ONE_FAST);
            }
            else{
                if(AnalogValue[BATTERY_CH] > MAX_BATTERY){
                    printf("\n\n\rERROR: HIGH BATTERY!\n");
                    CurrentError = _HIGH_BAT;
                    set_beep(_THREE_FAST);    
                }
            } 
#endif // BATTERY_ALARM_ENABLE
 
            if(PPMChecker >= SIGNAL_LOST_ALARM){
                YawRef = 0;        
                ThrottleRef = MIN_THROTTLE;
                PitchRef = 0;
                RollRef = 0;
                CurrentError = _NO_SIGNAL;
#ifdef SIGNAL_LOST_ALARM_ENABLE                
                printf("\n\n\rERROR: NO RC TRANSMITTER SIGNAL!\n");
                set_beep(_ONE_SLOW);
#endif //SIGNAL_LOST_ALARM_ENABLE
            }
        break;
        
        case _LOW_BAT:
            if(AnalogValue[BATTERY_CH] >= MIN_BATTERY){
                printf("\n\n\rERROR: NONE.\n");
                CurrentError = _NO_ERROR;  
                set_beep(_NO_BEEP);
            }
            else{
                if(AnalogValue[BATTERY_CH] < BATTERY_SHTD){
                    printf("\n\n\rBATTERY LIMIT.");
                    for(i = 0; i < 4; i++){
                        Throttle[i] = MIN_THROTTLE;
                    }
                    set_throttle();
                    printf("\n\rTHROTTLE SET TO ZERO.");
                    printf("\n\rENTERING IN LOW POWER MODE.");               
                    dint();
                    _BIS_SR(LPM4_bits); // enter low power mode 4
                }
            }
        break;
        
        case _HIGH_BAT:
            if(AnalogValue[BATTERY_CH] < MAX_BATTERY){
                printf("\n\n\rERROR: NONE.\n");
                CurrentError = _NO_ERROR;
                set_beep(_NO_BEEP);
                // colocar mais seguranca
            }
        break;
        
        case _NO_SIGNAL:
            if(PPMChecker == 0){
                set_beep(_NO_BEEP);
                CurrentError = _NO_ERROR;
            }
            else{
                PPMChecker = SIGNAL_LOST_ALARM;
            }
        break;
    }
}

void set_beep(BEEPSTYLE beep){
    CurrentBeep = beep;
    BeepCounter = 0;
    BeepStep = 0;
    BUZZER_OFF;
    
    switch (CurrentBeep){
            
        case _NO_BEEP:
            BUZZER_OFF;
        break;
        
        case _ONE_FAST:
            printf("\n\rONE FAST BEEP...\n");
            uvetcpy(BeepTrigger, TriggerOneFast, 7);
        break;
        
        case _ONE_SLOW:
            printf("\n\rONE SLOW BEEP...\n");
            uvetcpy(BeepTrigger, TriggerOneSlow, 7);
        break;
        
        case _TWO_FAST:
            printf("\n\rTWO FAST BEEP...\n");
            uvetcpy(BeepTrigger, TriggerTwoFast, 7);
        break;
        
        case _TWO_SLOW:
            printf("\n\rTWO SLOW BEEP...\n");
            uvetcpy(BeepTrigger, TriggerTwoSlow, 7);
        break;
        
        case _THREE_FAST:
            printf("\n\rTHREE FAST BEEP...\n");
            uvetcpy(BeepTrigger, TriggerThreeFast, 7);
        break;
        
        case _THREE_SLOW:
            printf("\n\rTHREE SLOW BEEP...\n");
            uvetcpy(BeepTrigger, TriggerThreeSlow, 7);
        break;
    }
}

void beep_process(void){
    if(BeepCounter > BeepTrigger[6]){
        BeepCounter = 0;
        BeepStep = 0;
        BUZZER_OFF;
    }
    if((BeepCounter++) > BeepTrigger[BeepStep]){
        BUZZER_TOGGLE;
        BeepStep++;
    }
}

void set_throttle(void){
#ifndef ESC_I2C
    TBCCR1 = Constrain(Throttle[0], MIN_THROTTLE, MAX_THROTTLE);
    TBCCR2 = Constrain(Throttle[1], MIN_THROTTLE, MAX_THROTTLE);    
    TBCCR3 = Constrain(Throttle[2], MIN_THROTTLE, MAX_THROTTLE);
    TBCCR4 = Constrain(Throttle[3], MIN_THROTTLE, MAX_THROTTLE);
#else
    // envio por i2c
    // fazer
    
#endif // ESC_I2C
}

void set_min_throttle(void){
    int k = 0;
    for(k = 0; k < 4; k++){
        Throttle[k] = MIN_THROTTLE;
    }
    
    RollIntegrator = 0;
    PitchIntegrator = 0;
    YawIntegrator = 0;
    
    set_throttle(); 
}

void adjust_sensors(){
    char CharAux = 0;
    
    // accel low pass
#ifdef __MMA7260
    AccelValues[0] = 0.7 * AccelValues[0] + 0.3 * AnalogValue[ACCELX_CH] * ACCEL_GAIN;
    AccelValues[1] = 0.7 * AccelValues[1] - 0.3 * AnalogValue[ACCELY_CH] * ACCEL_GAIN;
    // AccelValues[2] = AccelValues[2] * 0.8 + AnalogValue[ACCELZ_CH] * 0.2; // Z nnao esta conectado
#else
    i2c_change_address(MMA7455_I2C_ADDR);
    
    i2c_read_byte(ACC_XOUT8, &CharAux); // le byte  low
    AccelValues[0] = AccelValues[0] * 0.7 + ((float)(CharAux) - (float)MMA7455Offset[0]) * 0.3 * ACCEL_GAIN;
    
    i2c_read_byte(ACC_YOUT8, &CharAux); // le byte  low
    AccelValues[1] = AccelValues[1] * 0.7 - ((float)(CharAux) - (float)MMA7455Offset[1]) * 0.3 * ACCEL_GAIN;
    
    i2c_read_byte(ACC_ZOUT8, &CharAux); // le byte  low
    AccelValues[2] = AccelValues[2] * 0.7 + (float)(CharAux) * 0.3 * ACCEL_GAIN;
#endif //__MMA7260

    // corrected gyro value (�/s)
    GyroValues[0] = (AnalogValue[GYROX_CH]) * GYRO_GAIN;
    GyroValues[1] = (AnalogValue[GYROY_CH]) * GYRO_GAIN;
    GyroValues[2] = (-AnalogValue[GYROZ_CH]) * GYRO_GAIN;
}

void filter_angles(void){
    // integracao trapezoidal
    //0.986 e 0.014 para loop de 20ms - nao eh usado este valor, tem que fazer para loop de 5ms
    //YawGyro = YawGyro + (GyroValues[2] + GyroValuesOld[2]) * G_Dt / 2;      
    YawGyro = YawGyro * 0.95 + GyroValues[2] * 0.05; // controle de yaw � feito em cima da velocidade angular
    PitchGyro = PitchGyro + (GyroValues[1] + GyroValuesOld[1]) * G_Dt / 2;   
    RollGyro = RollGyro + (GyroValues[0] + GyroValuesOld[0]) * G_Dt / 2;
    
    GyroValuesOld[0] = GyroValues[0];
    GyroValuesOld[1] = GyroValues[1];
    GyroValuesOld[2] = GyroValues[2];
    
    /* integracao normal
    YawGyro = YawGyro + GyroValues[2] * G_Dt;
    PitchGyro = PitchGyro + GyroValues[1] * G_Dt;   
    RollGyro = RollGyro + GyroValues[0] * G_Dt;
    */
    
    //YawMag = 0;
    Pitch = 0.99 * (Pitch + GyroValues[1] * G_Dt) + 0.01 * AccelValues[0];
    Roll = 0.99 * (Roll + GyroValues[0] * G_Dt) + 0.01 * AccelValues[1];
    Yaw = YawGyro;
    
}

void process_rc_reference(void){
    float VarAux = 0;
    if(PPMChecker == 0){

        ChannelInput[THROTTLE_CH] = PPMResult[THROTTLE_CH] * PPMSlope[THROTTLE_CH] + PPMOffset[THROTTLE_CH];
        ChannelInput[YAW_CH] = PPMResult[YAW_CH] * PPMSlope[YAW_CH] + PPMOffset[YAW_CH];
        ChannelInput[PITCH_CH] = PPMResult[PITCH_CH] * PPMSlope[PITCH_CH] + PPMOffset[PITCH_CH]; // pitch invertido
        ChannelInput[ROLL_CH] = PPMResult[ROLL_CH] * PPMSlope[ROLL_CH] + PPMOffset[ROLL_CH];

        if(ChannelInput[THROTTLE_CH] < 2100 && ChannelInput[THROTTLE_CH] > 1900){
            if(ChannelInput[YAW_CH] > 3900 && ChannelInput[YAW_CH] < 4000){
                MotorArmed = 1;      
            }
            else{
                if(ChannelInput[YAW_CH] < 2100){
                    MotorArmed = 0;
                    set_min_throttle();
                }
            }
        }

        VarAux = (ChannelInput[YAW_CH] - 3000) * STICK_TO_YAW_FACTOR;
        YawRef = YawRef * 0.8 + VarAux * 0.2;
                
        VarAux = ChannelInput[THROTTLE_CH];
        ThrottleRef = Constrain(ThrottleRef * 0.8 + VarAux * 0.2, MIN_THROTTLE, MAX_THROTTLE);
        
        VarAux = (-ChannelInput[PITCH_CH] + 3000) * STICK_TO_ANGLE_FACTOR;
        PitchRef = PitchRef * 0.8 + VarAux * 0.2;
        
        VarAux = (ChannelInput[ROLL_CH] - 3000) * STICK_TO_ANGLE_FACTOR;
        RollRef = RollRef * 0.8 + VarAux * 0.2;

    }
   
    PPMChecker++; // aumenta o checker, soh vai ler denovo a hora que uma subida/descida de borda for feita denovo
}

void compute_control(void){
    // PITCH CONTROL
    PitchErro = PitchRef - Pitch;
    PitchDerivative = (PitchErro - PitchErroOld) / G_Dt;
    PitchErroOld = PitchErro;
    PitchProportional = PitchErro * PitchGainP;
    PitchIntegrator += (PitchErro * G_Dt);
//    PitchIntegrator = Constrain(PitchIntegrator, -300, 300);
    PitchControl = PitchProportional + PitchIntegrator * PitchGainI + PitchDerivative * PitchGainD;

    // ROLL CONTROL
    RollErro = RollRef - Roll;    // roll normal:
    RollDerivative = (RollErro - RollErroOld) / G_Dt;
    RollErroOld = RollErro;    
    RollProportional = RollErro * RollGainP;
    RollIntegrator += (RollErro * G_Dt);
//    RollIntegrator = Constrain(RollIntegrator, -300, 300);
    RollControl = RollProportional +  RollIntegrator * RollGainI + RollDerivative * RollGainD;
    
    // YAW CONTROL    
    YawErro = YawRef - Yaw; 
    YawDerivative = (YawErro - YawErroOld) / G_Dt;  
    YawErroOld = YawErro;
    YawProportional = YawErro * YawGainP;
    //YawIntegrator += (YawErro * G_Dt);
    //YawIntegrator = Constrain(YawIntegrator, -300, 300);
    YawControl = YawProportional + YawDerivative * YawGainD;
    
    // SET CONTROL    
    Throttle[0] = ThrottleRef + ThrottleOffset[0] - RollControl + YawControl;
    Throttle[1] = ThrottleRef + ThrottleOffset[1] + RollControl + YawControl;
    Throttle[2] = ThrottleRef + ThrottleOffset[2] - PitchControl - YawControl;
    Throttle[3] = ThrottleRef + ThrottleOffset[3] + PitchControl - YawControl;
}

void calibrate_radio(void){
    char c = 0;
    fourbytes ValorAux;
    
    if(MotorArmed == 1 ){
        return;
    }
    
    if(PPMChecker != 0){
        printf("\n\rSem sinal do transmissor. Conecte o transmissor ou pressione qualquer tecla para sair.");      
        while(!(UC1IFG & UCA1RXIFG)){
            if(PPMChecker == 0){
                delayms(2000);
                break;
            }
        }      
        c = UCA1RXBUF;
    }
    
    if(PPMChecker == 0){
        printf("\n\rCalibrando Radio. Mova os canais para os extremos maximos e minimos...\n");
        int i = 0;
        float PPMMin[6] = {0, 0, 0, 0, 0, 0};
        float PPMMax[6] = {0, 0, 0, 0, 0, 0};
        char c = 0;
            
        for(i = 0; i < 6; i++){ // zera offset e slope
            PPMOffset[i] = 0;
            PPMSlope[i] = 1;
        }
    
        for(i = 0; i < 6; i++){ // coloca um valor inicial em max min
            PPMMin[i] = PPMResult[i];
            PPMMax[i] = PPMMin[i];
        }
        
        while(c != '-'){
            printf("\rCH0:%d CH1:%d: CH2:%d CH3:%d CH4:%d CH5:%d", (int)PPMResult[0], (int)PPMResult[1], (int)PPMResult[2], (int)PPMResult[3], (int)PPMResult[4], (int)PPMResult[5]);
            delayms(1);
            for(i = 0; i < 6; i++){ // pega max min
                if(PPMMax[i] < PPMResult[i]){ // nao ta pegando maximo
                    PPMMax[i] = PPMResult[i];
                }
                if(PPMMin[i] > PPMResult[i]){
                    PPMMin[i] = PPMResult[i];
                }
            }
            if(UC1IFG & UCA1RXIFG){
                c = UCA1RXBUF;
            }
        }
    
        for(i = 0; i < 6; i++){ // mostra valores max e min
            printf("\n\rCH%d: Min:%d Max:%d", i, (int)PPMMin[i], (int)PPMMax[i]);
        }
            
        for(i = 0; i < 6; i++){ // calcula offset e slope pra deixar na faixa de 1000 a 2000
            PPMSlope[i] = 2000.0 / (PPMMax[i] - PPMMin[i]);
            PPMOffset[i] = 2000.0 - (PPMSlope[i] * PPMMin[i]);
            printf("\n\rCH%d: Slope(x1000):%d Offset(x1):%d", i, (int)(PPMSlope[i] * 1000), (int)(PPMOffset[i]));
        }
    
        // grava dados na EEPROM
        if(EEPROMFound){
            i2c_change_address(EEPROM_I2C_ADDR);
            
            // grava yaw slope 
            ValorAux.f = PPMSlope[YAW_CH];
            i2c_write16_multiples(_RADIO_YAW_SLOPE, ValorAux.c, 4);
            
            delayms(100);
            
            // grava throttle slope 
            ValorAux.f = PPMSlope[THROTTLE_CH];
            i2c_write16_multiples(_RADIO_THROTTLE_SLOPE, ValorAux.c, 4);
            
            delayms(100);
            
            // grava pitch slope 
            ValorAux.f = PPMSlope[PITCH_CH];
            i2c_write16_multiples(_RADIO_PITCH_SLOPE, ValorAux.c, 4);
            
            delayms(100);
            
            // grava roll slope 
            ValorAux.f = PPMSlope[ROLL_CH];
            i2c_write16_multiples(_RADIO_ROLL_SLOPE, ValorAux.c, 4);
            
            delayms(100);
            
            // grava ch5 slope 
            ValorAux.f = PPMSlope[CH5_CH];
            i2c_write16_multiples(_RADIO_CH5_SLOPE, ValorAux.c, 4);
            
            delayms(100);
            
            // grava ch6 slope 
            ValorAux.f = PPMSlope[CH6_CH];
            i2c_write16_multiples(_RADIO_CH6_SLOPE, ValorAux.c, 4);
            
            delayms(100);
            
            // grava yaw offset 
            ValorAux.f = PPMOffset[YAW_CH];
            i2c_write16_multiples(_RADIO_YAW_OFFSET, ValorAux.c, 4);
            
            delayms(100);
            
            // grava throttle offset 
            ValorAux.f = PPMOffset[THROTTLE_CH];
            i2c_write16_multiples(_RADIO_THROTTLE_OFFSET, ValorAux.c, 4);
            
            delayms(100);
            
            // grava pitch offset 
            ValorAux.f = PPMOffset[PITCH_CH];
            i2c_write16_multiples(_RADIO_PITCH_OFFSET, ValorAux.c, 4);
            
            delayms(100);
            
            // grava roll offset 
            ValorAux.f = PPMOffset[ROLL_CH];
            i2c_write16_multiples(_RADIO_ROLL_OFFSET, ValorAux.c, 4);
            
            delayms(100);
            
            // grava ch5 offset 
            ValorAux.f = PPMOffset[CH5_CH];
            i2c_write16_multiples(_RADIO_CH5_OFFSET, ValorAux.c, 4);
            
            delayms(100);
            
            // grava ch6 offset 
            ValorAux.f = PPMOffset[CH6_CH];
            i2c_write16_multiples(_RADIO_CH6_OFFSET, ValorAux.c, 4);
            
        }
        printf("\n\rRadio calibration finished...");
    }
}


void init_MMA7455(void){
    i2c_config(MMA7455_I2C_ADDR);
    MMA7455Found = !(i2c_find_device());
    
    if(MMA7455Found){
        printf("\n\rMMA7455 encontrado.\n\rConfigurando MMA7455...");
        i2c_write_byte(ACC_MCTL, (BIT2 | BIT0)); // Gsel = 2g; Mode = measurement
        printf("OK...");
        delayms(1);

        // carrega offsets da eeprom
        if(EEPROMFound == 1){
            i2c_change_address(EEPROM_I2C_ADDR);
            printf("\n\rLoading MMA7455 offset from eeprom...");
            i2c_read16_multiples(_MMA7455_OFFSET, MMA7455Offset, 3);
            printf("\n\rX:%d\n\rY:%d\n\rZ:%d\n\rOK...",(int)MMA7455Offset[0], (int)MMA7455Offset[1], (int)MMA7455Offset[2]);
        }
        else{
            printf("\n\rAccelerometer not calibrated. EEPROM cannot be found.");
        }
    }
    else{
        printf("\n\rMMA7455 not found.");
        BUZZER_ON;
        delayms(500);
        BUZZER_OFF;
        delayms(500);
        BUZZER_ON;
        delayms(500);
        BUZZER_OFF;
    }
}

void load_transmitter_values(void){
    fourbytes ValorAux;

    if(EEPROMFound == 1){
        i2c_change_address(EEPROM_I2C_ADDR);    
        printf("\n\rCarregando parametros do transmissor da EEPROM...");  
        
        // load yaw slope e offset
        i2c_read16_multiples(_RADIO_YAW_SLOPE, ValorAux.c, 4);
        PPMSlope[YAW_CH] = ValorAux.f;
        i2c_read16_multiples(_RADIO_YAW_OFFSET, ValorAux.c, 4);
        PPMOffset[YAW_CH] = ValorAux.f;
        
        // load throttle slope  e offset
        i2c_read16_multiples(_RADIO_THROTTLE_SLOPE, ValorAux.c, 4);
        PPMSlope[THROTTLE_CH] = ValorAux.f;
        i2c_read16_multiples(_RADIO_THROTTLE_OFFSET, ValorAux.c, 4);
        PPMOffset[THROTTLE_CH] = ValorAux.f;
        
        // load pitch slope  e offset
        i2c_read16_multiples(_RADIO_PITCH_SLOPE, ValorAux.c, 4);
        PPMSlope[PITCH_CH] = ValorAux.f;
        i2c_read16_multiples(_RADIO_PITCH_OFFSET, ValorAux.c, 4);
        PPMOffset[PITCH_CH] = ValorAux.f;
        
        // load roll slope  e offset
        i2c_read16_multiples(_RADIO_ROLL_SLOPE, ValorAux.c, 4);
        PPMSlope[ROLL_CH] = ValorAux.f;
        i2c_read16_multiples(_RADIO_ROLL_OFFSET, ValorAux.c, 4);
        PPMOffset[ROLL_CH] = ValorAux.f;
    
        // load ch5 slope  e offset
        i2c_read16_multiples(_RADIO_CH5_SLOPE, ValorAux.c, 4);
        PPMSlope[CH5_CH] = ValorAux.f;
        i2c_read16_multiples(_RADIO_CH5_OFFSET, ValorAux.c, 4);
        PPMOffset[CH5_CH] = ValorAux.f;
    
        // load ch6 slope  e offset
        i2c_read16_multiples(_RADIO_CH6_SLOPE, ValorAux.c, 4);
        PPMSlope[CH6_CH] = ValorAux.f;
        i2c_read16_multiples(_RADIO_CH6_OFFSET, ValorAux.c, 4);
        PPMOffset[CH6_CH] = ValorAux.f;
            
        
        printf("\n\rYaw slope(x1000): %d offset: %d", (int)(PPMSlope[YAW_CH] * 1000),(int)(PPMOffset[YAW_CH]));      
        printf("\n\rThrottle slope(x1000): %d  offset: %d", (int)(PPMSlope[THROTTLE_CH] * 1000),(int)(PPMOffset[THROTTLE_CH]));
        printf("\n\rPitch slope(x1000): %d  offset: %d", (int)(PPMSlope[PITCH_CH] * 1000),(int)(PPMOffset[PITCH_CH]));
        printf("\n\rRoll slope(x1000): %d  offset: %d", (int)(PPMSlope[ROLL_CH] * 1000),(int)(PPMOffset[ROLL_CH]));
        printf("\n\rCH5 slope(x1000): %d  offset: %d", (int)(PPMSlope[CH5_CH] * 1000),(int)(PPMOffset[CH5_CH]));
        printf("\n\rCH6 slope(x1000): %d  offset: %d", (int)(PPMSlope[CH6_CH] * 1000),(int)(PPMOffset[CH6_CH]));
    }
    else{
        printf("\n\rRadio is not calibrated. EEPROM could not be found.");
    }
}

void save_PID_values(void){
    fourbytes ValorAux;
    
    if(MotorArmed == 0 && EEPROMFound == 1){
        i2c_change_address(EEPROM_I2C_ADDR);
        printf("\n\rSaving PID parameters into EEPROM...");
        
        // pitch
        ValorAux.f = PitchGainP;
        i2c_write16_multiples(_PITCH_P, ValorAux.c, 4);
        delayms(100);
        ValorAux.f = PitchGainI;
        i2c_write16_multiples(_PITCH_I, ValorAux.c, 4);
        delayms(100);
        ValorAux.f = PitchGainD;        
        i2c_write16_multiples(_PITCH_D, ValorAux.c, 4);
        delayms(100);
        
        // roll
        ValorAux.f = RollGainP;
        i2c_write16_multiples(_ROLL_P, ValorAux.c, 4);
        delayms(100);
        ValorAux.f = RollGainI;
        i2c_write16_multiples(_ROLL_I, ValorAux.c, 4);
        delayms(100);
        ValorAux.f = RollGainD;        
        i2c_write16_multiples(_ROLL_D, ValorAux.c, 4);
        delayms(100);
        
        // yaw
        ValorAux.f = YawGainP;
        i2c_write16_multiples(_YAW_P, ValorAux.c, 4);
        delayms(100);
        ValorAux.f = YawGainI;
        i2c_write16_multiples(_YAW_I, ValorAux.c, 4);
        delayms(100);
        ValorAux.f = YawGainD;        
        i2c_write16_multiples(_YAW_D, ValorAux.c, 4);
        delayms(100);
        
        printf("\n\rPID salvo.");
    }
}

void load_PID_values(void){
    fourbytes ValorAux;
    
    if(EEPROMFound == 1){
        i2c_change_address(EEPROM_I2C_ADDR);
        // PITCH        
        i2c_read16_multiples(_PITCH_P, ValorAux.c, 4);
        PitchGainP = ValorAux.f;
        i2c_read16_multiples(_PITCH_I, ValorAux.c, 4);
        PitchGainI = ValorAux.f;
        i2c_read16_multiples(_PITCH_D, ValorAux.c, 4);
        PitchGainD = ValorAux.f;
        // ROLL
        i2c_read16_multiples(_ROLL_P, ValorAux.c, 4);
        RollGainP = ValorAux.f;
        i2c_read16_multiples(_ROLL_I, ValorAux.c, 4);
        RollGainI = ValorAux.f;
        i2c_read16_multiples(_ROLL_D, ValorAux.c, 4);
        RollGainD = ValorAux.f;
        //YAW
        i2c_read16_multiples(_YAW_P, ValorAux.c, 4);
        YawGainP = ValorAux.f;
        i2c_read16_multiples(_YAW_I, ValorAux.c, 4);
        YawGainI = ValorAux.f;
        i2c_read16_multiples(_YAW_D, ValorAux.c, 4);
        YawGainD = ValorAux.f;   
        
        printf("\n\rParametros PID carregados...");
        printf("\n\rPitch P: %d I: %d D: %d", (int)(PitchGainP * 100),(int)(PitchGainI * 1000),(int)(PitchGainD * 100));     
        printf("\n\rRoll P: %d I: %d D: %d", (int)(RollGainP * 100),(int)(RollGainI * 1000),(int)(RollGainD * 100));
        printf("\n\rYaw P: %d I: %d D: %d", (int)(YawGainP * 100),(int)(YawGainI * 1000),(int)(YawGainD * 100));
    }
}

void set_factory_defaults(void){
    // seta as variaveis com os _DEF.... do defaults.h       
}

void uvetcpy(unsigned int result[], const unsigned int vet[], int size){
    do{
        size--;
        result[size] = vet[size];
    }while(size > 0);
}

