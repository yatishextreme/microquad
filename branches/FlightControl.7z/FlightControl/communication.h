#ifndef COMMUNICATION_H_
#define COMMUNICATION_H_

#include "mcufunctions.h"

/* PPM interrupt */

/* XBEE UART */

/* EEPROM */

/* NAVIGATION */

#endif /*COMMUNICATION_H_*/
