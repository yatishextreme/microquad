#ifndef __FLIGHTCONTROL
#define __FLIGHTCONTROL

#include <msp430x261x.h>

#include "io.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "signal.h"

#include "defaults.h"
#include "delay.h"
#include "analog.h"
#include "uart.h"
#include "timers.h"
#include "i2c.h"
#include "mma7455.h" // accelerometro
#include "lpx510al.h"  // gyroscope
#include "eeprom.h" //24LC1025
#include "ppm.h"

//#define __MMA7260 // accelerometro analogico ( melhor em sensibilidade )

#define ToRad(x) (x*0.01745329252)
#define ToDeg(x) (x*57.2957795131)
#define Constrain(val,min,max) ((val)<(min)?(min):(val)>(max)?(max):val) // limita um valor entre min e max

#define THROTTLE_CH 1
#define ROLL_CH 3
#define PITCH_CH 2
#define YAW_CH 0
#define CH5_CH 4
#define CH6_CH 5

#define GYRO_GAIN 0.324;        // 2.5 mV/�/s

#define MEAN_SIZE 300
#ifdef __MMA7260
#define ACCEL_GAIN 0.091125    // 800 mV/g * 90
#endif // __MMA7260

//#define TEST_ESC_PERIOD // testa minimo tempo de resposta do ESC 
//#define CALIBRATE_ESC
#define FAST_PWM // 150 hz update rate
//#define ESC_I2C

#define LEDRED_ON (P5OUT&=~BIT5)
#define LEDRED_OFF (P5OUT|=BIT5)
#define LEDRED_TOGGLE (P5OUT=P5OUT^BIT5)

#define LEDGREEN_ON (P5OUT&=~BIT6)
#define LEDGREEN_OFF (P5OUT|=BIT6)
#define LEDGREEN_TOGGLE (P5OUT=P5OUT^BIT6)

#define BUZZER_ON (P5OUT|=BIT7)
#define BUZZER_OFF (P5OUT&=~BIT7)
#define BUZZER_TOGGLE (P5OUT=P5OUT^BIT7)

// valores baseados num limite de -40 a +40 graus
#define STICK_TO_ANGLE_FACTOR 0.04
// valor para -100 a +100
#define STICK_TO_YAW_FACTOR 0.1

//#define SIGNAL_LOST_ALARM_ENABLE
#define SIGNAL_LOST_ALARM 75

//#define BATTERY_ALARM_ENABLE
#define BATTERY_SHTD 2850
#define MIN_BATTERY 2950
#define MAX_BATTERY 3850

#define MIN_THROTTLE 2000
#define MAX_THROTTLE 4000

// colocar numeros primos para diminuir a probabilidade de ocorrerem simultaneamente
#define LOOP_PERIOD 5 // controle em 5ms
#define ERROR_PERIOD 13 // error check em 5 * 13 = 65ms
#define SERIAL_PERIOD 3 // serial check in 15ms ( telemetry // error report)
#define RC_CHECK_PERIOD 7 // rc check in 7 * 5 = 35ms

typedef enum{
    _NO_ERROR,
    _LOW_BAT,
    _HIGH_BAT,
    _NO_SIGNAL
}ERROR;

#define BEEP_TIME 2

typedef enum{
    _NO_BEEP,
    _ONE_FAST,
    _ONE_SLOW,
    _TWO_FAST,
    _TWO_SLOW,
    _THREE_FAST,
    _THREE_SLOW
}BEEPSTYLE;

extern ERROR CurrentError;
extern BEEPSTYLE CurrentBeep;

extern char MotorArmed;

extern float PPMSlope[6];
extern float PPMOffset[6];

extern float ThrottleAcc;
extern int ThrottleRef;
extern int Throttle[4];
extern int ThrottleOffset[4];

// Pitch Control
extern float PitchGainP;
extern float PitchGainI;
extern float PitchGainD;

// Roll Control
extern float RollGainP;
extern float RollGainI;
extern float RollGainD;
extern float RollGainCascateP; //isso foi um teste que nao deu certo, tenho que por PID fora da cascata e PD dentro

// yaw control
extern float YawGainP;
extern float YawGainI;
extern float YawGainD;

extern float G_Dt;

extern float GyroValues[3];
extern float AccelValues[3];
extern float ChannelInput[6];

extern float PitchRef;
extern float RollRef;
extern float YawRef;

extern float Pitcherro;
extern float RollErro;
extern float YawErro;

extern float RollErroCascate;

extern float PitchErroOld;
extern float RollErroOld;
extern float YawErroOld;

extern float PitchControl;
extern float RollControl;
extern float YawControl;

extern float PitchProportional;
extern float PitchIntegrator;
extern float PitchDerivative;

extern float RollProportional;
extern float RollIntegrator;
extern float RollDerivative;

extern float YawProportional;
extern float YawIntegrator;
extern float YawDerivative;

extern float PitchGyro;
extern float RollGyro;
extern float YawGyro;

extern float Pitch;
extern float Roll;
extern float Yaw;

void setup(void);
void calibrate_gyro(void);
void error_process(void);
void beep_process(void);
void set_beep(BEEPSTYLE beep);

void set_throttle(void);
void set_min_throttle(void);

void save_PID_values(void);
void load_PID_values(void);
void init_MMA7455(void);
void load_transmitter_values(void);
void adjust_sensors(void);
void filter_angles(void);
void process_rc_reference(void);
void compute_control(void);
void calibrate_radio(void);
void calibrate_accel(void);

#endif /* __FLIGHTCONTROL */
