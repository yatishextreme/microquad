#include "mcufunctions.h"
#include "signal.h"

unsigned long MILLISECONDS = 0;

void MCU_init(void){
	// primary
	WDT_init();
	CLK_init();
	TMRA_init();
	TMRB_init();
	ADC12_init();
	
	// secondary
	PPM_init();
	SPI_init();
	I2C_init(I2C_MSTR_ADDR);
	UART_init();
	
	/* configure I/O output pins - led e buzzer*/
	P5OUT |= (0x20 | 0x40 | 0x80);
	
	__bis_SR_register(GIE);
}

void WDT_init(void){
    WDTCTL = WDTPW + WDTHOLD;
}

void CLK_init(void){
	int i = 0;
    /* 
     * Basic Clock System Control 2
     * 
     * SELM_3 -- LFXTCLK
     * DIVM_0 -- Divide by 1
     * SELS -- XT2CLK when XT2 oscillator present. LFXT1CLK or VLOCLK when XT2 oscillator not present
     * DIVS_0 -- Divide by 1
     * ~DCOR -- DCO uses internal resistor
     * 
     * Note: ~DCOR indicates that DCOR has value zero
     */
    BCSCTL2 = SELM_3 + DIVM_0 + SELS + DIVS_0;

    if (CALBC1_16MHZ != 0xFF) {
        for(i = 0; i < 30000; i++);
        for(i = 0; i < 30000; i++);
        for(i = 0; i < 30000; i++);
        /* Follow recommended flow. First, clear all DCOx and MODx bits. Then
         * apply new RSELx values. Finally, apply new DCOx and MODx bit values.
         */
        DCOCTL = 0x00;
        BCSCTL1 = CALBC1_16MHZ;     /* Set DCO to 16MHz */
        DCOCTL = CALDCO_16MHZ;
    }  

    /* 
     * Basic Clock System Control 1
     * 
     * XT2OFF -- Disable XT2CLK
     * XTS -- High Frequency
     * DIVA_0 -- Divide by 1
     */
    BCSCTL1 |= XT2OFF + XTS + DIVA_0;

    /* 
     * Basic Clock System Control 3
     * 
     * XT2S_2 -- 3 - 16 MHz
     * LFXT1S_2 -- If XTS = 0, XT1 = VLOCLK ; If XTS = 1, XT1 = 3 - 16-MHz crystal or resonator
     * XCAP_0 -- ~1 pF
     */
    BCSCTL3 = XT2S_2 + LFXT1S_2 + XCAP_0;

}

void PPM_init(void){
	P1DIR &= ~PPM_P1_MASK; // P1.5 .. P1.7
	P2DIR &= ~PPM_P2_MASK; // P2.0 .. P2.2
	
	P1IE |= PPM_P1_MASK;
	P2IE |= PPM_P2_MASK;
	
	/* calibrar canais */
	PPM_calibration();
}

void SPI_init(void){
}

void I2C_init(char addr){
	/* Disable USCI */
    UCB1CTL1 |= UCSWRST;
    
    /* 
     * Control Register 0
     * 
     * ~UCA10 -- Own address is a 7-bit address
     * ~UCSLA10 -- Address slave with 7-bit address
     * ~UCMM -- Single master environment. There is no other master in the system. The address compare unit is disabled
     * UCMST -- Master mode
     * UCMODE_3 -- I2C Mode
     * UCSYNC -- Synchronous Mode
     * 
     * Note: ~<BIT> indicates that <BIT> has value zero
     */
    UCB1CTL0 = UCMST + UCMODE_3 + UCSYNC;
    
    /* 
     * Control Register 1
     * 
     * UCSSEL_2 -- SMCLK
     * ~UCTR -- Receiver
     * ~UCTXNACK -- Acknowledge normally
     * ~UCTXSTP -- No STOP generated
     * ~UCTXSTT -- Do not generate START condition
     * UCSWRST -- Enabled. USCI logic held in reset state
     * 
     * Note: ~<BIT> indicates that <BIT> has value zero
     */
    UCB1CTL1 = UCSSEL_2 + UCSWRST;
    
    /* 
     * I2C Own Address Register
     * 
     * ~UCGCEN -- Do not respond to a general call
     * 
     * Note: ~UCGCEN indicates that UCGCEN has value zero
     */
    UCB1I2COA = addr;
    
    /* Bit Rate Control Register 0 */
    UCB1BR0 = 40;
    
    /* Enable USCI */
    UCB1CTL1 &= ~UCSWRST;
    
    /* seleciona pins P5.1 e P5.2 pro I2C */
    P5SEL |= 0x02 + 0x04;
}

void UART_init(void){

}

void TMRA_init(void){
    /* 
     * TACCTL0, Capture/Compare Control Register 0
     * 
     * CM_0 -- No Capture
     * CCIS_0 -- CCIxA
     * ~SCS -- Asynchronous Capture
     * ~SCCI -- Latched capture signal (read)
     * ~CAP -- Compare mode
     * OUTMOD_0 -- PWM output mode: 0 - OUT bit value
     * 
     * Note: ~<BIT> indicates that <BIT> has value zero
     */
    TACCTL0 = CM_0 + CCIS_0 + OUTMOD_0 + CCIE;

    /* TACCR0, Timer_A Capture/Compare Register 0 */
    TACCR0 = 16001;

    /* 
     * TACTL, Timer_A3 Control Register
     * 
     * TASSEL_1 -- ACLK
     * ID_1 -- Divider - /1
     * MC_1 -- Up Mode
     */
    TACTL = TASSEL_1 + ID_0 + MC_1;
    
    /* nenhuma porta sera usada como saida do timerA */ 
}

/* TIMER B */
// 4020 = 2ms ; 2020 = 1ms
void TMRB_init(void){
    /* 
     * TBCCTL1, Capture/Compare Control Register 1
     * 
     * CM_0 -- No Capture
     * CCIS_0 -- CCIxA
     * OUTMOD_7 -- PWM output mode: 7 - PWM reset/set
     */
    TBCCTL1 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL2 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL3 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL4 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL5 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL6 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;

    /* TBCCR0, Timer_B Capture/Compare Register 0 */
    TBCCR0 = 40001;

    /* TBCCR1, Timer_B Capture/Compare Register 1 */
    TBCCR1 = 2020; /* 1ms */
    TBCCR2 = 2020; /* 1ms */
	TBCCR3 = 2020; /* 1ms */
    TBCCR4 = 2020; /* 1ms */
    TBCCR5 = 2020; /* 1ms */
    TBCCR6 = 2020; /* 1ms */

    /* 
     * TBCTL, Timer_B3 Control Register
     * 
     * CNTL_0 -- 16-bit, TBR(max) = 0FFFFh
     * TBSSEL_1 -- ACLK
     * ID_3 -- Divider - /8
     * MC_1 -- Up Mode
     */
    TBCTL = TBCLGRP_0 + CNTL_0 + TBSSEL_1 + ID_3 + MC_1;
    
    /* configura saidas do timerB - P4.1 a P4.6*/
    P4SEL = 0x7E;
    P4DIR = 0x7E;
}

/* TIMER A */
void TMRA_delay_ms(unsigned long _delay){
	__disable_interrupt();
	unsigned long i;
	i = MILLISECONDS + _delay;
	while(MILLISECONDS < i);
	__enable_interrupt();
}

interrupt (TIMERA0_VECTOR) TIMERA0_ISR_HOOK(void){
	MILLISECONDS++;
}

/* void TMRB_changeduty(char n, char duty)
 * n = quem vai mudar
 * duty = valor do duty de 0 a 100
 * */
void TMRB_change_duty(char n,  int duty){
	switch(n){
		case 1:
			TBCCR1 = duty;
			break;
		case 2:
			TBCCR2 = duty;
			break;
		case 3:
			TBCCR3= duty;
			break;
		case 4:
			TBCCR4 = duty;
			break;
		case 5:
			TBCCR5 = duty;
			break;
		case 6:
			TBCCR6 = duty;
			break;
	}
}

void TMRB_change_duties( int duties[6]){
	TBCCR1 = duties[0];
	TBCCR2 = duties[1];
	TBCCR3 = duties[2];
	TBCCR4 = duties[3];
	TBCCR5 = duties[4];
	TBCCR6 = duties[5];
}

/* ADC12 */
void ADC12_init(void){
	ADC12CTL0 = SHT0_2 + ADC12ON;             // Set sampling time, turn on ADC12
	ADC12CTL1 = ADC12SSEL_2;				  // MCLK ADC12 clock source
	
	/* configura inputs do ADC12 A0 A1 A2 A3 A4 */
	P6DIR &= 0xFF;                            // P6 i/p 
	P6SEL |= 0xFF;                            // P6 adc 
}

int ADC12_read_channel(unsigned char n){
	ADC12CTL0 &= ~ENC;
	
	if(n > 0x0F){
		return 0;
	}
		
	ADC12MCTL0 = n;
	ADC12CTL1 = ADC12SSEL_2;			// MCLK ADC12 clock source
	ADC12CTL0 |= ENC + ADC12SC;       	// Start convn, software controlled
	while(ADC12CTL1 & ADC12BUSY);

	return ADC12MEM0;
}

/* PPM Interruption */
unsigned int PPM_aux;
unsigned int PPM_capture_time[6] = {0, 0, 0, 0, 0, 0};

float PPM_result[6] = {0, 0, 0, 0, 0, 0};
float PPM_slope[6] = {0, 0, 0, 0, 0, 0};
float PPM_offset[6] = {0, 0, 0, 0, 0, 0};

unsigned char PPM_ch_counter = 0;

void PPM_calibration(){

}

interrupt (PORT1_VECTOR) PORT1_ISR_HOOK(void){
	PPM_aux = TBR; // captura aqui pra ser mais exato
	// aqui eh usado PPM_P1_MASK, pq eh a interrupcao da P1	
	unsigned char channel_num = 0; // na P1 os canais vao de 0 a 2 e na P2 os canais vao de 3 a 5
	for(PPM_ch_counter = 0x20; PPM_ch_counter <= 0x80; PPM_ch_counter = PPM_ch_counter << 1){
		if(P1IFG & (PPM_ch_counter & PPM_P1_MASK)){
			if(!(P1IES & (PPM_ch_counter & PPM_P1_MASK))){ // low to high
				PPM_capture_time[channel_num] = PPM_aux;
				P1IES |= (PPM_ch_counter & PPM_P1_MASK); // configura high to low
			}
			else{ // high to low
				PPM_refresh_channel(channel_num);
				P1IES &= ~(PPM_ch_counter & PPM_P1_MASK); // configure low to high		
			}
			P1IFG &= ~(PPM_ch_counter & PPM_P1_MASK); // apaga o interruption flag da P1.7
		}
		channel_num++;
	}
}

void PPM_refresh_channel(unsigned char channel){
	if(PPM_capture_time[channel] > PPM_aux){ // se deu overflow na contagem do timer
#ifdef PPM_LOWPASS
		PPM_result[channel] = ((PPM_result[channel] * PPM_LPGAIN0) / 10) + ((((40001 - PPM_capture_time[channel]) + PPM_aux) * PPM_LPGAIN1 ) / 10);
#else /* PPM_LOWPASS */
		PPM_result[channel] = (40001 - PPM_capture_time[channel]) + PPM_aux;
#endif /* PPM_LOWPASS */
	}
	else{ // se nao deu overflow na contagem do timer
#ifdef PPM_LOWPASS
		PPM_result[channel] = ((PPM_result[channel] * PPM_LPGAIN0) / 10) + (((PPM_aux - PPM_capture_time[channel]) * PPM_LPGAIN1 ) / 10 );
#else
		PPM_result[channel] = PPM_aux - PPM_capture_time[channel];
#endif /* PPM_LOWPASS */
	}
}

interrupt (PORT2_VECTOR) PORT2_ISR_HOOK(void)
{
	// copiar da port 1
}

/* I2C */

void I2C_set_slave_add(char addr){
	/* I2C Slave Addres	s Register */
    UCB1I2CSA = addr;
}

/*
 * returns n = 0 good
 * returns n = 1 wrong address ( first timeout )
 * returns n > 1 nack for byte 'n - 2'
 */
char I2C_receive_byte(char byte[], char buff_size){
	int timeout_count = 0, buff_counter = 0;
			
	while(buff_counter < buff_size){
		// set receiver mode + generate start condition
		UCB1CTL1 |= UCTXSTT;
		UCB1CTL1 &= ~UCTR; 
		
		// espera UCTXSTT goes down ( address acknowledge )
		timeout_count = 0;
		while(UCB1CTL1 & UCTXSTT){ // espera acknowledge do address
			if((timeout_count >= I2C_TIMEOUT ) || (UCB1STAT & UCNACKIFG)){ // se estourar timeout ou se receber um nack da um stop e retorna 1
				UCB1CTL1 |= UCTXSTP; // stop
				return 1;
			}
			timeout_count++;
		}
		
		// espera chegar o dado no buffer UCB1RXIFG == 1
		timeout_count = 0;
		while(!(UC1IFG & UCB1RXIFG)){ // espera o flag de RX buffer full
			if(timeout_count >= I2C_TIMEOUT ){ // se o slave ta se enrolando pra enviar, sai fora
				UCB1CTL1 |= UCTXSTP; // stop
				return (buff_counter + 2);
			}
			timeout_count++;
		}
		
		byte[buff_counter++] = UCB1RXBUF;
	}
	
	UCB1CTL1 |= UCTXSTP;
	
	return 0;
}

/* 
 * I2C Write Byte:
 * char I2C_sendByte(char byte[], char buff_size);
 * byte is a buffer array where the size is specified by buff_size.
 * the first byte sent is in the position 0 and the last is in the position buff_size - 1.
 * returns n = 0 good
 * returns n = 1 wrong address ( first timeout )
 * returns n > 1 nack for byte 'n - 2'
 */
char I2C_write_byte(char byte[], char buff_size){
	int timeout_count = 0, buff_counter = 0;
			
	while(buff_counter < buff_size){
		timeout_count = 0;
		while(!(UC1IFG & UCB1TXIFG)){ // espera o TX buff ficar vazio
			if(timeout_count >= I2C_TIMEOUT ){
				UCB1CTL1 |= UCTXSTP; // stop
				return (buff_counter + 2);
			}
			timeout_count++;
		}
		// set transmiter mode + generate start condition
		UCB1CTL1 |= UCTR + UCTXSTT;
		// espera UCTXSTT == 0 address acknowledge received
		timeout_count = 0;
		while(UCB1CTL1 & UCTXSTT){ // espera acknowledge do address
			if(timeout_count >= I2C_TIMEOUT ){
				UCB1CTL1 |= UCTXSTP; // stop
				return 1;
			}
			timeout_count++;
		}		
		
		// escreve o byte no buffer UCB1TXBUF
		UCB1TXBUF = byte[buff_counter++];
				
	}
	// send stop condition
	UCB1CTL1 |= UCTXSTP;
	
	return 0;
}


char I2C_read_request(char register_addr){
	int timeout_count = 0, buff_counter = 0;
			
	while(!(UC1IFG & UCB1TXIFG)){ // espera o TX buff ficar vazio
		if(timeout_count >= I2C_TIMEOUT ){
			UCB1CTL1 |= UCTXSTP; // stop
			return (buff_counter + 2);
		}
		timeout_count++;
	}
	// set transmiter mode + generate start condition
	UCB1CTL1 |= UCTR + UCTXSTT;
	// espera UCTXSTT == 0 address acknowledge received
	timeout_count = 0;
	while(UCB1CTL1 & UCTXSTT){ // espera acknowledge do address
		if(timeout_count >= I2C_TIMEOUT ){
			UCB1CTL1 |= UCTXSTP; // stop
			return 1;
		}
		timeout_count++;
	}		
	
	// escreve o byte no buffer UCB1TXBUF
	UCB1TXBUF = register_addr;
		
	timeout_count = 0;	
	while(!(UC1IFG & UCB1TXIFG)){ // espera o TX buff ficar vazio
		if(timeout_count >= I2C_TIMEOUT ){
			UCB1CTL1 |= UCTXSTP; // stop
			return (buff_counter + 2);
		}
		timeout_count++;
	}	
			
	return 0;
}
