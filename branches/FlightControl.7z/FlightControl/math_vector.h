#ifndef MATH_VECTOR_H_
#define MATH_VECTOR_H_

void vector_scale(int vector_out[], int vector_in[], int scale,  unsigned int size);
void vector_scale_float(float vector_out[], float vector_in[], float scale,  unsigned int size);

void vector_cross(float output[3], float input1[3], float input2[3]);
float vector_dot(float input1[3], float input2[3]);

// ver se da pra fazer polimorfismo de parametro aqui com essas fun��es e pras de cima tbm
void vector_add(int vector_out[], int vector_in1[], int vector_in2[], unsigned int size);
void vector_add_float(float vector_out[], float vector_in1[], float vector_in2[], unsigned int size);	
	
#endif /*MATH_VECTOR_H_*/
