#ifndef MCUFUNCTIONS_H_
#define MCUFUNCTIONS_H_

#include <msp430x261x.h>

/* inicializacao dos perifericos */
void MCU_init(void);

void WDT_init(void);
void CLK_init(void);
void TMRA_init(void);
void TMRB_init(void);
void ADC12_init(void);
void PPM_init(void);
void SPI_init(void);
void I2C_init(char addr);
void UART_init(void);

/* timerA */
extern unsigned long MILLISECONDS;
void TMRA_delay_ms(unsigned long _delay);

/* timerB */
void TMRB_change_duty(char n,  int duty);
void TMRB_change_duties( int duties[6]);
	
/* ADC12 */
int ADC12_read_channel(unsigned char n); 

/* PPM */
/* o PPM come�a a funcionar a partir do PPM_init, ele funciona com interrupcao na porta P1 e P2 que fica toda hora analizando o tempo de todos os canais habilitados */
#define PPM_LOWPASS // habilita lowpass na leitura do canal pra diminuir ruido, aumenta em 2 multiplicacoes e 2 divisoes a mais por canal no programa
#ifdef PPM_LOWPASS
#define PPM_LPGAIN0 6
#define PPM_LPGAIN1 4
#endif /* PPM_LOWPASS */

#define PPM_CHANNEL_ACTIVE 0x3F /* 6 canais ativos */

#define THROTTLE_CH 0
#define ROLL_CH 1
#define PITCH_CH 2
#define YAW_CH 3
#define AUX1_CH 4
#define AUX2_CH 5

#define PPM_P2_MASK (0x07 & (PPM_CHANNEL_ACTIVE >> 3))
#define PPM_P1_MASK (0xE0 & (PPM_CHANNEL_ACTIVE << 5))

extern float PPM_slope[6];
extern float PPM_offset[6];

extern float PPM_result[6];

void PPM_calibration();
/* essa funcao eh feita na interrupcao, ela nem precisa tar aqui */
void PPM_refresh_channel(unsigned char channel);

/* SPI */

/* I2C */
#define I2C_MSTR_ADDR 99
#define I2C_TIMEOUT 100 //cycles

void I2C_set_slave_add(char addr);

/* char I2C_sendByte(char byte[], char buff_size)
 * returns n = 0 good
 * returns n = 1 wrong address ( first timeout )
 * returns n > 1 nack for byte 'n - 2' */
char I2C_receive_byte(char byte[], char buff_size);

/* char I2C_sendByte(char byte[], char buff_size)
 * returns n = 0 good
 * returns n = 1 wrong address ( first timeout )
 * returns n > 1 nack for byte 'n - 2' */
char I2C_write_byte(char byte[], char buff_size);

char I2C_read_request(char register_addr);

/* UART */

#endif /*MCUFUNCTIONS_H_*/
