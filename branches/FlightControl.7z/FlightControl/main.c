#include "flightcontrol.h"

void print_help(void);
void serial_process(char c);

int main(){ 
    WDTCTL = WDTPW + WDTHOLD;  // desabilita watchdog
    
    long k = 0;
    for(k = 0; k < 200000; k++);
    
    char c = 0; // usado para ler RXBUFF da UART
    
    int ErrorTicker = 0, SerialTicker = 0, RCProcessTicker = 0; // contadores de tempo para envento
         
    setup();    // configura os perifericos, o clock do msp430f2619, os sensores e calibra os sensores e ESC
    
    eint(); // habilita interruptions
     
    LEDGREEN_OFF; // ascende a luz verde pra sinalizar fim do setup e motores desarmados
    
    MILLISECONDS = 0;
    
    for(;;){    
        if((MILLISECONDS - TIMER_MS) >= LOOP_PERIOD ){
            TIMER_MS_OLD = TIMER_MS;
            TIMER_MS = MILLISECONDS;
            // periodo de amostragem
            G_Dt = (TIMER_MS - TIMER_MS_OLD) * 0.001; // sample period em milisegundos

            // le os canais analogicos
            analog_refresh_all();
            
            // ajusta os ganhos do acelerometro e gyro para grandezas reais
            adjust_sensors();
            
            // filtering
            filter_angles();
            
            // envia controle
            if(MotorArmed == 1){
                LEDGREEN_OFF;
                
                // controle            
                compute_control();
                
                // envia sinal para os motores
                set_throttle();
            }
            else{
                LEDGREEN_ON;
            }
            
            // envio serial periodico
            if((SerialTicker++) >= SERIAL_PERIOD){  
                // recebimento de comandos
                if(UC1IFG & UCA1RXIFG){
                    LEDRED_TOGGLE;
                    c = UCA1RXBUF;
                    serial_process(c);
                }
                SerialTicker = 0;
            }
            
            // processamento de erros
            if((ErrorTicker++) >= ERROR_PERIOD){
                error_process();
                ErrorTicker = 0;
            }
            
            // processamento do RC
            if((RCProcessTicker++) >= RC_CHECK_PERIOD){
                process_rc_reference(); // detect quando ta sem o controle
                RCProcessTicker = 0;
            }
        }
    }
}

void print_help(void){

    int i = 0, j = 0;
    
    printf("\n\n\rCommand Line Help:\n");
    
    printf("\n\r -: calibration RC start/finish."); 
    printf("\n\r 1: send radio input.");     
    printf("\n\r 2: send raw analog.");
    printf("\n\r 3: send mixed pitch, roll, yaw.");
    printf("\n\r 4: send motor control.");
    printf("\n\r 5: send gyro pitch, roll, yaw.");                               
    
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
                    
    printf("\n\r 6: send accel pitch, roll.");                                   
    printf("\n\r 7: send pitch gains x 100, roll gains x 1000, yaw gains x 100.");
    
    printf("\n\r 8: send references.");
    printf("\n\r 9: send throttle offset.");
    printf("\n\r 0: send current gains.");
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
    
    printf("\n\r q: incrementa 10%% Kp pitch.");
    printf("\n\r w: incrementa 1%% Ki pitch.");
    printf("\n\r e: incrementa 10%% Kd pitch.");
    printf("\n\r r: incrementa 10%% Kp roll.");
    printf("\n\r t: incrementa 1%% Ki roll.");
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
    
    printf("\n\r y: incrementa 10%% Kd roll.");
    printf("\n\r u: incrementa 10%% Kp yaw.");
    printf("\n\r i: incrementa 1%% Ki yaw.");
    printf("\n\r o: incrementa 10%% Kd yaw.");
    printf("\n\r p: re calibrate gyro and accel.");
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
    
    printf("\n\r a: decrementa 10%% Kp pitch.");
    printf("\n\r s: decrementa 1%% Ki pitch.");
    printf("\n\r d: decrementa 10%% Kd pitch.");
    printf("\n\r f: decrementa 10%% Kp roll.");
    printf("\n\r g: decrementa 1%% Ki roll.");
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
    
    printf("\n\r h: decrementa 1%% Ki roll.");
    printf("\n\r j: decrementa 10%% Kd yaw.");
    printf("\n\r k: decrementa 10%% Kd yaw.");
    printf("\n\r l: decrementa 10%% Kd yaw.");
    printf("\n\r z: zera pitch.");
    printf("\n\r x: zera roll.");
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
    
    printf("\n\r c: zera yaw.");
    printf("\n\r v: increment throttle offset motor 1.");
    printf("\n\r b: increment throttle offset motor 2.");
    printf("\n\r n: increment throttle offset motor 3.");
    printf("\n\r m: increment throttle offset motor 4.");
    printf("\n\r space: stop auto-stabilization.");
    printf("\n\r .: arm_motors.");
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
    
    printf("\n\r Q: increment motor 1 throttle.");
    printf("\n\r W: increment motor 2 throttle.");
    printf("\n\r E: increment motor 3 throttle.");
    printf("\n\r R: increment motor 4 throttle.");
    printf("\n\r T: increment +5 throttle reference.");
    printf("\n\r Y: increment 10%% roll cascate proportional gain.");      
    printf("\n\r U: decrement yaw reference");  
    printf("\n\r I: decrement pitch reference.");
    printf("\n\r O: increment yaw reference");
    printf("\n\r P: calibrate accelerometer.");  
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
    
    printf("\n\r A: decrement motor 1 throttle.");
    printf("\n\r S: decrement motor 2 throttle.");
    printf("\n\r D: decrement motor 3 throttle.");
    printf("\n\r F: decrement motor 4 throttle.");
    printf("\n\r G: decrement -5 throttle reference.");
    printf("\n\r H: help. shows this menu.");
    printf("\n\r J: decrement roll reference.");
    printf("\n\r K: increment pitch reference.");
    printf("\n\r L: increment roll reference.");
    
    for(j = 0; j < 5; j++){
        for(i = 0; i < 20000; i++);
    }
    
    printf("\n\r Z: set min throttle all motors.");
    printf("\n\r X: ACK.");
    printf("\n\r C: sample period.");
    printf("\n\r V: decrement throttle offset motor 1.");
    printf("\n\r B: decrement throttle offset motor 2.");
    printf("\n\r N: decrement throttle offset motor 3."); 
    printf("\n\r M: decrement throttle offset motor 4."); 

    printf("\n\r!: send channel inputs.");    
    printf("\n\r?: save PID values.");    
}

void serial_process(char c){
    
    switch(c){                  
        case 'H': //help
            if(!MotorArmed){
                print_help();
            }                        
        break;

        case '1': // reserved
            printf("%d %d %d %d %d %d %d\n", (int)PPMResult[0], (int)PPMResult[1], (int)PPMResult[2], (int)PPMResult[3], (int)PPMResult[4], (int)PPMResult[5], (int)PPMResult[6]);            
        break;

        case '-': 
            calibrate_radio();
        break;
        
        case 'Y': // reserved
            // reserved ;   
        break;
        
        case 'P': 
            calibrate_accel();             
        break;
                
        case '2': // raw analog
            printf("%d %d %d %d %d %d %d %d\n", AnalogValue[0], AnalogValue[1], AnalogValue[2], AnalogValue[3], AnalogValue[4], AnalogValue[5], AnalogValue[6], AnalogValue[7]);
        break;
        
        case '3': // pitch roll yaw
            printf("%d %d %d\n", (int)Pitch, (int)Roll, (int)Yaw);
        break;
        
        case '4': // motor throttle
            printf("%d %d %d %d\n ", TBCCR1, TBCCR2, TBCCR3, TBCCR4);
        break;
                    
        case '5': // gyro pitch roll yaw
            printf("%d %d %d\n", (int)(GyroValues[1]), (int)(GyroValues[0]), (int)(GyroValues[2]));
        break;
        
        case '6': // accel pitch roll
            printf("%d %d %d\n", (int)(AccelValues[0]), (int)(AccelValues[1]), (int)(AccelValues[2]));
        break;
        
        case '7': // pitch gains roll gains yaw gains
            printf("%d %d %d %d %d %d %d %d %d\n", (int)(PitchGainP * 100), (int)(PitchGainI * 1000), (int)(PitchGainD * 100), (int)(RollGainP * 100), (int)(RollGainI * 1000), (int)(RollGainD * 100), (int)(YawGainP * 100), (int)(YawGainI * 1000), (int)(YawGainD * 100));
        break;
        
        case '8': // references
            printf("%d %d %d %d\n", (int)PitchRef, (int)RollRef, (int)YawRef, ThrottleRef);
        break;
        
        case '9': // throttle offset
            printf("%d %d %d %d\n", ThrottleOffset[0], ThrottleOffset[1], ThrottleOffset[2], ThrottleOffset[3]);
        break;
        
        case '0': // current gains
            printf("%d %d %d %d %d %d %d %d %d\n", (int)(PitchProportional * 100), (int)(PitchIntegrator * 100), (int)(PitchDerivative * 100), (int)(RollProportional * 100), (int)(RollIntegrator * 100), (int)(RollDerivative * 100), (int)(YawProportional * 100), (int)(YawIntegrator * 100), (int)(YawDerivative * 100));
        break;
                                    
        break;
        // increment gain
        case 'q':
            PitchGainP = PitchGainP * 1.1;   
        break;
        
        case 'w':
            PitchGainI = PitchGainI * 1.01;
        break;
        
        case 'e':
            PitchGainD = PitchGainD * 1.1;
        break;
        
        case 'r':
            RollGainP = RollGainP * 1.1;
        break;
        
        case 't':
            RollGainI = RollGainI * 1.01;
        break;
        
        case 'y':
            RollGainD = RollGainD * 1.1;
        break;
        
        case 'u':
            YawGainP = YawGainP * 1.1;
        break;
        
        case 'i':
            YawGainI = YawGainI * 1.01;
        break;
        
        case 'o':
            YawGainD = YawGainD * 1.1;
        break;
        
        case 'p':
            calibrate_gyro();   
        break;
        // decrement gain
            
        case 'a':
            PitchGainP = PitchGainP * 0.9;   
        break;
        
        case 's':
            PitchGainI = PitchGainI * 0.99;
        break;
        
        case 'd':
            PitchGainD = PitchGainD * 0.9;
        break;
        
        case 'f':
            RollGainP = RollGainP * 0.9;
        break;
        
        case 'g':
            RollGainI = RollGainI * 0.99;
        break;
        
        case 'h':
            RollGainD = RollGainD * 0.9;
        break;
        
        case 'j':
            YawGainP = YawGainP * 0.9;
        break;
        
        case 'k':
            YawGainI = YawGainI * 0.99;
        break;
        
        case 'l':
            YawGainD = YawGainD * 0.9;
        break;
        
        // trim drift angle etc
        case 'z':
            Pitch = 0;
            PitchGyro = 0;
        break;
        
        case 'x':
            Roll = 0;
            RollGyro = 0;
        break;
        
        case 'c':
            Yaw = 0;
            YawGyro = 0;
        break;
        
        case 'v':
            ThrottleOffset[0] = ThrottleOffset[0] + 1;
        break;
        
        case 'b':
            ThrottleOffset[1] = ThrottleOffset[1] + 1;
        break;
        
        case 'n':
            ThrottleOffset[2] = ThrottleOffset[2] + 1;
        break;
        
        case 'm':
            ThrottleOffset[3] = ThrottleOffset[3] + 1;
        break;
        
        case 'V':
            ThrottleOffset[0] = ThrottleOffset[0] - 1;
        break;
        
        case 'B':
            ThrottleOffset[1] = ThrottleOffset[1] - 1;
        break;
        
        case 'N':
            ThrottleOffset[2] = ThrottleOffset[2] - 1;
        break;
        
        case 'M':
            ThrottleOffset[3] = ThrottleOffset[3] - 1;
        break;
        
        // motor armed
        case ' ':
            set_min_throttle();                       
            MotorArmed = 0;
        break;
        
        case '.':
            MotorArmed = 1;
        break;
        
        // motor commands
        case 'Q': // incrementa throttle motor 1
            TBCCR1 = TBCCR1 + 1;
        break;
        
        case 'W': // incrementa throttle motor 2
            TBCCR2 = TBCCR2 + 1;
        break;
        
        case 'E': // incrementa throttle motor 3
            TBCCR3 = TBCCR3 + 1;
        break;
        
        case 'R': // incrementa throttle motor 4
            TBCCR4 = TBCCR4 + 1;
        break;
        
        case 'T': // incrementa +5 throttle reference
            ThrottleRef = ThrottleRef + 5;
        break;
        
        case 'U': // decrement yaw ref
            YawRef = YawRef - 1;
        break;
        
        case 'I': // decrementa pitch reference
            if(PitchRef > -45){
                PitchRef = PitchRef - 1;
            }
        break;
        
        case 'O':
            YawRef = YawRef + 1;
        break;
        
        case 'A': // Decrementa throttle motor 1
            TBCCR1 = TBCCR1 - 1;
        break;
        
        case 'S': // decrementa throttle motor 2
            TBCCR2 = TBCCR2 - 1;
        break;
        
        case 'D': // decrementa throttle motor 3
            TBCCR3 = TBCCR3 - 1;
        break;
        
        case 'F': // decrementa throttle motor 4
            TBCCR4 = TBCCR4 - 1;
        break;
        
        case 'G': //decrement -5 throttle reference
            ThrottleRef = ThrottleRef - 5;
        break;

        case 'J': // decrement roll reference
            if(RollRef > -45){
                RollRef = RollRef - 1;
            }
        break;
        
        case 'K': // increment pitch reference
            if(PitchRef < 45){
                PitchRef = PitchRef + 1;
            }
        break;
        
        case 'L': // increment Roll reference
            if(RollRef < 45){
                RollRef = RollRef + 1; 
            }
        break;
        
        case 'Z':
            set_min_throttle();
        break;

        case 'X':
            printf("X");
        break;
                            
        case 'C':
            printf("%d \n", (int)(G_Dt * 1000));
        break;
        
        case '?':
            save_PID_values();
        break;                    
        
        case '!':
            printf("%d %d %d %d %d %d \n", (int)(ChannelInput[0]), (int)(ChannelInput[1]), (int)(ChannelInput[2]), (int)(ChannelInput[3]), (int)(ChannelInput[4]), (int)(ChannelInput[5]) );
        break;
                            
        // tem mais chars reservados para usar se precisar
    }                
}


