#ifndef __DCM
#define __DCM

#include "flightcontrol.h"

//#define PRINT_MATRIX

extern float DCM_Matrix[3][3];
extern float Update_Matrix[3][3];
extern float Temporary_Matrix[3][3];

void DCM_process(void);
void print_matrix(float Matrix[3][3]);

#endif /* __DCM */
