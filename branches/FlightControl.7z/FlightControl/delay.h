#ifndef __DELAY
#define __DELAY

#include <msp430x261x.h>

//
// ****************************************************************
// **                                                            **
// **  LABORATORIO DE PROCESSADORES I (2010/I)                   **
// **                                                            **
// **  Rotinas de delay por software (@16MHz)                    **
// **                                                            **
// **                                    (C) by JCLima, 2010/1   **
// **                                                            **
// ****************************************************************
//
// para clock de 16Mhz
void delay2us(void);
void delay5us(void);

void delayus(unsigned int tempo);
void delayms(unsigned int tempo);

#endif //__DELAY
