#include "atuadores.h"
#include "math_vector.h"

int ATUADORES_relacao = (MAX_THROTTLE - MIN_THROTTLE) / 100;

void ATUADORES_setDuty(char _n, int _duty){
	_duty = _duty * ATUADORES_relacao + 2020;
	TMRB_change_duty(_n, _duty);
}

void ATUADORES_set_duties(int duties[ATUADORES_QTD]){
	vector_scale(duties, duties, ATUADORES_QTD, ATUADORES_relacao);
	TMRB_change_duties(duties);
}


