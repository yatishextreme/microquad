#include <msp430x261x.h>

void UART_init(void);
int putchar(int c);
