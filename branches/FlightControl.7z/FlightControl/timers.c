#include "timers.h"

volatile unsigned long MILLISECONDS = 0;
unsigned long TIMER_MS = 0;
unsigned long TIMER_MS_OLD = 0;

void TMRB_test_esc(void){
    char c = 1;
    unsigned int value = 10001; // 5ms
    printf("\n\rESC OUTPUT TESTER:\n\r'q' : increase\n\r'w' : decrease\n\r'0' : exit");
    
    while(c != '0'){
        if(UC1IFG & UCA1RXIFG){
            c = UCA1RXBUF;
            switch(c){
                case 'q':
                    value = Constrain(value + 100, 3001, 40001);    
                break;
                        
                case 'w':
                    value = Constrain(value - 100, 3001, 40001);
                break;
            }
            printf("\rperiod = %d us", value / 20);        
        }
    }
    TMRB_init(value);
}

/* TIMER B */
// 4020 = 2ms ; 2020 = 1ms
void TMRB_init(unsigned int period){
    /* 
     * TBCCTL1, Capture/Compare Control Register 1
     * 
     * CM_0 -- No Capture
     * CCIS_0 -- CCIxA
     * OUTMOD_7 -- PWM output mode: 7 - PWM reset/set
     */

    TBCCTL1 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL2 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL3 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL4 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL5 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;
    TBCCTL6 = CM_0 + CCIS_0 + CLLD_0 + OUTMOD_7;

    /* TBCCR0, Timer_B Capture/Compare Register 0 */
    TBCCR0 = period;

    /* TBCCR1, Timer_B Capture/Compare Register 1 */
    TBCCR1 = 0; 
    TBCCR2 = 0; 
    TBCCR3 = 0; 
    TBCCR4 = 0; 
    TBCCR5 = 0; 
    TBCCR6 = 0; 

    /* 
     * TBCTL, Timer_B3 Control Register
     * 
     * CNTL_0 -- 16-bit, TBR(max) = 0FFFFh
     * TBSSEL_1 -- ACLK
     * ID_3 -- Divider - /8
     * MC_1 -- Up Mode
     */
    TBCTL = TBCLGRP_0 + CNTL_0 + TBSSEL_1 + ID_3 + MC_1;
    
    /* configura saidas do timerB - P4.1 a P4.6*/
    P4SEL = 0x7E;
    P4DIR = 0x7E;
}

void TMRA_init(void){
    /* 
     * TACCTL0, Capture/Compare Control Register 0
     * 
     * CM_0 -- No Capture
     * CCIS_0 -- CCIxA
     * ~SCS -- Asynchronous Capture
     * ~SCCI -- Latched capture signal (read)
     * ~CAP -- Compare mode
     * OUTMOD_0 -- PWM output mode: 0 - OUT bit value
     * 
     * Note: ~<BIT> indicates that <BIT> has value zero
     */
    TACCTL0 = CM_0 + CCIS_0 + OUTMOD_0 + CCIE;

    /* TACCR0, Timer_A Capture/Compare Register 0 */
    TACCR0 = 16001;

    /* 
     * TACTL, Timer_A3 Control Register
     * 
     * TASSEL_1 -- ACLK
     * ID_1 -- Divider - /1
     * MC_1 -- Up Mode
     */
    TACTL = TASSEL_1 + ID_0 + MC_1;
    
    /* nenhuma porta sera usada como saida do timerA */ 
}

interrupt (TIMERA0_VECTOR) TIMERA0_ISR_HOOK(void){
    MILLISECONDS++;
}


