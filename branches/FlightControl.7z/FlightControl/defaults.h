#define _DEF_PITCH_P 1.2
// fazer todos os defaults aqui

