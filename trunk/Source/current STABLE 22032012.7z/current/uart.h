#include <msp430f2619.h>

void UART_init(void);
int putchar(int c);
