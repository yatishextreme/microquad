//SHORT DEF TYPES
#ifndef SHORT_TYPES
#define SHORT_TYPES

typedef unsigned char uchar;
typedef unsigned char uint8;
typedef unsigned int uint16;

#endif
