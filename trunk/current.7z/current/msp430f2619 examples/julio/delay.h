//
// ****************************************************************
// **                                                            **
// **  D E L A Y                                                 **
// **                                    (C) by JCLima, 2010/1   **
// **                                                            **
// ****************************************************************
//
extern void delay2us(void);
extern void delay5us(void);
extern void delayus(unsigned int tempo);
extern void delayms(unsigned int tempo);

